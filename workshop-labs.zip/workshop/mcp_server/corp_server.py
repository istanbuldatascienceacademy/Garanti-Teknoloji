"""Internal Resources MCP Server — workshop example.

WHY THIS DOMAIN WAS CHOSEN
--------------------------
The first idea people have when writing an MCP server for a bank is customer
data: "customer 360", "account movements", "limit lookup". For a workshop
example that is the WRONG choice, and the reason is worth teaching:

Everything an MCP tool returns enters the model's context. Everything in the
context goes to the model provider. An MCP tool can therefore become a channel
that carries data across your boundary without anyone deciding that it should.
Writing a tool that returns personal data is technically trivial and
institutionally significant, and a developer cannot make that call alone.

So this server exposes three internal resources that contain no personal data,
are genuinely useful, and are genuinely needed several times a day:
  1. Engineering standards (which rule applies where)
  2. The internal API catalogue (what a service does, who owns it)
  3. The release calendar (can we deploy today)

Run it:
    python mcp_server/corp_server.py

To register it with VS Code, see .vscode/mcp.json.
"""

from __future__ import annotations

import json
from datetime import date, datetime

from mcp.server import MCPServer

mcp = MCPServer(
    name="corp-internal",
    version="0.1.0",
    instructions=(
        "Provides access to internal engineering standards, the API catalogue "
        "and the release calendar. Contains NO personal or customer data."
    ),
)


# ============================================================
# Stand-in internal data — in a real system this comes from
# Confluence, the API gateway and the CMDB.
# ============================================================

STANDARDS: dict[str, dict] = {
    "java-service": {
        "title": "Java Microservice Standard",
        "version": "4.2",
        "scope": "All Spring Boot services",
        "clauses": [
            "Controllers contain no business logic; validation and routing only.",
            "External calls must set an explicit timeout, 3 seconds by default.",
            "Monetary amounts use BigDecimal, never double.",
            "No customer identifiers in logs (national ID, card number, account number).",
            "New endpoints require an OpenAPI schema in the same pull request.",
        ],
    },
    "data-access": {
        "title": "Data Access Standard",
        "version": "2.8",
        "scope": "Every component that touches a database",
        "clauses": [
            "Queries must be parameterised; string concatenation is forbidden.",
            "No direct DDL against production; changes go through the migration tool.",
            "Access to tables holding personal data is logged.",
            "SELECT * is not used; columns are named explicitly.",
        ],
    },
    "ai-assistant-usage": {
        "title": "Coding Assistant Usage Standard",
        "version": "1.1",
        "scope": "Everyone using Copilot or a comparable assistant",
        "clauses": [
            "Production data, customer data and secrets are never pasted into chat.",
            "Assistant-generated code is not merged without human review.",
            "Directories under content exclusion are not opened to the assistant.",
            "Unapproved MCP servers are not connected.",
        ],
    },
}

API_CATALOGUE: dict[str, dict] = {
    "customer-profile": {
        "name": "Customer Profile Service",
        "owner_team": "Customer Platform",
        "protocol": "REST",
        "criticality": "high",
        "contains_pii": True,
        "description": "Returns core customer attributes. Requires a separate access grant.",
    },
    "limit-engine": {
        "name": "Limit Engine",
        "owner_team": "Credit Technology",
        "protocol": "gRPC",
        "criticality": "high",
        "contains_pii": False,
        "description": "Runs product-level limit calculation rules.",
    },
    "notification": {
        "name": "Notification Service",
        "owner_team": "Channel Technology",
        "protocol": "REST + Kafka",
        "criticality": "medium",
        "contains_pii": True,
        "description": "Sends push, SMS and email messages.",
    },
    "fx-rates": {
        "name": "FX Rate Service",
        "owner_team": "Treasury Technology",
        "protocol": "REST",
        "criticality": "medium",
        "contains_pii": False,
        "description": "Live and historical foreign exchange rates.",
    },
}

# Release calendar: days on which deployment is blocked
DEPLOY_FREEZE_DAYS = {
    "2026-08-14": "Month-end reconciliation window",
    "2026-08-28": "Month-end reconciliation window",
    "2026-09-01": "Quarter-close preparation",
}


# ============================================================
# Tools
# ============================================================


@mcp.tool()
def standards_list() -> str:
    """List the engineering standards that exist, as a short index.

    Call this FIRST. Use it to decide which standard you need before pulling
    the full text with standard_get, which is much larger.
    """
    index = [
        {"key": k, "title": v["title"], "version": v["version"],
         "scope": v["scope"], "clause_count": len(v["clauses"])}
        for k, v in STANDARDS.items()
    ]
    return json.dumps(index, ensure_ascii=False, indent=2)


@mcp.tool()
def standard_get(key: str) -> str:
    """Return the full text of one engineering standard.

    Use when you need the exact wording of a rule — for example before telling
    the user whether their code complies. Call standards_list first if you do
    not already know the key.

    Args:
        key: a key from standards_list, e.g. "java-service".
    """
    standard = STANDARDS.get(key)
    if not standard:
        return json.dumps(
            {"error": f"'{key}' not found.", "available": sorted(STANDARDS)},
            ensure_ascii=False,
        )
    return json.dumps(standard, ensure_ascii=False, indent=2)


@mcp.tool()
def api_search(keyword: str = "", pii_free_only: bool = False) -> str:
    """Search the internal API catalogue.

    Use when the user asks which internal service does something, who owns a
    service, or which services are safe to integrate with from a data
    protection point of view.

    Args:
        keyword: text to match against service name, description or owner.
            Empty returns everything.
        pii_free_only: when True, services holding personal data are excluded.
    """
    term = keyword.lower().strip()
    results = []
    for key, service in API_CATALOGUE.items():
        if pii_free_only and service["contains_pii"]:
            continue
        haystack = f"{key} {service['name']} {service['description']} {service['owner_team']}".lower()
        if not term or term in haystack:
            results.append({"key": key, **service})
    return json.dumps(
        {"found": len(results), "services": results}, ensure_ascii=False, indent=2
    )


@mcp.tool()
def can_deploy(target_date: str = "") -> str:
    """Check whether a production release is permitted on a given date.

    Use before planning or announcing a deployment. Returns the reason as well
    as the verdict, so the answer can be quoted back to the user.

    Args:
        target_date: YYYY-MM-DD. Empty means today.
    """
    try:
        day = date.fromisoformat(target_date) if target_date else date.today()
    except ValueError:
        return json.dumps(
            {"error": f"Invalid date format: '{target_date}'. Expected YYYY-MM-DD"},
            ensure_ascii=False,
        )

    key = day.isoformat()
    if key in DEPLOY_FREEZE_DAYS:
        return json.dumps({
            "date": key, "can_deploy": False, "reason": DEPLOY_FREEZE_DAYS[key],
        }, ensure_ascii=False)

    if day.weekday() >= 5:
        return json.dumps({
            "date": key, "can_deploy": False,
            "reason": "Weekend — outside the planned release window.",
        }, ensure_ascii=False)

    return json.dumps({
        "date": key, "can_deploy": True,
        "note": "Calendar is open. Team approval and a change record are still required.",
    }, ensure_ascii=False)


@mcp.tool()
def tool_cost() -> str:
    """Report roughly how much context this server's own tool schemas occupy.

    This tool is here to teach. Connecting an MCP server is not free: every
    tool's name, description and schema is sent to the model on EVERY request
    made while that server is connected. Connecting ten servers and leaving
    them all on adds a fixed toll to every question anyone asks.
    """
    tools = []
    total_chars = 0
    for name, fn in (
        ("standards_list", standards_list),
        ("standard_get", standard_get),
        ("api_search", api_search),
        ("can_deploy", can_deploy),
        ("tool_cost", tool_cost),
    ):
        target = getattr(fn, "fn", fn)
        doc = (target.__doc__ or "").strip()
        chars = len(name) + len(doc)
        total_chars += chars
        tools.append({"tool": name, "description_chars": len(doc),
                      "approx_tokens": max(1, chars // 3)})

    return json.dumps({
        "server": "corp-internal",
        "tool_count": len(tools),
        "tools": tools,
        "approx_total_tokens": max(1, total_chars // 3),
        "warning": (
            "This is a rough estimate only; the real token count is higher once "
            "the JSON schemas are serialised. The lesson holds: every additional "
            "tool makes every request more expensive. Disconnect servers you are "
            "not using."
        ),
        "measured_at": datetime.now().isoformat(timespec="seconds"),
    }, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    mcp.run()
