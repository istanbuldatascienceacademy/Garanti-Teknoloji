# Copilot, MCP and Token Economics — workshop repository

One-day workshop materials. Runs offline: no API keys, no network calls in the
tests.

## Quick start

```bash
python3 -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt
python -m pytest tests -q            # 28 passed
python cost/scenarios.py             # the before/after cost table
```

Then set the interpreter path in `.vscode/mcp.json`:

```bash
which python                         # copy this into "command"
```

Plain `python` will resolve to whatever is first on PATH and the server will
fail silently, with an empty output channel. Lab 2 Step 1 covers this in full.

Open the folder in VS Code (trust the workspace), put the chat in the **Agent**
role, and run **MCP: List Servers** to start `corp-internal`.

## Layout

```
.github/
  copilot-instructions.md            always-on, ~290 tokens
  instructions/*.instructions.md     scoped with applyTo
  prompts/*.prompt.md                called with /command
  chatmodes/analyst.chatmode.md      reading mode, restricted tools
.vscode/mcp.json                     MCP server definition
mcp_server/corp_server.py            working server, 5 tools, no PII
cost/calculator.py                   rate table + cost engine
cost/scenarios.py                    before/after scenario comparison
labs/*.md                            lab guides (TR), labs/en/ for English
tests/                               28 tests, offline
INSTRUCTOR-RUNBOOK.md                how to run the day
```

## Labs

Participant guides are in Turkish under `labs/`. English versions of the same
four labs are in `labs/en/`.

| Lab | Duration | Topic |
|---|---|---|
| [1](labs/LAB-1-talimat-dosyalari.md) | 45 min | Instruction files, applyTo, prompt files, chat modes |
| [2](labs/LAB-2-mcp-sunucusu.md) | 60 min | Connecting and writing an MCP server (split track) |
| [3](labs/LAB-3-olcum.md) | 45 min | Finding your real number, verifying three thresholds |
| [4](labs/LAB-4-optimizasyon.md) | 60 min | Cutting the always-on file, routing, before/after |

Full verbatim script (what to actually say, sentence by sentence):
[`SUNUM-TAM-METIN.md`](SUNUM-TAM-METIN.md) (Turkish).

Slide-by-slide speaker guide: [`SUNUM-KILAVUZU.md`](SUNUM-KILAVUZU.md) (Turkish).

Instructor answer key for every discussion question: [`labs/EGITMEN-CEVAP-ANAHTARI.md`](labs/EGITMEN-CEVAP-ANAHTARI.md) (Turkish).

## Before you present

Prices change. Verify the `RATES` dictionary in `cost/calculator.py` against
`docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing`, and
set `SEATS` in `cost/scenarios.py` to the client's real team size.
