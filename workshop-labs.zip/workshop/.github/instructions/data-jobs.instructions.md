---
description: Rules for Python data jobs
applyTo: "**/*.py"
---

# Python data job rules

- Type hints are required.
- Money and rate calculations use `Decimal`; never floating point.
- DataFrames holding personal data are not written to disk; if they must be, mask first.
- Long-running jobs are idempotent — re-running must not corrupt data.
- Do not use chained assignment in pandas.
