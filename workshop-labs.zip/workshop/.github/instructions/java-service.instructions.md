---
description: Detailed rules for Spring Boot service code
applyTo: "**/*.java"
---

# Java service rules

This file loads only when a `.java` file is in play. You do not pay for these
tokens while working on Python — that is exactly what `applyTo` is for.

## Layers

- `Controller`: validation and routing only. No business logic.
- `Service`: business logic. Minimal dependency on framework annotations.
- `Repository`: data access. Contains no business rules.

## Requirements

- A new endpoint updates the OpenAPI schema in the same pull request.
- External service calls set an explicit timeout (3 seconds by default).
- Return `Optional`; never return `null`.
- Define a dedicated exception class for recoverable errors.

## Testing

- Every `Service` class requires a unit test.
- Tests do not connect to a real database; use Testcontainers or a fake.
- Test names describe behaviour: `rejectsWhenReturnWindowHasClosed`.
