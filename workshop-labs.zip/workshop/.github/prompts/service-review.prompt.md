---
description: Reviews a service class against the corporate standards
mode: agent
---

# Service review

Review the selected service class against the corporate standards.

Steps:

1. Call `standard_get("java-service")` on the `corp-internal` MCP server.
   If the server is not connected, say so and continue with general rules.
2. Check the class against every clause of the standard.
3. Report findings in this table:

   | Clause | Status | Line | Suggestion |

   Status: OK · SUSPECT · VIOLATION

4. Write fix code only for VIOLATION rows. Ask about SUSPECT rows; do not fix them.

**Do not modify the code.** Show the report first and wait for approval.
