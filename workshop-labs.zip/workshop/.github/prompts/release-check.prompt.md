---
description: Runs the pre-release checklist
mode: agent
---

# Release readiness check

1. Call `can_deploy` for the target date. If the calendar is closed, stop and
   report the reason; do not run the checklist.
2. If it is open, check each item and give evidence as `file:line`:
   - Is the OpenAPI schema current for every changed endpoint?
   - Does every new external call set a timeout?
   - Do any log statements carry a customer identifier?
   - Does every new `Service` class have a test?
3. Return the result as a short checklist. Do not modify code.
