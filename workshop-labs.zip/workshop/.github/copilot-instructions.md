# Engineering instructions

This file is added to the context of **every Copilot Chat request**. Keeping it
short is not a style preference — it is a budget decision. Every line here is
re-paid on every request, by everyone. Detail belongs in the scoped files under
`instructions/`.

## Context

Java/Spring Boot microservices for banking, plus Python data jobs.

## Invariants

- Monetary amounts use `BigDecimal`, never `double` or `float`.
- No customer identifiers in logs (national ID, card number, account number, IBAN).
- SQL is parameterised; never build a query by string concatenation.
- External calls must set an explicit timeout.
- Secrets live in configuration, never in code.

## If you do not know, ask

Do not invent the corporate standard. If the `corp-internal` MCP server is
connected, call `standard_get`. If it is not, ask the user which standard applies.
