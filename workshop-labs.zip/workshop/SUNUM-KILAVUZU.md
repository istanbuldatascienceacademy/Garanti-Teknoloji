# Eğitmen sunum kılavuzu — 60 slayt

Slayt slayt anlatım rehberi. Her slaytta: süre, ekranda ne olduğu, ne söyleneceği
ve dikkat edilecek nokta.

**Nasıl kullanılır:** bunu ezberlenecek metin değil, tempo tutucu olarak kullan.
"Söyle" kısımları kelime kelime okunacak cümleler değil, vurulması gereken
noktalar. Kendi örneklerin her zaman daha iyidir.

## Zaman bütçesi

| Blok | Saat | Slayt | Süre | Slayt başına |
|---|---|---|---|---|
| Açılış | 09:00–09:30 | 1–8 | 30 dk | ~3,5 dk |
| M1 Talimat dosyaları | 09:30–10:15 | 9–20 | 45 dk | ~3,5 dk |
| M2 MCP | 11:15–11:45 | 21–34 | 30 dk | ~2 dk |
| M3 Token ekonomisi | 13:45–14:15 | 35–46 | 30 dk | ~2,5 dk |
| M4 Optimizasyon | 15:15–15:30 | 47–55 | 15 dk | ~1,5 dk |
| Kapanış | 16:30–17:00 | 56–60 | 30 dk | — |

**En sıkışık blok M4.** Aşağıda hangi slaytların hızlı geçileceği işaretli.
Geç kalırsan sıkıştırılacak yerler: 15, 17, 31, 33, 50.

---

# AÇILIŞ — Slayt 1–8 (09:00–09:30)

## Slayt 1 — Başlık

**2 dk** · Ekranda: başlık, alt başlık ve gün bilgisi.

**Söyle:** Kendini tanıt, kısa tut. Günün tek cümlesini oku: *"Bağlam bir
bütçedir."* Sonra üç açıyı söyle — ne gönderdiğin, neyi açtığın, ne ödediğin.

Günün ritmini duyur: dört anlatım, dört lab, kapanışta grup çalışması. Labların
kendi makinelerinde olduğunu ve öğleden sonra kendi gerçek rakamlarını
bulacaklarını söyle.

**Dikkat:** burada slayt okuma. İlk iki dakika oda seni tartıyor.

---

## Slayt 2 — Günün akışı

**2 dk** · Ekranda: saat saat program tablosu.

**Söyle:** Blokları hızlıca geç. İki şeyi vurgula: molalar korunacak, ve 16:30'da
yazacakları dört sayfa günün asıl çıktısı.

**Dikkat:** tabloyu satır satır okuma. "Sabah dosyalar ve MCP, öğleden sonra para
ve optimizasyon" yeterli.

---

## Slayt 3 — Tek fikir, üç açı

**3 dk** · Ekranda: "Context is a budget" + üç kart.

**Söyle:** Üç kartı sırayla aç.

*Ne gönderdiğin* — talimat dosyaları, prompt dosyaları, sohbet modları. Her
istekte yükleniyor, kimse okumasa da.

*Neyi açtığın* — MCP sunucuları ve araç şemaları. Bağlı her sunucu her soruya
sabit bir harç ekliyor.

*Ne ödediğin* — girdi, çıktı, önbellek. Modele göre fiyatlanıyor ve fatura
varlığı düzeyinde havuzlanıyor.

Kapat: sohbet geçmişi, eklenen dosyalar, araç çıktıları — hepsi **her turda**
yeniden gönderiliyor ve yeniden ödeniyor.

**Dikkat:** Bu slayt günün omurgası. Dört modül bu üç açının açılımı. Acele etme.

---

## Slayt 4 — 1 Haziran 2026'da ne değişti

**4 dk** · Ekranda: önce/sonra tablosu.

**Söyle:** Satır satır git, ama iki satırda dur.

*Kod tamamlama artık ölçülmüyor* — ücretli planlarda sınırsız. Bu, günün en
kolay kazancı ve çoğu kişi bilmiyor.

*Kontrol edebildiğin şey değişti* — eskiden "ne sıklıkla soruyorsun", şimdi "her
soru ne kadar bağlam taşıyor". Alışkanlık değişimi burada.

**Söyle ayrıca:** fiyatlar ve plan detayları değişiyor; bu tabloyu GitHub Docs'tan
doğruladım, siz de doğrulayın.

**Dikkat:** Bu odada fiyat bilen insanlar var. Kaynağı söylemek güven kazandırır.

---

## Slayt 5 — Aynı iş, aynı kişiler, üç fiyat

**5 dk** · Ekranda: üç senaryo grafiği + yüzde kartları.

**Söyle:** 120 kişilik ekip, 21 iş günü, Business koltuk. Aynı iş, üç farklı
kurulum: $3.064, $1.334, $456. Havuz kullanımı %134, %58, %20.

İlk senaryo aşımda. Üçüncüsü havuzun beşte birini kullanıyor. Yıllık fark
yaklaşık $31.000.

**Kritik cümle:** *"Bu rakamlar modellenmiş kullanım varsayımlarına dayanıyor.
Kendi gerçek rakamınızı Lab 3'te bulacaksınız."*

**Dikkat:** Bunu söylemezsen kıdemli mühendisleri günün geri kalanında
kaybedersin. Abartma; bu oda kontrol eder.

---

## Slayt 6 — Hangisindesiniz?

**2 dk** · Ekranda: tek soru, koyu zemin.

**Söyle:** Soruyu sor. **Sonra sus.**

Sessizlik uzun gelecek. Bırak uzasın. Çoğu oda cevap veremez ve günün gerekçesi
tam olarak bu.

Ardından: "15:00'te kendi kullanım raporunuzu çekmiş, kendi ekip büyüklüğünüzle
hesabı yapmış ve üç eşiği de canlı doğrulamış olacaksınız."

**Dikkat:** Sessizliği doldurma. En etkili slayt bu ve etkisi susmandan geliyor.

---

## Slayt 7 — 17:00'de neler yapabileceksiniz

**2 dk** · Ekranda: beş kazanım, laba bağlı.

**Söyle:** Hızlı geç. Her kazanımın bir laba karşılık geldiğini söyle. Beşincide
dur: kurumlarının benimseyebileceği bir kullanım politikası taslağıyla
çıkacaklar.

---

## Slayt 8 — Başlamadan önce

**3 dk** · Ekranda: üç kart, sonuncusu kırmızı.

**Söyle:** İlk iki kartı hızlı geç. Kırmızı kartta dur: **MCP yalnızca Agent
modunda çalışır.** Kurumsal politikada kapalıysa günün yarısı çalışmaz.

Şimdi sor: "Kim şu an makinesinde VS Code'u açıp Agent modunu görebiliyor?"
El kaldıranları say. Sorun varsa **şimdi** öğren, 11:45'te değil.

**Dikkat:** Bu, önceden çözülmüş olması gereken bir şey. Yine de burada teyit et
— politika bir gecede değişebiliyor.

---

# M1 — TALİMAT DOSYALARI — Slayt 9–20 (09:30–10:15)

## Slayt 9 — Bölüm 01 ayracı

**1 dk** · Ekranda: "What you send: instruction files".

**Söyle:** Bu bölüm neden ilk? Çünkü en ucuz değişiklik ve etkisi en geniş.
Kimseden izin almadan bugün yapabileceğiniz şey burada.

---

## Slayt 10 — Dört dosya, dört iş

**4 dk** · Ekranda: dosya türü tablosu.

**Söyle:** Dört dosyanın farkı **ne zaman yüklendikleri**, dolayısıyla ne kadar
maliyet ettikleri.

`copilot-instructions.md` her istekte. `*.instructions.md` sadece `applyTo`
eşleştiğinde. `*.prompt.md` sadece `/komut` yazınca. `*.chatmode.md` sadece modu
seçince.

Karar kuralını oku ve tahtaya yaz: **her soruda gerekli değilse, always-on
dosyaya girmez.**

---

## Slayt 11 — Bu kural nereye gider?

**3 dk** · Ekranda: karar ağacı.

**Söyle:** Tepedeki soruyla başla: bu kural her dosya türünde geçerli mi?
Evetse always-on. Hayırsa üç dala bak.

Son satırı vurgula: dört sorunun da cevabı hayırsa o içerik ekip wiki'sine
gider, repoya değil.

**Dikkat:** Katılımcılar kendi dosyalarını düşünmeye başlayacak. İyi işaret;
Lab 1'de bunu yapacaklar.

---

## Slayt 12 — copilot-instructions.md

**4 dk** · Ekranda: kod bloğu + iki kart.

**Söyle:** Dosyayı satır satır oku. Altı invariant var, hepsi dil bağımsız,
hepsinin ihlali pahalı.

Son bölüme dikkat çek: *"Bilmiyorsan sor."* Modelin kurum standardını
uydurmasını engelleyen tek satır bu ve tek başına yerini hak ediyor.

Yeşil/kırmızı kartlar: ne yer bulur, ne bulmaz. Framework öğreticileri, stil
tercihleri, onboarding metni — hiçbiri buraya ait değil.

---

## Slayt 13 — Always-on dosyayı denetlemek

**4 dk** · Ekranda: tek soru + üç kart.

**Söyle:** Soruyu yüksek sesle oku: *"Ekibimin sorduğu soruların yüzde kaçında
bu satır gerçekten gerekli?"*

%80 üstü kalır. %20–80 kapsamlı dosyaya gider. %20 altı prompt dosyasına.

Hedefi söyle: **500 token altı.** İnemiyorsan dosyayı wiki gibi kullanıyorsun.

**Dikkat:** "Bizimki 2.000 token" diyen çıkacak. Savunmaya itme — "Lab 1'de
birlikte keseceğiz" de ve geç.

---

## Slayt 14 — applyTo

**4 dk** · Ekranda: kod bloğu + canlı test + iki kart.

**Söyle:** Bir Java kuralı, Python yazarken hiçbir şeye mal olmamalı. `applyTo`
bunu yapıyor.

Canlı testi anlat: `.py` dosyasında sor, `.java` dosyasında aynı soruyu sor,
farkı gör. Lab 1'de yapacaklar.

İki kartı vurgula: bu hem maliyet hem **kalite** kazancı. Bağlamda daha az
alakasız kural, modelin yanlış kuralı uygulama ihtimali daha düşük. Takas değil.

**Dikkat:** "Ucuz ama kötü" endişesini burada ön alıyorsun. Bu argümanı sakla,
slayt 54'te tekrar lazım olacak.

---

## Slayt 15 — Prompt dosyaları

**3 dk** · Ekranda: kod bloğu + üç özellik. *Geç kalırsan sıkıştır.*

**Söyle:** Haftada ikiden fazla tekrar ettiğin her şey buraya ait.

Üç özelliği say: çok adımlı, açık çıktı biçimi, sonunda bir duruş. Sonuncuyu
açıkla — "önce raporu ver, onay bekle". Düzeltmeden önce incelemek, geri
almaktan ucuz.

Kapat: prompt dosyası **sadece çağırdığında** yükleniyor. Bu yüzden uzun,
detaylı, nadir gereken her şeyin doğru evi burası.

---

## Slayt 16 — Sohbet modları

**4 dk** · Ekranda: analyst.chatmode.md + iki kart.

**Söyle:** Mod, asistanın kim olduğunu ve hangi araçlara dokunabileceğini
değiştiriyor.

**Canlı göster:** analist moduna geç, kod yazmasını iste, reddedişini odaya
izlettir. Sınırını tutan bir mod, anlattığın bir moddan çok daha ikna edici.

İki kartı bağla: analist okuyan bir asistan kazanıyor; finans ise `tools`
alanının araç erişimini kısıtlamasını — az araç, az şema, ucuz ve odaklı cevap.

**Dikkat:** Odadaki analistler buraya kadar biraz dışarıda kalmış hissedebilir.
Bu slayt onların slaytı; onlara bakarak anlat.

---

## Slayt 17 — Atlanan üç şey

**3 dk** · Ekranda: AGENTS.md, org düzeyi, /init. *Geç kalırsan sıkıştır.*

**Söyle:** `AGENTS.md` — birden fazla aracın okuduğu taşınabilir dosya. Kurum tek
asistanda standartlaşmadıysa işe yarar.

**Organizasyon düzeyi talimatlar** — asıl kaldıraç bu. 120 repoda tek tanım, 120
kopyanın birbirinden ayrışmasına yeğdir.

`/init` — mevcut repoyu analiz edip taslak üretir. Kesilecek başlangıç noktası,
teslim edilecek ürün değil.

Kapat: talimatları merkezîleştirmek, yanlış yapmanın maliyetini de
merkezîleştirir. Sahiplik org düzeyinde daha da önemli.

---

## Slayt 18 — 1.000 boşa token ne eder

**4 dk** · Ekranda: çarpanlar + $600/yıl.

**Söyle:** Hesabı odayla birlikte yap. 120 kişi × 4 istek × 21 gün × 1.000 fazla
token = ayda 10,1 milyon token. Güçlü modelde ~$50/ay, $600/yıl.

**Kritik cümle:** *"Kimsenin okumadığı satırlar için."*

Son satırı oku: rakam görmezden gelinecek kadar küçük, utandıracak kadar büyük.
Yıllarca hayatta kalmasının sebebi tam olarak bu.

**Dikkat:** "$600 mü? Değmez" diyen çıkarsa: tek başına değmez, ama bu tek bir
dosya ve yedi kaldıraç var. Slayt 46'da geri döneceksin.

---

## Slayt 19 — Bu dosya kod mu, politika mı?

**3 dk** · Ekranda: üç soru + işleyen model.

**Söyle:** Bir geliştirici satır eklediğinde maliyet ekibin tamamına biniyor.

Üç soruyu sor, cevap bekleme — Lab 1'in tartışma sorusu bu. İşleyen modeli oku:
isimli sahip, dosyanın kendi başlığında token bütçesi, çeyreklik gözden geçirme.

**Dikkat:** Cevap anahtarındaki Lab 1 bölümü burada işine yarar. Ama tartışmayı
laba sakla, şimdi başlatma — yoksa program kayar.

---

## Slayt 20 — Lab 1 brifingi

**3 dk** · Ekranda: hedef, beş adım, çıktılar, tartışma sorusu.

**Söyle:** Beş adımı hızlıca geç. İki şeyi vurgula:

**Adım 1 önce ölçüyor.** Talimat dosyasını önce eklerseniz farkı hiç göremezsiniz.
Bugün yapacağınız her ölçümde bu sıra geçerli.

**Her soruda yeni sohbet.** İkisini tek sohbette sorarsanız ilk cevap hâlâ
bağlamda ve ikincisi kirlenir. Lab 3'te aynı hata bütün ölçümü bozar.

**Dikkat:** Adım 2'deki "hangi satırlar gerçekten gerekli" tartışması labın
kendisi. Aceleyle geçmelerine izin verme; dolaşırken buna zaman ayırt.

---

# M2 — MCP — Slayt 21–34 (11:15–11:45)

> Bu blok 30 dakikada 13 slayt. Tempo hızlı olacak. 24, 25, 26 numaralı banka
> slaytları asla sıkıştırılmaz; gerekirse 31 ve 33'ten kısarsın.

## Slayt 21 — Bölüm 02 ayracı

**1 dk** · **Söyle:** Şimdi "neyi açtığınız" tarafına geçiyoruz. Bankada bu
bölüm teknik değil, kurumsal bir konu.

---

## Slayt 22 — MCP nedir

**3 dk** · Ekranda: üç ilkel + Copilot uyarısı.

**Söyle:** Modelin dış dünyayla konuşması için standart arayüz. Üç ilkel: tools,
resources, prompts.

Sonra koyu kutuyu oku: **Copilot yalnızca tools kullanıyor.** Resources ve
prompts desteklenmiyor. Değeri yayımladığı kaynaklarda olan bir sunucu
bağlarsanız o içerik hiç görünmez — ve size kimse söylemez.

**Dikkat:** Bu, satın alma kararını etkileyen bir bilgi. Vurgulanmaya değer.

---

## Slayt 23 — Mimari ve taşıyıcılar

**3 dk** · Ekranda: üç kutu diyagramı + taşıyıcı tablosu.

**Söyle:** Sunucu ayrı bir süreç. stdio yerelde, http/sse ağda.

Kırmızı kutuyu **tahtaya yaz**: *yerel bir stdio sunucusu, döndürdüğü her şeyi
model sağlayıcısına gönderir.*

**Dikkat:** Bu cümle bir sonraki slaydın kurulumu. Geçiştirme.

---

## Slayt 24 — Yapılandırma iki yerde

**2 dk** · Ekranda: mcp.json + workspace/user ayrımı + komutlar.

**Söyle:** Workspace dosyası repoyla paylaşılır, PR'da incelenir. User dosyası
tek makinede kalır — kimlik bilgisi taşıyan her şey oraya.

Komutları göster: MCP: List Servers, MCP: Restart Server.

**Ekle (sahadan):** `command` alanına düz `python` yazmayın, tam yol yazın.
Yanlış yorumlayıcı seçilirse süreç anında ölür ve **output kanalı boş kalır** —
sebebi görünmeyen bir hata. Lab 2 Adım 1 bunu adım adım çözüyor.

---

## Slayt 25 — Agent modu zorunlu

**2 dk** · Ekranda: Ask/Agent tablosu + iki kart.

**Söyle:** Ask modunda MCP araçları çalışmaz. Nokta.

İki kartı dengele: Agent size araç ve çok adımlı yürütme veriyor; karşılığında
her adım birikmiş bağlamı yeniden gönderiyor. **Bir agent koşusu tek istek
değil, çok istektir.** Bütçelerken böyle düşünün.

---

## Slayt 26 — Banka noktası bir: yerel ≠ içeride

**4 dk** · Ekranda: eşitsizlik + üç adım.

**Söyle:** MCP hakkındaki en yaygın ve en pahalı yanlış anlama bu.

Üç adımı yavaş git: araç çıktısı bağlama giriyor → bağlam sağlayıcıya gidiyor →
dolayısıyla araç bir **veri yolu**.

Kapat: bir MCP aracı sessizce sınırınızın dışına veri taşıyan bir kanala
dönüşebilir. Bu kurumsal bir karar, geliştirici kararı değil.

**Dikkat:** M2'nin en önemli slaytı. Acele etme. Odaya sor: "kurumunuzda bu
kararı kim verir?"

---

## Slayt 27 — Banka noktası iki: onay akışı denetim izidir

**3 dk** · Ekranda: üç kart + koyu kutu.

**Söyle:** Copilot her araç çağrısından önce soruyor. O istem göründüğünden fazla
iş yapıyor.

Per-call onay = insanın verdiği kararların kaydı. Auto-approve = faaliyetin
kaydı; inceleyen kişi niyeti otomasyondan ayıramaz.

Orta yol: salt-okunur araçlar otomatik onaylanabilir. Yazan veya düzenlemeye tabi
veriye dokunan araçlar **asla**.

Koyu kutuyu oku ve odaya sor: denetçi geçen ay hangi verinin araç çağrısıyla
sınır dışına çıktığını sorsa, kim cevap verebilir?

---

## Slayt 28 — Banka noktası üç: onaylı liste

**3 dk** · Ekranda: üç model tablosu + üç soru.

**Söyle:** Serbest kurulum bankaya uymaz. Tamamen merkezî de uymaz — ekipler
etrafından dolaşır. Doğru varsayılan **onaylı liste**.

Onay sürecinin yanıtlaması gereken üç soru: ne döndürüyor, kim sahibi, kim
bağlayabilir.

---

## Slayt 29 — Araç bütçesi

**3 dk** · Ekranda: sunucu/şema grafiği + üç kart.

**Söyle:** Bağlı her sunucu şemalarını **her isteğe** ekliyor — kullansanız da
kullanmasanız da.

Grafiği oku: 10 sunucu × 8 araç = 80 şema, her soruda. Copilot'un tavanı 128 ama
kalite bozulması çok önce başlıyor, çünkü model bunlar arasından seçmek zorunda.

Kural: bugün kullanmadığınız sunucuyu kapatın. Tek tıklık değişiklik, kalıcı etki.

---

## Slayt 30 — Neden müşteri verisi yok

**3 dk** · Ekranda: iki kart + koyu kutu.

**Söyle:** Bankaya MCP sunucusu yazarken ilk akla gelen fikir genelde yanlış
olanıdır. Customer 360 teknik olarak kolay, kurumsal olarak ağır.

Bunun yerine: mühendislik standartları, API kataloğu, sürüm takvimi. Kişisel veri
yok, gerçekten faydalı, günde birkaç kez gerekiyor.

Koyu kutuyu oku: kataloğumuz bir servisin kişisel veri **içerdiğini söyler**,
verinin kendisini vermez. Hassas verinin nerede olduğunu tarif etmek, onu
taşımaktan farklı bir eylemdir.

---

## Slayt 31 — Bağlayacağınız beş araç

**2 dk** · Ekranda: beş araç listesi. *Geç kalırsan sıkıştır.*

**Söyle:** Hızlı geç, labda kullanacaklar. İki tasarım kararını işaret et:

`standards_list` sadece indeks döndürüyor, tam metni değil — iki aşamalı erişim,
pahalı çağrıyı bilinçli kılıyor.

`tool_cost` öğretmek için var: bu sunucunun kendi harcını görünür kılıyor.

---

## Slayt 32 — Docstring arayüzdür

**3 dk** · Ekranda: kötü/iyi örnek + üç kart.

**Söyle:** Model araç seçimini açıklamaları okuyarak yapıyor. Seçmek zorunda olan
okuyucu için yaz.

Kötü: "Servis sahibi bilgisini döndürür." Doğru ve karar vermek için işe yaramaz.

İyi: "Bir servisten sorumlu ekip gerektiğinde kullan — kayıt açmadan veya
yükseltmeden önce. Kısmi isim varsa önce api_search çağır."

Üç kartı say: faydalı biçimde başarısız ol, gerekçe döndür, açıklamaları kısa
tut — her kelime her istekte yeniden gönderiliyor.

---

## Slayt 33 — Protokolü değil mantığı test et

**2 dk** · Ekranda: test kodu + üç not. *Geç kalırsan sıkıştır.*

**Söyle:** Araçları düz Python fonksiyonu olarak test edin. Taşıyıcıyı VS Code
zaten test ediyor.

İki testi göster: "indeks tam metin döndürmez" bir maliyet kararının teste
dönüşmüş hâli; "hiçbir araç kişisel veri döndürmez" ise bir politikanın CI'ın
zorladığı bir şeye dönüşmüş hâli.

---

## Slayt 34 — Lab 2 brifingi

**2 dk** · Ekranda: hedef, beş adım, çift kol.

**Söyle:** Adım 1'e 15 dakika ayırın ve atlamayın — kurulum burada kazanılıyor
veya kaybediliyor.

İki kolu duyur. **Analist kolunun kolay olmadığını açıkça söyle:** "hangi araç
yazılmamalı" sorusu daha zor ve bankada asıl önemli olan o. Analist grubu
değerlendirmede ilk sunacak.

---

# M3 — TOKEN EKONOMİSİ — Slayt 35–46 (13:45–14:15)

> Öğle sonrası blok. Enerji düşük olur; grafikli slaytlarla (38, 40, 42, 44)
> tempoyu koru.

## Slayt 35 — Bölüm 03 ayracı

**1 dk** · **Söyle:** Sabah ne gönderdiğinizi ve neyi açtığınızı konuştuk. Şimdi
faturaya bakıyoruz.

---

## Slayt 36 — Sayaç nasıl çalışıyor

**3 dk** · Ekranda: üç kart + yeşil kutu.

**Söyle:** Üç şey sayılıyor: girdi, çıktı, önbellekli girdi. Çıktı her modelde
girdiden birkaç kat pahalı.

Yeşil kutuda dur: **kod tamamlama ölçülmüyor.** Ücretli planlarda sınırsız.
Sadece sohbet, agent koşuları ve kod incelemesi sayılıyor.

**Dikkat:** Bu, günün en kolay kazancı. Odaya sor: "kaçınız satır içi
tamamlamayla halledilebilecek bir şeyi sohbete yapıştırıyor?"

---

## Slayt 37 — Kredinin aritmetiği

**2 dk** · Ekranda: 1 kredi = $0,01 + örnek hesap.

**Söyle:** Her şey tek bir dönüşüme iniyor. Örneği birlikte yap: 100K girdi +
3K çıktı = $0,24 = 24 kredi.

Kapat: tek istek önemsiz derecede ucuz. 120 kişi × 4 istek × 21 gün değil. Birim
küçük, çarpan sizin kadronuz.

---

## Slayt 38 — Dahil krediler ve havuzlanma

**3 dk** · Ekranda: $19/$39/Pooled + koyu kutu.

**Söyle:** Koltuk başına dahil kredi Business'ta $19, Enterprise'da $39. Ama
havuz koltuk başına değil — **fatura varlığı düzeyinde toplanıyor**.

120 koltuklu Business = ayda $2.280 dahil kredi. Bir ağır ekip, birkaç hafif
ekibin başlığını tüketebilir ve fatura gelene kadar ikisi de bunu göremez.

**Dikkat:** Bu bir tasarım tercihi, arıza değil. Ama görünürlük olmadan çalışmaz
— sonraki slaydın kurulumu bu.

---

## Slayt 39 — Bütçe kimin?

**3 dk** · Ekranda: üç kart + üç soru.

**Söyle:** Ekip lideri davranışa yakın ama havuzu göremiyor. Platform ekibi
havuzu görüyor ama işe uzak. Doğru cevap ikisi, bir ritimle.

Üç soruyu oku ve bırak: kim okuyor, aşımda ilk hangi veri isteniyor, ay sonundan
önce birine haber veriliyor mu.

**Dikkat:** Lab 3'ün tartışma sorusu bu. Cevap anahtarında veri isteme sırası
var — kişi bazlı tüketimle başlamak konuyu performans değerlendirmesine çevirir.

---

## Slayt 40 — Milyon token başına girdi fiyatı

**2 dk** · Ekranda: yedi model çubuk grafiği.

**Söyle:** Aynı soru, farklı modellerde, aynı iş — çok farklı fiyat. $0,20'den
$5,00'a.

Alt notu oku: çıktı bunun birkaç katı, önbellekli girdi onda biri. Fiyatları
kendiniz doğrulayın.

---

## Slayt 41 — Eşik bir: model seçimi

**3 dk** · Ekranda: $0,20 — 25× — $5,00.

**Söyle:** Fiyat listesindeki en geniş uçurum ve kapatması en kolay olanı.

Bir fonksiyonu açıklamak, PR açıklaması yazmak, tutarlı yeniden adlandırma —
hiçbiri muhakeme problemi değil.

**Kritik cümle:** rutin işi hafif modele yönlendirmek, emek/tasarruf oranı en iyi
tek değişiklik.

---

## Slayt 42 — Eşik iki: önbellek

**3 dk** · Ekranda: grafik + üç kart.

**Söyle:** Değişmeyen bağlam girdi fiyatının onda birine geliyor.

Önbelleğe ne düşer: talimat dosyaları, araç şemaları, sohbetin sabit başı.

Ne bozar: talimat dosyasını düzenlemek, ekleri yeniden sıralamak, oturum ortasında
sunucu bağlayıp koparmak. Bağlamın önündeki oynaklık, sonrasındaki her şeyi
geçersiz kılıyor.

**Kritik cümle:** sabit kısmı sabit tutun, değişkeni sona koyun. Sıralama bedava
— sadece bir şeyleri oynatmayı bırakmanız gerekiyor.

---

## Slayt 43 — Önbellek bedava değil

**3 dk** · Ekranda: uyarı + Anthropic fiyat tablosu.

**Söyle:** Anthropic modellerinde önbelleğe **yazmak** düz girdiden pahalı.
Sonnet 5: girdi $2,00, önbellekli $0,20, yazma $2,50.

Yani önbellek, tekrar kullanımda geri dönen bir yatırım. Tekrar tekrar
dokunacağınız bağlamda kesinlikle ucuz; kısa ömürlüde zarar ettirebilir.

**Dikkat:** Bu slaydı **sen gönüllü söyle**, sorulmadan. Odadaki en kıdemli
mühendis bunu zaten biliyor. Kendin söylersen günün geri kalanı için güven
kazanırsın; sorulunca söylersen kaybedersin.

---

## Slayt 44 — Eşik üç: uzun bağlam uçurumu

**3 dk** · Ekranda: grafik + %3,7/%104 + nerede çarpılıyor.

**Söyle:** 272K girdi token'ı geçtiğinizde birim fiyat ikiye katlanıyor. Kademe
yok, uçurum var.

270.000 token $0,576. 280.000 token $1,174. **%3,7 daha çok token, %104 daha çok
para.**

Nerede çarpılıyor: "tüm repoyu bağlama ekle", uzun agent koşuları, pazartesiden
beri kapatılmamış sohbet.

**İtiraf et:** hesaplayıcıyı ilk yazarken testte 1M token kullandım ve beklenen
rakam hiç tutmadı. Kod doğruydu — 1M zaten uzun bağlam kademesindeydi. Oda aynı
hatayı yapacak.

---

## Slayt 45 — Kendi rakamını bul

**2 dk** · Ekranda: Settings → Billing → Usage + üç kart.

**Söyle:** Buradan sonrası gerçek rakama dayanıyor, modellenmişe değil.

Üç soruyu göster: kaç kredi, hangi modeller, dahil kredinin yüzde kaçı.

Kırmızı kutuyu oku: *tahminle bütçe kurmak, ölçmemenin kibarcasıdır.*

---

## Slayt 46 — Lab 3 brifingi

**2 dk** · Ekranda: hedef, beş adım.

**Söyle:** Adım 1 pazarlığa kapalı. Erişimi olan var mı? Yoksa kendi ekranımı
göstereceğim — ama kurumunuzda **kimin** erişimi olduğunu öğrenin.

Adım 2'de senaryo scriptini kendi ekibinize kalibre edeceksiniz. Rakam tutmuyorsa
hatalı olan hesaplayıcı değil, varsayımlarınız. Kalibrasyonun kendisi
uygulamanın asıl kısmı.

---

# M4 — OPTİMİZASYON — Slayt 47–55 (15:15–15:30)

> **15 dakikada 9 slayt.** En sıkışık blok. 49 ve 50'yi hızlı geç, 51 ve 52'yi
> laba bırak, 54'ü asla atlama.

## Slayt 47 — Bölüm 04 ayracı

**30 sn** · **Söyle:** Ölçtünüz. Şimdi düşürüyoruz.

---

## Slayt 48 — Yedi kaldıraç

**3 dk** · Ekranda: yedi satır, etkiye göre sıralı.

**Söyle:** Listeyi yukarıdan aşağı okuyun. **İlk üçü tasarrufun çoğunu veriyor.**

Her birine bir cümle: doğru yüzey (tamamlama ölçülmüyor), model yönlendirme
(25x'e kadar), bağlam disiplini (her ek her turda yeniden gidiyor), önbellek
sıralaması, araç bütçesi, yeni sohbet refleksi, yeniden deneme maliyeti.

**Ekle:** kaldıraçlar toplanmıyor, **çarpılıyor**. Lab 3'te 25x ile 9x'in 224x
ettiğini göreceksiniz.

---

## Slayt 49 — İlk üçü, pratikte

**2,5 dk** · Ekranda: üç kart, her biri tetik/yerine.

**Söyle:** Alışkanlıkların somut tetiği olur. Üç tetiği oku:

Kodu sohbete yapıştırmak üzereyken → satır içi yap. Model düşünmeden sohbet
açarken → hafif modelle başla, gerekirse yükselt. Dosya yerine klasör eklerken →
sorunun ihtiyacı kadarını ekle.

---

## Slayt 50 — Son dördü, pratikte

**2 dk** · Ekranda: dört kart + koyu kutu. *Sıkıştırılabilir.*

**Söyle:** Kartları hızlı geç, koyu kutuda dur.

**Hangisi dayatılabilir, hangisi öğrenilir?** 4 ve 5 bir ayar veya politika
olabilir. 6 ve 7 alışkanlık — örnek ve geri bildirimle yerleşir, kuralla değil.
Yanlış mekanizma ikisini birden harcar.

---

## Slayt 51 — Always-on dosyayı küçültmek

**2 dk** · Ekranda: ölçüm komutu + 500 token hedefi.

**Söyle:** Komutu göster, labda çalıştıracaklar. Hedef 500 token altı.

Tahmin uyarısını oku: gerçek tokenizasyon modele özgü ve **Türkçe metin aynı
içerik için İngilizceden belirgin fazla token üretiyor**. Rapor edeceğiniz hiçbir
şeyde tahmin kullanmayın.

---

## Slayt 52 — Model yönlendirme tablosu

**2 dk** · Ekranda: tablo + kırmızı uyarı.

**Söyle:** İskeleti göster, labda kendilerininkini yazacaklar.

Kırmızı kutuda dur: **bu tabloyu copilot-instructions.md'ye koymayın.** Günün en
ironik hatası — maliyeti düşürmek için yazılan tablo, her isteğe eklenerek
maliyeti artırır. Üstelik modelin karar vermediği bir şeyi modele anlatır.

---

## Slayt 53 — Önce ve sonra ölç

**1,5 dk** · Ekranda: önce/sonra kartları + dört satırlık tablo.

**Söyle:** Bir gerçek işi iki kez yapın. Tabloyu gösterip **dördüncü satırı**
işaret et: "Cevap kabul edilebilir mi?"

**Dikkat:** Bu tabloyu basılı dağıt. İnsanlar gördükleri tabloyu doldurur.

---

## Slayt 54 — Ucuzlatmak hedef değil

**2 dk** · Ekranda: koyu kutu + üç kart. **Asla atlama.**

**Söyle:** İşi yapamayan bir kurulum üreten optimizasyon, optimizasyon değildir.

Başarısızlık biçimi: fatura düşer, kabul oranı da düşer. İnsanlar işi elle
yapmaya döner, kimse raporlamaz, çünkü herkesin baktığı metrik iyi görünüyordur.

Kontrol: kabul edilebilirliği maliyetle **aynı tabloya** yaz. Kalite düştüyse
değişiklik başarısızdır, ne tasarruf ettirdiği önemli değil.

**Dikkat:** Bu slayt günün dürüstlük teminatı. 15 dakikada sıkışsan bile bunu
tam anlat.

---

## Slayt 55 — Lab 4 brifingi

**1,5 dk** · **Söyle:** Beş adım. Adım 2 günün en iyi tartışmalarını üretiyor,
zaman ayırın. Adım 5'te üç satır yazacaksınız: yarın, bu çeyrek, hâlâ eksik.

---

# KAPANIŞ — Slayt 56–60 (16:30–17:00)

## Slayt 56 — Kapanış atölyesi

**3 dk** · Ekranda: dört kart + koyu kutu.

**Söyle:** Üçer kişilik gruplar, birer sayfa, üçer dakika sunum. Dört başlığı
dağıt.

Koyu kutuyu oku: burada üretilen metin günün kalıcı değeri. Öncesindeki her şey
bunu yazabilmek için hazırlıktı.

**Dikkat:** Dört sayfayı **kimse odadan çıkmadan topla**.

*Ardından 20 dakika grup çalışması + sunumlar.*

---

## Slayt 57 — Tek sayfalık özet

**2 dk** · Ekranda: üç sütun — Dosyalar, MCP, Maliyet.

**Söyle:** Her sütunun son satırı bir kural. Üçünü oku, başka bir şey ekleme.

Bunu basılı dağıt. Masaya konacak kart bu.

---

## Slayt 58 — Bundan sonra ne oluyor

**2 dk** · Ekranda: bu hafta / bu ay / 4–6 hafta.

**Söyle:** Atölye bir etkinlik. Ölçülen bir takip, onu programa dönüştürür.

Bu hafta: dört sayfayı yayımlayın, sahiplerini atayın. Bu ay: ölçüm ritmini
kurun. 4–6 hafta: bugün öngörülen tasarrufla gerçekleşeni karşılaştırın.

---

## Slayt 59 — Neyi götürüyorsunuz

**2 dk** · Ekranda: repo ağacı + üç komut.

**Söyle:** Repo çevrimdışı çalışıyor — anahtar yok, ağ yok, 28 test geçiyor.

Üç komutu göster. Fiyat tablosunu güncellemeleri gerektiğini son kez söyle.

---

## Slayt 60 — Kapanış

**2 dk** · Ekranda: "Context is a budget" + üç zaman dilimi.

**Söyle:** Başladığımız yere dön. Ne gönderdiğinizi, neyi açtığınızı ve ne
ödediğinizi artık biliyorsunuz — ve üçünü de kendi makinenizde ölçtünüz.

Üç eylemi oku: yarın, bu çeyrek, sürekli.

Teşekkür et, soruları al, dört sayfayı topla.

---

# Son kontrol listesi

- [ ] Slayt 5'in rakamları müşterinin gerçek ekip büyüklüğüne göre güncellendi
- [ ] Slayt 40 ve 43'ün fiyatları GitHub Docs'tan doğrulandı
- [ ] Slayt 53'ün tablosu basılı olarak hazır
- [ ] Slayt 57 basılı olarak hazır
- [ ] Cevap anahtarı okundu (`labs/EGITMEN-CEVAP-ANAHTARI.md`)
- [ ] Slayt 16'nın canlı demosu (analist modu reddi) prova edildi
- [ ] Slayt 8'de Agent modu teyidi için yer bırakıldı
