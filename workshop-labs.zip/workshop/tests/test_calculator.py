"""Tests for the cost calculator."""

import math

import pytest

from cost.calculator import (
    Interaction,
    TeamProfile,
    compare,
    estimate_tokens,
    model_table,
)


def test_basic_cost():
    # GPT-5.6 Terra standard tier: input $2.00/1M, output $12.00/1M.
    # Must stay UNDER the 272K threshold or the long-context price applies.
    i = Interaction("gpt-5.6-terra", input_tokens=100_000, output_tokens=100_000)
    assert math.isclose(i.cost_usd(), 0.20 + 1.20, rel_tol=1e-9)


def test_credit_conversion():
    # 1 AI credit = $0.01 -> 100K input = $0.20 = 20 credits
    i = Interaction("gpt-5.6-terra", input_tokens=100_000)
    assert math.isclose(i.credits(), 20.0, rel_tol=1e-9)


def test_cached_input_is_ten_times_cheaper():
    full = Interaction("gpt-5.6-terra", input_tokens=100_000).cost_usd()
    cached = Interaction("gpt-5.6-terra", cached_input_tokens=100_000).cost_usd()
    assert math.isclose(full / cached, 10.0, rel_tol=0.01)


def test_crossing_the_threshold_doubles_the_price():
    """The sharpest example in the workshop: 272K + 1 token doubles the bill.

    This test documents a trap. The first version of the calculator was tested
    with 1M tokens and the expected figure never matched. The code was right —
    1M was already in the long-context tier.
    """
    under = Interaction("gpt-5.6-terra", input_tokens=272_000)
    over = Interaction("gpt-5.6-terra", input_tokens=273_000)
    assert under.breakdown()["long_context"] is False
    assert over.breakdown()["long_context"] is True
    assert over.cost_usd() / under.cost_usd() > 1.9


def test_model_without_a_threshold_is_unaffected():
    small = Interaction("gpt-5-mini", input_tokens=100_000).cost_usd()
    large = Interaction("gpt-5-mini", input_tokens=1_000_000).cost_usd()
    assert math.isclose(large / small, 10.0, rel_tol=1e-9)


def test_anthropic_cache_write_is_added():
    without = Interaction("claude-sonnet-5", input_tokens=1_000_000).cost_usd()
    with_write = Interaction("claude-sonnet-5", input_tokens=1_000_000,
                             cache_write_tokens=1_000_000).cost_usd()
    assert math.isclose(with_write - without, 2.50, rel_tol=1e-9)


def test_cache_write_ignored_on_models_without_it():
    a = Interaction("gpt-5.6-terra", input_tokens=1000).cost_usd()
    b = Interaction("gpt-5.6-terra", input_tokens=1000, cache_write_tokens=99_999).cost_usd()
    assert math.isclose(a, b)


def test_model_choice_can_be_25x():
    cheap = Interaction("gpt-5.6-luna", input_tokens=100_000).cost_usd()
    dear = Interaction("gpt-5.6-sol", input_tokens=100_000).cost_usd()
    assert math.isclose(dear / cheap, 25.0, rel_tol=0.01)


def test_unknown_model_is_rejected():
    with pytest.raises(ValueError, match="Unknown model"):
        Interaction("gpt-9000", input_tokens=100)


def test_negative_tokens_are_rejected():
    with pytest.raises(ValueError, match="negative"):
        Interaction("gpt-5.6-terra", input_tokens=-5)


def test_team_monthly_cost():
    profile = TeamProfile(
        name="test", seats=10, workdays_per_month=20, plan_allowance_usd=19.0,
        interactions_per_dev_per_day=[
            Interaction("gpt-5.6-terra", input_tokens=50_000, output_tokens=2_000)
        ],
    )
    # per person/day = 50k*2/1M + 2k*12/1M = 0.10 + 0.024 = 0.124
    assert math.isclose(profile.daily_cost_per_dev(), 0.124, rel_tol=1e-9)
    assert math.isclose(profile.monthly_cost(), 0.124 * 20 * 10, rel_tol=1e-9)


def test_allowances_are_pooled():
    profile = TeamProfile(name="t", seats=100, plan_allowance_usd=19.0)
    assert profile.monthly_allowance() == 1900.0


def test_no_overage_below_the_allowance():
    profile = TeamProfile(
        name="t", seats=10, workdays_per_month=20, plan_allowance_usd=19.0,
        interactions_per_dev_per_day=[Interaction("gpt-5-mini", input_tokens=1_000)],
    )
    assert profile.overage() == 0.0


def test_compare_reports_the_saving():
    before = TeamProfile(name="before", seats=10, workdays_per_month=20,
                         interactions_per_dev_per_day=[
                             Interaction("gpt-5.6-sol", input_tokens=100_000)])
    after = TeamProfile(name="after", seats=10, workdays_per_month=20,
                        interactions_per_dev_per_day=[
                            Interaction("gpt-5.6-terra", input_tokens=100_000)])
    result = compare(before, after)
    assert result["saving_pct"] == 60.0   # 5.00 -> 2.00
    assert result["annual_saving_usd"] > 0


def test_rate_table_shows_the_cache_discount():
    table = {r["key"]: r for r in model_table()}
    assert table["gpt-5.6-terra"]["cache_discount_x"] == 10.0


def test_token_estimate_is_rough_but_sane():
    assert estimate_tokens("") >= 1
    text = "a" * 3000
    assert 900 <= estimate_tokens(text) <= 1100
