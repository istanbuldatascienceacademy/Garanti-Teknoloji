"""Tests for the MCP tools.

The tools are tested as plain Python functions, not over the MCP protocol.
The reason is deliberate: the business logic should be independent of the
protocol. VS Code already tests the transport; what we need to verify is that
the tool gives the right answer.
"""

import json

from mcp_server.corp_server import (
    api_search,
    can_deploy,
    standard_get,
    standards_list,
    tool_cost,
)


def call(tool, **kwargs):
    """Invoke an MCP tool and parse its JSON output."""
    fn = getattr(tool, "fn", tool)
    return json.loads(fn(**kwargs))


def test_index_returns_a_summary_only():
    result = call(standards_list)
    keys = {s["key"] for s in result}
    assert "java-service" in keys
    # The index must NOT carry the full text — context thrift is by design
    assert all("clauses" not in s for s in result)


def test_standard_get_returns_full_text():
    result = call(standard_get, key="java-service")
    assert result["version"] == "4.2"
    assert any("BigDecimal" in c for c in result["clauses"])


def test_missing_standard_lists_the_alternatives():
    result = call(standard_get, key="no-such-thing")
    assert "error" in result
    assert "java-service" in result["available"]


def test_api_search_by_keyword():
    result = call(api_search, keyword="limit")
    assert result["found"] == 1
    assert result["services"][0]["key"] == "limit-engine"


def test_api_search_pii_filter():
    everything = call(api_search, keyword="")
    pii_free = call(api_search, keyword="", pii_free_only=True)
    assert pii_free["found"] < everything["found"]
    assert all(not s["contains_pii"] for s in pii_free["services"])


def test_empty_search_returns_everything():
    assert call(api_search, keyword="")["found"] == 4


def test_deploy_blocked_on_a_freeze_day():
    result = call(can_deploy, target_date="2026-08-14")
    assert result["can_deploy"] is False
    assert "reconciliation" in result["reason"]


def test_deploy_blocked_at_the_weekend():
    # 2026-08-15 is a Saturday
    result = call(can_deploy, target_date="2026-08-15")
    assert result["can_deploy"] is False
    assert "Weekend" in result["reason"]


def test_deploy_allowed_on_an_open_working_day():
    # 2026-08-13 is a Thursday
    assert call(can_deploy, target_date="2026-08-13")["can_deploy"] is True


def test_malformed_date_gives_a_clear_error():
    result = call(can_deploy, target_date="14.08.2026")
    assert "error" in result
    assert "YYYY-MM-DD" in result["error"]


def test_tool_cost_reports_a_token_estimate():
    result = call(tool_cost)
    assert result["tool_count"] == 5
    assert result["approx_total_tokens"] > 0
    assert all(t["approx_tokens"] > 0 for t in result["tools"])


def test_no_tool_returns_personal_data():
    """The security lesson of the workshop, encoded as a test.

    The catalogue SAYS a service contains personal data; it never returns any.
    """
    outputs = [
        getattr(standards_list, "fn", standards_list)(),
        getattr(api_search, "fn", api_search)(keyword=""),
    ]
    forbidden = ["national_id", "card_no", "account_no", "iban", "tckn"]
    for text in outputs:
        for term in forbidden:
            assert term not in text.lower()
