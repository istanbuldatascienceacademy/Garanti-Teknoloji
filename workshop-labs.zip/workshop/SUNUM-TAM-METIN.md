# Sunum tam metni — cümle cümle

Konuşulacak metnin kendisi. Köşeli parantez içindekiler sahne yönergesi, sesli
okunmaz.

**Uyarı:** bunu ezberleme ve okuma. Bir kez baştan sona oku, kendi cümlelerine
çevir, sonra sadece tempo tutucu olarak kullan. Ezberlenmiş metin oda tarafından
anında fark edilir ve güvenini kaybettirir. Kendi örneklerin buradaki her
cümleden iyidir.

---

# AÇILIŞ (09:00–09:30)

## Slayt 1 — Başlık

Günaydın. Bugün bir gün boyunca birlikte olacağız ve sabah dokuzda başlayıp
akşam beşte, elinizde kurumunuza götürebileceğiniz bir belgeyle bitireceğiz.

Konumuz Copilot, MCP ve token ekonomisi. Ama üç ayrı konu anlatmayacağım. Tek bir
fikir var ve gün boyu onu üç farklı açıdan göreceğiz.

O fikir şu: **bağlam bir bütçedir.**

Modele gönderdiğiniz her şey — talimat dosyalarınız, açtığınız araçlar, sohbet
geçmişiniz — her istekte yeniden gönderiliyor ve her istekte yeniden
faturalanıyor. Bu bir benzetme değil. 1 Haziran'dan beri kelimenin tam anlamıyla
böyle.

Günü üçe böleceğiz: ne gönderdiğiniz, neyi açtığınız, ne ödediğiniz.

Dört anlatım bloğu, dört lab var. Labları kendi makinenizde yapacaksınız. Öğleden
sonra kendi gerçek rakamlarınızı bulacaksınız — benim slaytlarımdaki rakamları
değil, kendi kurumunuzunkini.

[Kendini tanıt. Kısa. İki cümle.]

---

## Slayt 2 — Günün akışı

Programı hızlıca göstereyim.

Sabah iki blok: talimat dosyaları ve MCP. İkisinin de ardından lab var.

Öğleden sonra iki blok: token ekonomisi ve optimizasyon. Yine ikisinin de ardından
lab.

16:30'da grup çalışması yapacağız. Orada dört sayfa yazacaksınız ve o dört sayfa
günün asıl çıktısı. Onu odadan çıkmadan toplayacağım.

Molalar korunuyor. On birde on beş dakika, bir buçukta bir saat öğle, üçte on beş
dakika.

Bir şey daha: anlatım bloklarında sorularınızı bekletmeyin, araya girin. Ama
labda konuşmayı ben keseceğim, çünkü asıl iş orada oluyor.

---

## Slayt 3 — Tek fikir, üç açı

Şuraya bakın. Günün tek cümlesi bu.

Bağlam bir bütçedir. Şimdi bunu üç parçaya ayıralım, çünkü gün bu üç parçanın
üstüne kurulu.

**Birincisi: ne gönderdiğiniz.** Talimat dosyalarınız, prompt dosyalarınız,
sohbet modlarınız. Bunlar her istekte modele yükleniyor. Kimse okumasa da,
kimsenin işine yaramasa da yükleniyor.

**İkincisi: neyi açtığınız.** MCP sunucuları ve onların araç şemaları. Bağlı olan
her sunucu, sorduğunuz her soruya sabit bir harç ekliyor. O sunucuyu o soruda
kullanıyor olmanız gerekmiyor.

**Üçüncüsü: ne ödediğiniz.** Girdi, çıktı ve önbellek token'ları. Modele göre
fiyatlanıyor ve fatura varlığı düzeyinde havuzlanıyor.

Şimdi bunların hepsini birleştiren cümle: sohbet geçmişi, eklediğiniz dosyalar,
araçların döndürdüğü çıktılar — hepsi **her turda** yeniden gönderiliyor.

Yani bir sohbet uzadıkça, ilk mesajınız da defalarca ödenmiş oluyor.

---

## Slayt 4 — 1 Haziran 2026'da ne değişti

1 Haziran'da GitHub Copilot kullanım bazlı faturalamaya geçti. Çoğu ekip bunu
henüz sindirmedi.

Soldaki sütun eski dünya, sağdaki yeni.

Eskiden **premium istek** sayıyorduk. Şimdi token sayılıyor: girdi, çıktı,
önbellek.

Eskiden modelin bir **çarpanı** vardı, dokuz kat gibi. Şimdi her modelin token
başına fiyatı var.

Eskiden koltuk başına sabit bir kota vardı. Şimdi AI Credits var ve fatura
varlığı düzeyinde havuzlanıyor. Bu ayrıntıya öğleden sonra döneceğiz, çünkü
sandığınızdan önemli.

Şu satırda duralım. **Kod tamamlama artık ölçülmüyor.** Ücretli planlarda
sınırsız. Satır içi öneriler, sonraki düzenleme önerileri — hiçbiri kredi
harcamıyor.

Bunu bilmiyorsanız, bugünün en kolay kazancını kaçırıyorsunuz demektir.

Ve son satır, benim için en önemlisi. Eskiden kontrol edebildiğiniz şey "ne
sıklıkla soruyorum"du. Şimdi "her sorum ne kadar bağlam taşıyor". Alışkanlık
değişimi tam olarak burada.

Bir not: bu fiyatlar ve plan detayları değişiyor. Ben bunları GitHub Docs'tan
aldım, tarihi de repoda yazılı. Siz de sunmadan önce doğrulayın.

---

## Slayt 5 — Aynı iş, aynı kişiler, üç fiyat

Şimdi somut bir rakam.

120 kişilik bir ekip. Ayda 21 iş günü. Business koltuk. Herkes aynı işi yapıyor,
aynı sayıda soru soruyor.

Üç farklı kurulumda üç farklı fiyat çıkıyor.

**Birinci senaryo, hiçbir optimizasyon yok:** ayda 3.064 dolar. Havuzda dahil olan
kredinin yüzde 134'ü. Yani bu ekip aşımda, üstüne fatura ödüyor.

**İkinci senaryo, sadece model yönlendirmesi yapılmış:** rutin iş hafif modele,
gerçekten zor iş güçlü modelde kalmış. 1.334 dolar. Havuzun yüzde 58'i.

**Üçüncü senaryo, bağlam disiplini de eklenmiş:** talimat dosyaları kesilmiş,
kullanılmayan sunucular kapatılmış, önbellek çalışıyor. 456 dolar. Havuzun yüzde
20'si.

Birinci ile üçüncü arasındaki fark yılda yaklaşık 31.000 dolar.

Şimdi şunu net söylemem lazım: **bu rakamlar modellenmiş kullanım varsayımlarına
dayanıyor.** Ben burada günde dört sohbet, sohbet başına şu kadar bağlam diye bir
profil kurdum. Sizin ekibiniz farklı çalışıyor olabilir.

O yüzden bunu kanıt olarak sunmuyorum. Büyüklük mertebesini göstermek için
sunuyorum. Kendi gerçek rakamınızı öğleden sonra, Lab 3'te kendiniz bulacaksınız.

---

## Slayt 6 — Hangisindesiniz?

Peki siz hangisindesiniz?

[Sus. Say. En az on saniye. Rahatsız edici gelecek, bırak gelsin.]

Cevabı veriden bilemiyorsanız, günün gerekçesi tam olarak bu.

Saat üçte kendi kullanım raporunuzu çekmiş olacaksınız. Kendi ekip
büyüklüğünüzle hesabı yapmış olacaksınız. Ve üç maliyet eşiğini de kendi
terminalinizde doğrulamış olacaksınız.

Bugünden çıkarken elinizde tahmin değil, ölçüm olacak.

---

## Slayt 7 — 17:00'de neler yapabileceksiniz

Beş kazanım var ve her biri bir laba bağlı.

Bir: Copilot'u dosyayla yönetebileceksiniz. Dört dosya türü var ve hangi kuralın
hangi dosyaya ait olduğunu bileceksiniz.

İki: bir MCP sunucusu bağlayabileceksiniz. Ve daha önemlisi, bankada hangi
verinin araç olarak açılıp açılamayacağını tartışabileceksiniz.

Üç: ekibinizin aylık maliyetini hesaplayabileceksiniz ve üç eşiği tanıyacaksınız
— model seçiminde 25 kat, önbellekte 10 kat, uzun bağlamda 2 kat.

Dört: somut bir değişiklik yapıp etkisini rakamla gösterebileceksiniz. Fikirle
değil, ölçümle.

Beş: kurumunuzun gerçekten benimseyebileceği bir sayfalık kullanım politikası
taslağıyla çıkacaksınız.

---

## Slayt 8 — Başlamadan önce

Kısa bir kontrol.

Makinenizde olması gerekenler: güncel VS Code, Copilot eklentisi ve oturum
açılmış olması, Business veya Enterprise koltuk, Python 3.10 veya üstü.

Kurumdan gerekenler: Agent modu ve MCP'ye politika izni, ve mümkünse aranızda
faturalama ekranına erişimi olan bir kişi.

Şimdi kırmızı kutu. Bu, günü bozabilecek tek madde.

**MCP yalnızca Agent modunda çalışıyor.** Agent modu kurumsal politikayla
kapatılmışsa günün yarısı çalışmaz.

O yüzden şimdi soralım. Makinesinde VS Code'u açıp sohbet panelinde Agent modunu
görebilen var mı?

[El kaldıranları say. Sorun varsa şimdi çöz, 11:45'te değil.]

---

# MODÜL 1 — TALİMAT DOSYALARI (09:30–10:15)

## Slayt 9 — Bölüm ayracı

Birinci bölüm: ne gönderdiğiniz.

Bu bölümü neden ilk yapıyoruz? Çünkü en ucuz değişiklik burada ve etkisi en
geniş. Kimseden izin almadan, bugün öğleden sonra yapabileceğiniz şeyler burada.

---

## Slayt 10 — Dört dosya, dört iş

Dört tane dosya türü var. Aralarındaki fark ne yaptıkları değil, **ne zaman
yüklendikleri**. Ve ne zaman yüklendikleri, ne kadar maliyet ettiklerini
belirliyor.

`copilot-instructions.md` — her istekte yükleniyor. Her soruya, her seferinde.

`instructions` klasöründeki dosyalar — sadece `applyTo` kuralı eşleştiğinde.

`prompts` klasöründekiler — sadece siz eğik çizgiyle komut yazdığınızda.

`chatmodes` klasöründekiler — sadece o modu seçtiğinizde.

Bir de `AGENTS.md` var, ona birazdan geleceğiz.

Şimdi bugünün en çok işinize yarayacak cümlesini yazın:

**Her soruda gerekli değilse, always-on dosyaya girmez.**

Bu kadar. Gerisi bunun uygulaması.

---

## Slayt 11 — Bu kural nereye gider?

Elinizde bir kural var ve nereye koyacağınızı bilmiyorsunuz. Tepedeki soruyu
sorun.

Bu kural her dosya türünde geçerli mi? Java'da da, Python'da da, SQL'de de,
YAML'de de?

Evetse, `copilot-instructions.md`. Ama bilerek: buraya koyduğunuz her satır,
ekibin sorduğu her soruya eklenen sabit bir vergi.

Hayırsa üç dal var.

Belirli bir dosya türüne mi özgü? O zaman `instructions` klasörüne, `applyTo`
ile.

Tekrar eden bir iş mi? Prompt dosyasına. Eğik çizgiyle çağırırsınız.

Farklı bir çalışma modu mu? Chatmode dosyasına, araçları da kısıtlayarak.

Ve son satır. Dört sorunun da cevabı hayırsa, o içerik ekip wiki'sine ait. Repoya
değil.

Bu size sert gelebilir ama şöyle düşünün: modelin okumadığı bir metni repoda
tutmak, insanların da okumamasını garantiliyor.

---

## Slayt 12 — copilot-instructions.md

Bu, atölye reposundaki gerçek dosya. Üzerinden geçelim.

Bağlam bölümü iki cümle: Java Spring Boot mikroservisleri ve Python veri işleri.

Sonra invariantlar. Altı tane var.

Para tutarları BigDecimal, asla double. Loglarda müşteri kimliği yok. SQL
parametreli, asla string birleştirmeyle değil. Dış çağrılarda açık zaman aşımı.
Sırlar yapılandırmada, kodda değil.

Neden bu altısı? Çünkü hepsi dil bağımsız ve hepsinin ihlali pahalı. Java'da da
doğru, Python'da da. Ve yanlış yapıldığında sonucu var.

Şimdi son bölüme bakın. "Bilmiyorsan sor."

Bu satır tek başına yerini hak ediyor, çünkü modelin kurum standardını
**uydurmasını** engelliyor. Onsuz model makul görünen ama sizin standardınız
olmayan bir cevap üretir ve bunu fark etmezsiniz.

Sağda ne yer bulur, ne bulmaz. Framework öğreticileri, stil tercihleri, model
yönlendirme tabloları, onboarding metinleri — bunların hiçbiri buraya ait değil.

Dosya 292 token. Hedefimiz 500'ün altı.

---

## Slayt 13 — Always-on dosyayı denetlemek

Şimdi size bir soru vereceğim ve bunu kendi dosyanızdaki **her satıra** ayrı ayrı
soracaksınız.

[Ekrandaki soruyu yüksek sesle oku.]

"Ekibimin sorduğu soruların yüzde kaçında bu satır gerçekten gerekli?"

Üç kutu var.

Yüzde 80'in üstündeyse kalır. Gerçekten evrensel demektir, always-on dosya bunun
için var.

Yüzde 20 ile 80 arasındaysa taşınır. `instructions` klasörüne, `applyTo` ile.
Böylece sadece ilgili olduğunda yüklenir.

Yüzde 20'nin altındaysa prompt dosyasına gider. İsteğe bağlı olur; ihtiyacı olan
çağırır.

Hedef: 500 token altı.

Oraya inemiyorsanız, o dosyayı wiki gibi kullanıyorsunuz demektir. İçerik
değersiz değil — yanlış yerde.

[Biri "bizimki 2.000 token" derse: "Labda birlikte keseceğiz" de ve geç.
Savunmaya itme.]

---

## Slayt 14 — applyTo

Bir Java kuralı, siz Python yazarken hiçbir şeye mal olmamalı.

`applyTo` bunu yapıyor. Frontmatter'a bir glob yazıyorsunuz, dosya sadece o
eşleşmede yükleniyor.

Labda şunu yapacaksınız: bir Python dosyası açıp "buradaki katman kuralları
neler" diye soracaksınız. Sonra bir Java dosyası açıp **aynı** soruyu
soracaksınız. İki cevap arasındaki fark, `applyTo`'nun size kazandırdığı şey.

Aşağıdaki iki kart önemli.

**Maliyet etkisi:** sadece Java dosyalarında yüklenen 900 token'lık bir standart,
ekibinizin sorduğu her Python, SQL ve YAML sorusunda görünmez.

**Kalite etkisi:** bağlamda daha az alakasız kural, modelin yanlış kuralı uygulama
ihtimalini düşürür.

Bunu özellikle vurgulamak istiyorum. Bu bir takas değil. Hem ucuzluyor hem
keskinleşiyor.

Gün boyu size "şunu kısın, bunu kesin" diyeceğim ve aklınıza "peki kalite ne
olacak" sorusu gelecek. Cevabın büyük kısmı bu: gereksiz bağlamı atmak kaliteyi
düşürmüyor, yükseltiyor.

---

## Slayt 15 — Prompt dosyaları

Haftada ikiden fazla tekrar yazdığınız her şey buraya ait.

Ekrandaki örnek bir servis inceleme promptu. Dört adımı var, çıktı biçimini
söylüyor ve sonunda duruyor.

İyi bir prompt dosyasının üç özelliği var.

**Bir: çok adımlı.** Tek cümleyse zaten dosyaya ihtiyacınız yoktu, sohbete
yazardınız.

**İki: açık çıktı biçimi.** Hangi tablo kolonlarını istiyorsanız yazın. "Güzel bir
rapor ver" değil, "Kural, Durum, Satır, Öneri kolonlarıyla tablo ver".

**Üç: sonunda bir duruş.** "Önce raporu göster, onay bekle." Düzeltmeden önce
incelemek, geri almaktan her zaman ucuz.

Ve şu: prompt dosyası **sadece çağırdığınızda** yükleniyor. Bu yüzden uzun,
detaylı, nadir gereken her şeyin doğru evi burası. Always-on dosyadan buraya
taşıdığınız her şey bedavaya gelmiş oluyor.

---

## Slayt 16 — Sohbet modları

Bu slayt özellikle analist arkadaşlar için.

Mod, asistanın kim olduğunu değiştiriyor. Ve `tools` alanıyla hangi araçlara
dokunabileceğini de.

Ekrandaki analist modu şunu diyor: kod yazma, kod değiştirme. İstenirse reddet ve
Agent moduna geçmesi gerektiğini söyle. Her teknik terimi ilk kullandığında
açıkla. Davranışın nerede tanımlı olduğunu dosya:satır olarak göster. Ve asla
tahmin etme — bilmiyorsan "kod bunu söylemiyor" de.

Şimdi canlı göstereyim.

[Analist moduna geç. "Bana bir servis sınıfı yaz" de. Reddedişini odaya
izlettir.]

Gördüğünüz gibi. Sınırını tutan bir mod, anlattığım bir moddan çok daha ikna
edici.

Bu neden önemli? Analist için: kod yazan değil, **kod okuyan** bir asistan
kazanıyorsunuz. Cevaplar iş diliyle geliyor ve dosya:satır referansıyla — o
referansı bir mühendise verebiliyorsunuz.

Finans için: `tools` alanı araç erişimini kısıtlıyor. Az araç, bağlamda az şema.
Hem ucuz hem odaklı cevap.

---

## Slayt 17 — Atlanan üç şey

Repodaki dört dosyanın dışında üç şey daha var.

**AGENTS.md.** Birden fazla aracın okuduğu taşınabilir bir talimat dosyası. VS
Code da okuyor. Kurumunuz tek bir asistanda standartlaşmadıysa işinize yarar.

**Organizasyon düzeyi talimatlar.** Merkezî tanımlıyorsunuz, tüm repolara
otomatik uygulanıyor. 120 repolu bir kurumda asıl kaldıraç bu — tek tanım, 120
kopyanın zamanla birbirinden ayrışmasına her zaman yeğdir.

**Eğik çizgi init komutu.** Mevcut repoyu analiz edip size bir talimat dosyası
taslağı üretiyor. Ama dikkat: bu kesilecek bir başlangıç noktası, teslim
edilecek bir ürün değil. Ürettiği dosya genelde çok uzun olur.

Son cümle önemli. Talimatları merkezîleştirmek, **yanlış yapmanın maliyetini de
merkezîleştiriyor.** Sahiplik org düzeyinde daha az değil, daha çok önemli hâle
geliyor.

---

## Slayt 18 — 1.000 boşa token ne eder

Hesabı birlikte yapalım.

120 mühendis. Kişi başı günde dört sohbet isteği. Ayda 21 iş günü. Ve always-on
dosyanızda gereksiz duran bin token.

Çarpalım: ayda 10,1 milyon token.

Güçlü bir modelde bu, ayda yaklaşık 50 dolar. Yılda 600 dolar.

**Kimsenin okumadığı satırlar için.**

Şimdi aşağıdaki cümleye dikkat edin, çünkü bu slaydın asıl mesajı orada.

Bu rakam, görmezden gelinecek kadar küçük ve utandıracak kadar büyük. Yıllarca
hayatta kalmasının sebebi tam olarak bu. Kimse 600 dolar için toplantı yapmaz,
ama kimse de bunun farkında olmak istemez.

[Biri "600 dolar mı, değmez" derse:] Tek başına değmez, haklısınız. Ama bu **tek
bir dosya**. Öğleden sonra yedi kaldıraç göreceğiz ve hepsi bu büyüklükte. Üstelik
çarpılıyorlar, toplanmıyorlar. Ona Lab 3'te geleceğiz.

---

## Slayt 19 — Bu dosya kod mu, politika mı?

Şunu düşünün. Bir geliştirici `copilot-instructions.md`'ye bir satır ekliyor.
Maliyet ekibin tamamına biniyor. Ve kimse fark etmiyor.

Peki bu dosya kod mu, politika mı?

Kod gibi davranıyor: repoda duruyor, PR'la değişiyor, git geçmişi var.

Ama politika gibi sonuç doğuruyor.

Üç soru var ve çoğu kurumda bu soruların cevabı verilmemiş.

Kim değiştirebilir? Commit yetkisi olan herkes mi, isimli bir sahip mi?

Hangi incelemeden geçiyor? Normal PR incelemesi doğruluğa bakar. Kimse bir
talimat dosyasını **uzunluk** için incelemiyor. Oysa maliyet uzunlukta.

Ne zaman yeniden okunuyor? Talimat dosyaları birikir. Planlı bir temizlik yoksa
sadece büyürler ve her ekleme kalıcıdır.

İşleyen bir model şu: bu dosyaya paylaşılan bir yapılandırma dosyası gibi
davranın. İsimli bir sahip, dosyanın kendi başlığında yazılı bir token bütçesi,
ve çeyreklik gözden geçirme. Kapsamlı dosyalar herkese açık kalabilir.

Bunu Lab 1'in sonunda tartışacağız.

---

## Slayt 20 — Lab 1 brifingi

Şimdi laba geçiyoruz. Kırk beş dakika.

Beş adım var. İki tanesini özellikle vurgulayacağım.

**Adım 1: önce ölçün.** Hiçbir dosyaya bakmadan Copilot'a soracaksınız. Cevabı
not alacaksınız. Sonra talimat dosyasını okuyup aynı soruyu tekrar soracaksınız.

Neden bu sıra? Çünkü dosyayı önce eklerseniz farkı **hiç göremezsiniz**. Bugün
yapacağınız her ölçümde bu sıra geçerli: önce ölç, sonra değiştir.

**İkinci vurgu: her soruda yeni sohbet.** İki soruyu tek sohbette sorarsanız ilk
cevap hâlâ bağlamda duruyor ve ikinci cevap kirleniyor.

Bu Lab 1'de küçük bir detay. Lab 3'te aynı hata bütün ölçümünüzü bozar. O yüzden
alışkanlığı şimdi kurun.

Adım 2'de dosyayı satır satır tartışacaksınız. Bu tartışma labın kendisi, aceleyle
geçmeyin. Ben dolaşacağım.

Sorusu olan?

[45 dakika lab. Dolaş. Adım 2'de vakit geçir.]

---

# MODÜL 2 — MCP (11:15–11:45)

> Bu blok otuz dakikada on üç slayt. Tempo hızlı. Banka slaytlarını (24, 25, 26)
> asla sıkıştırma; gerekirse 31 ve 33'ten kıs.

## Slayt 21 — Bölüm ayracı

İkinci bölüm: neyi açtığınız.

Sabah gönderdiğiniz şeyleri konuştuk. Şimdi modele dış dünyaya bir kapı açmaktan
bahsedeceğiz.

Ve şunu baştan söyleyeyim: bankada bu bölüm teknik bir konu değil, kurumsal bir
konu. Kodu on dakikada yazarsınız. Kararı vermek aylar alabilir.

---

## Slayt 22 — MCP nedir

MCP, modelin dış dünyayla konuşması için bir standart arayüz.

Üç şey sunuyor.

**Tools** — modelin çağırabileceği fonksiyonlar. Model adını, açıklamasını ve
argüman şemasını görüyor, ne zaman çağıracağına kendisi karar veriyor.

**Resources** — istemcinin okuyup bağlama ekleyebileceği içerik. Çağrılmıyor,
URI ile adresleniyor.

**Prompts** — sunucunun istemciye sunduğu hazır prompt şablonları.

Şimdi koyu kutuya bakın, çünkü bu bilgi satın alma kararınızı etkileyebilir.

**Copilot yalnızca tools kullanıyor.** Resources ve prompts desteklenmiyor.

Bunun pratik sonucu şu: değeri yayımladığı kaynaklarda olan bir MCP sunucusu
bağlarsanız, o içeriğin hiçbiri görünmez. Ve size bunu **kimse söylemez**. Hata
almazsınız, uyarı almazsınız. Sadece beklediğiniz şey olmaz.

O yüzden bir sunucuyu planınıza almadan önce gerçekte ne sunduğuna bakın.

---

## Slayt 23 — Mimari ve taşıyıcılar

Sunucu ayrı bir süreç. VS Code istemci, sunucu ayrı çalışıyor, sunucu sizin
sistemlerinize bağlanıyor.

Üç taşıyıcı var.

**stdio** — sunucu geliştiricinin makinesinde, VS Code tarafından başlatılıyor.
Yerel scriptler, repoya özgü araçlar için.

**http** — ağınızdaki veya bir tedarikçinin sunucusunda çalışan bir servis.
Paylaşılan kurumsal sunucular için.

**sse** — aynı ama akış kanalı var. Uzun süren veya akan araçlar için.

Şimdi kırmızı kutu. Bunu lütfen not alın, hatta ben tahtaya yazacağım.

**Yerel bir stdio sunucusu, döndürdüğü her şeyi model sağlayıcısına gönderir.**

[Tahtaya yaz. Bir sonraki slayt bunun üzerine kurulu.]

---

## Slayt 24 — Yapılandırma iki yerde

Yapılandırmayı iki yere koyabilirsiniz ve seçimi bilerek yapın, çünkü fark
**başka kimin aldığı**.

**Workspace yapılandırması** — repoyla birlikte commit ediliyor, ekiple
paylaşılıyor, PR'da inceleniyor. Projedeki herkesin ihtiyaç duyduğu sunucular
için.

**User yapılandırması** — tek makinede kalıyor. Kişisel kimlik bilgisi veya API
anahtarı taşıyan her şey buraya.

İhtiyacınız olacak komutlar: MCP: List Servers ile başlatır, durdurur,
incelersiniz. MCP: Restart Server, sunucu kodunu değiştirdiğinizde. Ve Agent modu
— tekrar söylüyorum, Ask modunda araçlar çalışmıyor.

Bir uyarı, sahadan geliyor. `command` alanına düz "python" yazmayın. **Tam yol
yazın.**

Neden? Düz "python" PATH'te ilk gelen yorumlayıcıyı çalıştırır. Anaconda kuruluysa
veya birden fazla Python varsa, yanlışını seçer. O yorumlayıcıda MCP paketi
olmadığı için süreç anında ölür.

Ve şu kısım can sıkıcı: VS Code hata gösterir ama **output kanalı boş kalır**.
Çünkü süreç bir şey yazacak kadar bile yaşamamıştır. Sebebi görünmeyen bir hata
alırsınız.

Labın birinci adımı bunu çözüyor. Oraya on beş dakika ayıracağız.

---

## Slayt 25 — Agent modu zorunlu

Bu tablo kısa ama net.

Ask modunda MCP araçları **yok**. Çalışmıyor. Nokta.

Agent modunda var, ve her çağrı için onay isteniyor.

Çok adımlı iş Ask modunda yok, Agent modunda var — planlıyor, düzenliyor,
çalıştırıyor, kontrol ediyor.

Şimdi alttaki iki kart. Bunları dengeli okuyun.

**Kazandığınız:** araçlar, çok adımlı yürütme, ve modelin kendi işini size
vermeden önce doğrulayabilmesi.

**Ödediğiniz:** her adım birikmiş bağlamı yeniden gönderiyor.

Bunu içselleştirin: **bir agent koşusu tek istek değil, çok istektir.** Bütçe
yaparken böyle düşünün. Beş adımlı bir agent görevi, beş sohbet mesajından pahalı
olabilir, çünkü her adım bir öncekinin çıktısını da taşıyor.

---

## Slayt 26 — Banka noktası bir: yerel içeride demek değil

Bu, MCP hakkındaki en yaygın ve en pahalı yanlış anlama.

[Ekrandaki eşitsizliği oku.]

"Sunucu yerelde çalışıyor" ile "veri içeride kalıyor" aynı şey **değil**.

Üç adımda görelim.

**Bir:** aracın döndürdüğü her şey bağlama giriyor. Girmek zorunda, çünkü model
onun üzerinde akıl yürütecek.

**İki:** bağlam model sağlayıcısına gidiyor. Bu turda ve sonraki her turda.

**Üç:** dolayısıyla araç bir **veri yolu**.

Bir MCP aracı, sessizce sınırınızın dışına veri taşıyan bir kanala dönüşebilir.
Kimse buna karar vermeden.

Ve şunu net söyleyeyim: bu kurumsal bir karar. Geliştirici kararı değil.

Sorayım: kurumunuzda bu kararı kim verir?

[Cevapları dinle. Genelde belirsiz çıkar ve bu, slayt 28'in kurulumu.]

---

## Slayt 27 — Banka noktası iki: onay akışı denetim izidir

Copilot her araç çağrısından önce izin istiyor. O istem, göründüğünden çok daha
fazla iş yapıyor.

Üç seçenek var.

**Her çağrıda onay.** Her kullanım, bir insanın belirli bir anda verdiği bir
karar. Denetim izini anlamlı kılan şey bu.

**Otomatik onay.** Rahat. Ve kararların kaydını, faaliyetin kaydına çeviriyor.
İnceleyen kişi artık niyeti otomasyondan ayıramıyor.

**Orta yol.** Hassas olmayan sunucularda salt-okunur araçları otomatik onaylayın.
Yazan veya düzenlemeye tabi veriye dokunan araçları **asla**.

Şimdi size bir soru bırakacağım. Atölyeden önce risk biriminize sorun:

Bir denetçi gelse ve "geçen ay bir araç çağrısı üzerinden hangi veri sınırın
dışına çıktı" diye sorsa — kim cevap verebilir?

Bu sorunun cevabı, MCP politikanızı herhangi bir teknik kısıttan daha çok
şekillendirir.

---

## Slayt 28 — Banka noktası üç: onaylı liste

Üç model var.

**Serbest kurulum.** Her geliştirici bulduğu sunucuyu bağlar. Bankaya uymaz —
incelenmemiş veri yolları, envanter yok.

**Onaylı liste.** İncelenmiş bir katalog var, dışındaki her şey talep gerektiriyor.
Doğru varsayılan bu.

**Tamamen merkezî.** Her sunucuyu platform ekibi işletiyor, yerel sunucu yok.
Güvenli ama yavaş, ve ekipler etrafından dolaşır. Dolaşmaları da sizin
göremediğiniz yerde olur.

Bir onayın yanıtlaması gereken üç soru var.

**Ne döndürüyor?** Hangi alanlar, hangi sistemden, ve bunların herhangi biri
kişisel veri mi? "Müşteri bilgisi" cevabı yeterli değil, alan listesi lazım.

**Kim sahibi?** Sunucuyu bakan ve araç yanlış şey döndürmeye başladığında cevap
veren isimli bir ekip.

**Kim bağlayabilir?** Tüm mühendisler mi, tek bir ekip mi, tek bir proje mi.
Başka her erişim yetkisi gibi kapsamlandırılmış.

---

## Slayt 29 — Araç bütçesi

Bağlı olan her sunucu, şemalarını **her isteğe** ekliyor. O sunucuyu o soruda
kullanıp kullanmamanız fark etmiyor.

Grafiğe bakın. Sunucu başına sekiz araç varsayımıyla: bir sunucu sekiz şema, üç
sunucu yirmi dört, altı sunucu kırk sekiz, on sunucu seksen.

Seksen araç şeması, sorduğunuz her sorunun başına ekleniyor.

Copilot'un tavanı istek başına 128 araç. Ama pratikte kalite bozulması çok daha
önce başlıyor, çünkü model bunlar arasından **seçmek** zorunda. Ne kadar çok
seçenek, o kadar çok yanlış seçim.

Kural basit: bugün kullanmadığınız sunucuyu kapatın. Tek tıklık bir değişiklik ve
etkisi her istekte kalıcı.

---

## Slayt 30 — Neden müşteri verisi yok

Bankaya MCP sunucusu yazarken ilk akla gelen fikir genelde yanlış olanıdır.

Sol taraf: müşteri 360, hesap hareketleri, limit sorgulama. Teknik olarak kolay,
hemen faydalı — ve kişisel veriyi, binadan çıkan bir bağlam penceresine koyuyor.

Sağ taraf, bizim yaptığımız: mühendislik standartları, dahili API kataloğu, sürüm
takvimi. Kişisel veri yok, gerçekten faydalı, ve günde birkaç kez gerçekten
gerekiyor.

Şimdi koyu kutu.

Kişisel veri döndüren bir araç yazmak **teknik olarak önemsiz, kurumsal olarak
ağır**. Bu ikisinin karıştırılması tehlikeli, çünkü kolay olan şey masum
sanılıyor.

Bizim kataloğumuz size bir servisin kişisel veri **içerdiğini söyler**. Verinin
kendisini vermez.

Bu ayrım önemli: hassas verinin nerede olduğunu tarif etmek, onu taşımaktan
farklı bir eylemdir.

---

## Slayt 31 — Bağlayacağınız beş araç

Labda bağlayacağınız sunucuda beş araç var. Hızlıca geçeyim, birazdan
kullanacaksınız.

`standards_list` — standartların kısa bir indeksini döndürüyor. Sadece başlık ve
sürüm, tam metin yok.

`standard_get` — bir standardın tam metnini döndürüyor.

Bu ikisi arasındaki ayrım bilinçli. İki aşamalı erişim, pahalı çağrıyı bilinçli
kılıyor. Model önce indekse bakıyor, hangisi lazımsa onu çekiyor.

`api_search` — dahili API kataloğunda arama. `pii_free` parametresi kişisel veri
tutan servisleri eleyebiliyor.

`can_deploy` — sürüm takvimini kontrol ediyor. Ve sadece cevabı değil,
**gerekçesini** de döndürüyor.

`tool_cost` — bu sunucunun kendi şemalarının kaç token ettiğini raporluyor.
Öğretmek için var; harcı görünür kılıyor.

---

## Slayt 32 — Docstring arayüzdür

Model araç seçimini **açıklamaları okuyarak** yapıyor. O yüzden açıklamayı,
seçmek zorunda olan biri için yazın.

Soldaki kötü örnek: "Servis sahibi bilgisini döndürür."

Doğru. Ve şimdi mi çağırayım, önce başka bir şey mi çağırayım sorusuna hiçbir
cevap vermiyor.

Sağdaki iyi örnek: "Bir servisten sorumlu ekip gerektiğinde kullan — kayıt açmadan
veya olayı yükseltmeden önce. Elinde sadece kısmi isim varsa önce api_search
çağır."

Fark şu: birincisi **ne yaptığını** söylüyor, ikincisi **ne zaman çağrılacağını**.

Alttaki üç kural.

**Faydalı biçimde başarısız olun.** Arama boşa çıktığında mevcut seçenekleri
döndürün. Model o zaman tahmin etmek yerine kendini düzeltebilir.

**Sadece cevabı değil, gerekçeyi döndürün.** `can_deploy` "hayır" diyor ve
sebebini de veriyor. Modelin okuyabildiği bir gerekçe, uyduramayacağı bir
gerekçedir.

**Açıklamaları kısa tutun.** Her kelime her istekte yeniden gönderiliyor. Buradaki
kesinlik hem kalite hem maliyet kararı.

---

## Slayt 33 — Protokolü değil mantığı test edin

Araçları düz Python fonksiyonu olarak test edin. MCP protokolünü test etmeyin —
taşıyıcıyı VS Code zaten test ediyor.

Ekranda iki test var ve ikisi de bir prensibi kodluyor.

Birincisi: "indeks tam metin döndürmez". Bu bir maliyet kararıydı ve şimdi bir
test. Sonraki geliştirici yanlışlıkla bozamıyor.

İkincisi: "hiçbir araç kişisel veri döndürmez". Bu bir politikaydı ve şimdi CI'ın
zorladığı bir şey.

Üstteki not önemli: iş mantığı protokolden uzun yaşar. MCP değişecek. `can_deploy`
fonksiyonunun cumartesi hakkında haklı olup olmadığı değişmeyecek.

Repoda 28 test var, hepsi çevrimdışı çalışıyor. Anahtar yok, ağ yok.

---

## Slayt 34 — Lab 2 brifingi

Bir saatimiz var. Beş adım.

**Birinci adıma on beş dakika ayırın ve atlamayın.** Kurulum burada kazanılıyor
veya kaybediliyor. Sanal ortam kuracaksınız, yorumlayıcının tam yolunu
alacaksınız, `mcp.json`'a yazacaksınız ve sunucuyu bir kez **elle**
çalıştıracaksınız.

O elle çalıştırma adımı önemli: VS Code'un sizden sakladığı hatayı orada
görürsünüz.

Sonra ikiye ayrılıyoruz.

**Geliştiriciler** yeni bir araç yazacak, docstring'iyle ve testiyle.

**Analistler** mevcut araçları değerlendirecek. Dört soru var: hangi açıklama
modeli yanıltabilir, `pii_free` olmasa ne bozulur, hangi araç yazılmamalı,
gerekçe dönmese ne kaybederiz.

Şunu açıkça söyleyeyim: **analist kolu kolay kol değil.** Bankada asıl kritik
soru hangi aracın **yazılmaması** gerektiği, ve bu soru Python bilene değil, iş
sonucunu bilene ait.

O yüzden değerlendirmede analist grubu ilk sunacak.

[60 dakika lab. Adım 1'de yakın dolaş.]

---

# MODÜL 3 — TOKEN EKONOMİSİ (13:45–14:15)

> Öğle sonrası blok. Enerji düşük olacak. Grafikli slaytlarla (38, 40, 42, 44)
> tempoyu koru, tabloları uzun okuma.

## Slayt 35 — Bölüm ayracı

Üçüncü bölüm: ne ödediğiniz.

Sabah ne gönderdiğinizi ve neyi açtığınızı konuştuk. Şimdi faturaya bakacağız.

Ve bu bölümün sonunda kendi gerçek rakamınızı çekeceksiniz.

---

## Slayt 36 — Sayaç nasıl çalışıyor

Üç şey sayılıyor.

**Girdi token'ları.** Talimat dosyalarınız, araç şemaları, eklediğiniz dosyalar,
sohbet geçmişi. Gönderdiğiniz her şey, her turda.

**Çıktı token'ları.** Modelin yazdığı her şey. Ve her modelde girdiden birkaç kat
pahalı.

**Önbellekli girdi.** Değişmeyen bağlam, girdi fiyatının yaklaşık onda birine
geliyor. Elinizdeki en büyük tek kaldıraç bu.

Şimdi yeşil kutu. Bu, günün en kolay kazancı.

**Kod tamamlama ölçülmüyor.** Satır içi öneriler ve sonraki düzenleme önerileri
kredi harcamıyor — ücretli planlarda sınırsız. Sadece sohbet, agent koşuları ve
kod incelemesi sayılıyor.

Şimdi size bir soru. Kaçınız, satır içi tamamlamanın halledebileceği bir şeyi
alıp sohbete yapıştırıyor? Kodu kopyalayıp "şunu şöyle değiştir" diyor?

[Eller kalkacak. Bekle.]

O hareket, bedava olan bir şeyi ücretliye çeviriyor. Ve düzeltmesi hiçbir şeye mal
olmuyor — sadece alışkanlık.

---

## Slayt 37 — Kredinin aritmetiği

Her şey tek bir dönüşüme iniyor.

**Bir AI kredisi, bir sent.**

Örneği birlikte yapalım. Yüz bin girdi token'ı, milyon başına iki dolardan, yirmi
sent. Üç bin çıktı token'ı, milyon başına on iki dolardan, dört sent.

Toplam yirmi dört sent. Yirmi dört kredi.

Tek bir istek için önemsiz bir rakam. Kimse bunun için toplantı yapmaz.

Ama 120 kişi, günde dört istek, ayda 21 gün — o zaman önemsiz olmuyor.

Birim küçük. Çarpan sizin kadronuz.

---

## Slayt 38 — Dahil krediler ve havuzlanma

Koltuk başına dahil kredi: Business'ta ayda on dokuz dolar, Enterprise'da otuz
dokuz.

Ama şu üçüncü kutuya dikkat edin, çünkü çoğu kişi burayı atlıyor.

**Havuz koltuk başına değil. Fatura varlığı düzeyinde toplanıyor.**

120 koltuklu bir Business kurumunda ayda 2.280 dolarlık dahil krediniz var. Tek
bir havuz.

Pratikte ne demek bu? Bir ağır kullanan ekip, birkaç hafif ekibin başlığını
tüketebilir. Ve araçlarda hiçbir şey bunu ikisine de göstermiyor — fatura gelene
kadar.

Şunu net söyleyeyim: bu bir arıza değil, tasarım tercihi. Ama görünürlük olmadan
çalışmıyor.

---

## Slayt 39 — Bütçe kimin?

O zaman bu bütçe kimin?

**Ekip lideri?** Davranışa en yakın olan o, değiştirebilecek olan da o. Ama havuzu
göremiyor ve diğer ekipler üzerinde hiçbir kaldıracı yok.

**Platform ekibi?** Havuzun tamamını görüyor ve merkezî varsayılan koyabiliyor.
Ama harcamayı üreten işe en uzak olan da o.

**Doğru cevap ikisi, ama bir ritimle.** Platform ekip bazlı tüketimi aylık
yayımlar. Ekip liderleri kendi satırlarından sorumlu olur. Biri olmadan diğeri
çalışmıyor.

Üç soru bırakıyorum, labda tartışacaksınız.

Kullanım raporunu kim okuyor ve hangi sıklıkla?

Havuz aşıma girdiğinde ilk hangi veri isteniyor?

Ay sonundan önce birine haber veriliyor mu, yoksa faturayı mı bekliyorsunuz?

---

## Slayt 40 — Milyon token başına girdi fiyatı

Aynı soru, farklı modellere sorulduğunda, aynı iş — çok farklı fiyat.

En soldan başlayarak: yirmi sentten beş dolara.

Yeşiller hafif modeller, turuncular dengeli, kırmızılar güçlü.

İki not. Çıktı fiyatı bunun birkaç katı — her modelde. Ve önbellekli girdi
yaklaşık onda biri.

Bu tabloyu kullanmadan önce GitHub Docs'tan doğrulayın. Fiyatlar değişiyor.

---

## Slayt 41 — Eşik bir: model seçimi

Fiyat listesindeki en geniş uçurum bu. Ve kapatması en kolay olan da bu.

Yirmi sent. Beş dolar. **Yirmi beş kat.**

Aynı soru. Aynı iş.

Şimdi düşünün. Bir fonksiyonun ne yaptığını açıklamak — bu bir muhakeme problemi
mi? PR açıklaması yazmak? Değişkenleri tutarlı biçimde yeniden adlandırmak?

Hiçbiri değil.

**Her iş, en güçlü modeli hak etmiyor.**

Rutin işi hafif bir modele yönlendirmek, elinizdeki emek-tasarruf oranı en iyi tek
değişiklik. Ve kalite kaybı yok, çünkü o işler zaten muhakeme gerektirmiyordu.

---

## Slayt 42 — Eşik iki: önbellek

Değişmeyen bağlam, girdi fiyatının yaklaşık onda birine geliyor.

Grafikte görüyorsunuz: yüz bin token tam fiyatla yirmi sent, önbellekli iki sent.

Peki önbelleğe ne düşüyor? Bağlamınızın istekler arasında **değişmeyen** kısmı.
Talimat dosyalarınız. Araç şemaları. Sohbetin sabit başı.

Ne bozuyor? Talimat dosyasını düzenlemek. Ekleri yeniden sıralamak. Oturum
ortasında sunucu bağlayıp koparmak.

Sebebi şu: bağlamın önündeki oynaklık, ondan **sonraki her şeyi** geçersiz kılıyor.
İlk satırı değiştirdiğinizde, arkasındaki her şeyin önbelleği gidiyor.

Pratik kural: **sabit kısmı sabit tutun, değişkeni sona koyun.**

Ve şu güzel tarafı: önbellek dostu sıralama bedava. Ekstra bir iş yapmıyorsunuz.
Sadece bir şeyleri oynatmayı bırakıyorsunuz.

---

## Slayt 43 — Önbellek bedava değil

Şimdi bir nüans var ve bunu size ben söylemek istiyorum, sormanızı beklemeden.

**Anthropic modellerinde önbelleğe yazmak, düz girdiden pahalı.**

Tabloya bakın. Sonnet 5'te girdi iki dolar, önbellekli yirmi sent — ama önbelleğe
yazma iki buçuk dolar.

Yani önbellek bir yatırım. Tekrar kullanımda geri dönüyor.

Defalarca dokunacağınız bir bağlamda kesinlikle ucuz. Kısa ömürlü bir bağlamda
zarar bile ettirebilir.

Bunu neden anlatıyorum? Çünkü size "önbellek on kat ucuz" deyip geçseydim,
aranızdaki en kıdemli mühendis bunu zaten biliyordu ve günün geri kalanında bana
güvenmezdi.

Ben de aynı şeyi sizden bekliyorum. Bu rakamları kurumunuza sunarken nüansları
gizlemeyin.

---

## Slayt 44 — Eşik üç: uzun bağlam uçurumu

Üçüncü eşik en sinsi olanı.

272 bin girdi token'ını geçtiğinizde birim fiyat **ikiye katlanıyor**. Kademeli
değil. Uçurum.

Rakamlara bakın. 270 bin token elli yedi sent. 280 bin token bir dolar on yedi
sent.

**Yüzde 3,7 daha çok token. Yüzde 104 daha çok para.**

Peki nerede çarpılıyorsunuz bu duvara?

"Tüm repoyu bağlama ekle" dediğinizde. Uzun bir agent koşusu birikmeye devam
ettiğinde. Pazartesiden beri kimsenin kapatmadığı bir sohbet dizisinde.

Size bir itirafta bulunayım. Bu hesaplayıcıyı ilk yazdığımda testte bir milyon
token kullandım ve beklediğim rakam bir türlü tutmadı. Kodda hata arayıp durdum.

Kod doğruydu. Bir milyon token zaten uzun bağlam kademesindeydi.

Muhtemelen bugün aranızdan biri aynı hatayı yapacak. Yaparsanız haber verin,
birlikte gülelim.

---

## Slayt 45 — Kendi rakamınızı bulun

Buradan sonrası gerçek bir rakama dayanıyor. Modellenmiş olana değil.

Adres basit: GitHub, Settings, Billing, Usage.

Üç şeye bakacaksınız.

Bu ay kaç kredi harcanmış? Havuzunuzla karşılaştırın, aşımda mısınız?

Hangi modeller kullanılmış? Güçlü model baskınsa, birinci eşik tek başına
faturanızı ciddi hareket ettirir.

Dahil kredinin yüzde kaçı? Bu, yukarı raporlayacağınız sayı. Aylık takip ederseniz
sürpriz değil, eğilim olur.

Ve şu cümle:

**Tahminle bütçe kurmak, ölçmemenin kibarcasıdır.**

---

## Slayt 46 — Lab 3 brifingi

Kırk beş dakika. Beş adım.

**Birinci adım pazarlığa kapalı.** Faturalama ekranına erişimi olan var mı
aranızda?

[Cevap bekle. Yoksa:] Tamam, ben kendi ekranımı göstereceğim. Ama lütfen
kurumunuzda **kimin** erişimi olduğunu öğrenin, çünkü önümüzdeki ay ona ihtiyacınız
olacak.

İkinci adımda senaryo scriptini kendi ekibinize kalibre edeceksiniz. Koltuk
sayısı, iş günü, dahil kredi — üçünü değiştirip tekrar çalıştıracaksınız.

Sonuç birinci adımdaki gerçek rakamınızla tutmuyorsa, hatalı olan hesaplayıcı
değil, sizin kullanım varsayımlarınız. Kabaca tutana kadar düzeltin.

**O kalibrasyonun kendisi uygulamanın asıl kısmı.** Sonuç değil, süreç önemli.

Üçüncü adımda üç eşiği kendi terminalinizde doğrulayacaksınız. Slaytlarıma
güvenmeyin, kendiniz çalıştırın.

[45 dakika lab.]

---

# MODÜL 4 — OPTİMİZASYON (15:15–15:30)

> **On beş dakikada dokuz slayt.** En sıkışık blok. 50'yi hızlı geç, 51 ve 52'yi
> laba bırak, **54'ü asla atlama**.

## Slayt 47 — Bölüm ayracı

Dördüncü bölüm.

Ölçtünüz. Şimdi düşürüyoruz.

---

## Slayt 48 — Yedi kaldıraç

Yedi kaldıraç var, etkisi büyükten küçüğe sıralı. Listeyi yukarıdan aşağı
uygulayın.

**Bir: doğru yüzey.** Tamamlama ölçülmüyor. Tamamlamanın halledebileceği bir işi
sohbete taşımak, bedavayı ücretliye çeviriyor.

**İki: model yönlendirme.** Aynı istekte yirmi beş kata kadar fark.

**Üç: bağlam disiplini.** Eklediğiniz her dosya her turda yeniden gidiyor. Uzun
sohbetler bunu görünmez biçimde katlıyor.

**Dört: önbellek dostu sıralama.** Sabit kısmı sabit tutun.

**Beş: araç bütçesi.** Kullanmadığınız sunucuyu kapatın.

**Altı: yeni sohbet refleksi.** Konu değiştiyse baştan başlayın. Eski bağlam hem
para yakıyor hem cevabı bulandırıyor.

**Yedi: yeniden deneme maliyeti.** Belirsiz istek, yanlış cevap ve tekrar soru
üretiyor — tam fiyattan.

İlk üçü tasarrufun çoğunu veriyor.

Ve şunu ekleyeyim: **kaldıraçlar toplanmıyor, çarpılıyor.** Labda göreceksiniz —
sadece model değiştirmek yirmi beş kat, sadece bağlam kesmek dokuz kat, ikisi
birden iki yüz yirmi dört kat.

---

## Slayt 49 — İlk üçü, pratikte

Alışkanlığın somut bir tetiği olmalı. Yoksa yerleşmiyor.

**Doğru yüzey.** Tetik: kodu sohbete yapıştırmak üzeresiniz, hafifçe
değiştirilsin diye. Onun yerine: satır içi yapın.

**Model yönlendirme.** Tetik: hangi modelin seçili olduğunu düşünmeden bir sohbet
açıyorsunuz. Onun yerine: hafif modelle başlayın, cevap yetmezse yükseltin.
Gerektiğinde yükseltmek, bütün gün güçlü modelde durmaktan çok daha ucuz.

**Bağlam disiplini.** Tetik: dosya yerine klasör ekliyorsunuz. Onun yerine:
sorunun ihtiyacı kadarını ekleyin. Bir dosyanın neden ekli olduğunu
söyleyemiyorsanız, çıkarın.

---

## Slayt 50 — Son dördü, pratikte

[Kartları hızlı geç, koyu kutuda dur.]

Dördü de daha küçük etkili ve ilk bozulanlar bunlar.

Asıl mesele koyu kutuda. **Hangisi dayatılabilir, hangisi öğrenilir?**

Dört ve beş bir ayar veya politika olabilir. Bir kez kurarsınız, çalışır.

Altı ve yedi alışkanlık. Örnek ve geri bildirimle yerleşir, kuralla değil.

Bunu ayırt etmek önemli, çünkü **yanlış mekanizmayı seçmek ikisini birden
harcıyor.** "Yeni sohbet aç" diye bir politika yazarsanız, hem kural işlemez hem
de kural yazan kişi itibar kaybeder.

---

## Slayt 51 — Always-on dosyayı küçültmek

Labda bu komutu çalıştıracaksınız. `.github` altındaki her dosyanın kaç token
ettiğini gösteriyor.

Hedef: `copilot-instructions.md` 500 token altı.

Bir uyarı. Bu tahminler sadece sezgi için. Gerçek tokenizasyon modele özgü.

Ve sizin için özel bir not: **Türkçe metin, aynı içerik için İngilizceden belirgin
biçimde fazla token üretiyor.** Prompt'larınızı Türkçe yazıyorsanız bunu hesaba
katın.

Rapor edeceğiniz, bütçeleyeceğiniz hiçbir şeyde tahmin kullanmayın. GitHub
kullanım raporu var.

---

## Slayt 52 — Model yönlendirme tablosu

Ekipiniz için bir sayfa. İskelet ekranda, kendinizinkini labda yazacaksınız.

Şimdi kırmızı kutuya bakın, çünkü bu günün en ironik hatası.

**Bu tabloyu `copilot-instructions.md`'ye koymayın.**

Koyarsanız ne olur? Maliyeti düşürmek için yazdığınız tablo, her isteğe eklenerek
maliyeti artırır. Sonsuza kadar.

Üstelik modelin **karar vermediği** bir şeyi modele anlatmış olursunuz. Model kendi
modelini seçmiyor. Siz seçiyorsunuz.

Bu tablo wiki'ye ait. İnsanlar bir kez okur.

---

## Slayt 53 — Önce ve sonra ölçün

Gerçek bir işi seçin ve iki kez yapın.

**Önce:** klasörün tamamı bağlamda, güçlü model, uzun süren bir sohbetin ortasında
sorulmuş.

**Sonra:** yeni sohbet, sadece ilgili dosya, hafif model, net tek istek.

Dört satır dolduracaksınız: model, dosya sayısı, harcanan kredi, ve —

[Dördüncü satırı işaret et.]

— cevap kabul edilebilir miydi?

Bu tabloyu basılı dağıtacağım. Gördüğünüz tabloyu doldurursunuz.

---

## Slayt 54 — Ucuzlatmak hedef değil

Bu slaydı atlamayacağım, çünkü günün dürüstlük teminatı burada.

[Koyu kutuyu oku.]

**İşi yapamayan bir kurulum üreten optimizasyon, optimizasyon değildir.**

Başarısızlık biçimi şöyle işliyor. Fatura düşüyor. Kabul oranı da düşüyor.
İnsanlar işi yavaş yavaş elle yapmaya dönüyor. Ve kimse bunu raporlamıyor — çünkü
herkesin baktığı metrik iyi görünüyor.

Kontrol basit: **kabul edilebilirliği maliyetle aynı tabloya yazın.** Kalite
düştüyse değişiklik başarısızdır. Ne kadar tasarruf ettirdiği önemli değil.

Ve raporlarken ikisini birlikte raporlayın. Yoksa ikinci rakamı bir başkası,
daha kötü bir anda keşfeder.

Son not: bazı işler gerçekten güçlü modeli hak ediyor. Onları bulmak
yönlendirmenin **parçası**, ona istisna değil.

---

## Slayt 55 — Lab 4 brifingi

Bir saat. Beş adım.

İkinci adım günün en iyi tartışmalarını üretiyor — kendi dosyanızı keseceksiniz.
Zaman ayırın, tartışın, birbirinize itiraz edin.

Beşinci adımda üç satır yazacaksınız. Sadece üç.

Yarın uygulayabileceğiniz bir kural. Bu çeyrekte yapacağınız bir değişiklik. Ve
hâlâ ihtiyacınız olan bir veri.

O üç satırı saklayın. Takip oturumunda karşılaştıracağımız şey o.

[60 dakika lab.]

---

# KAPANIŞ (16:30–17:00)

## Slayt 56 — Kapanış atölyesi

Son otuz dakika. Üçer kişilik gruplar oluşturun.

Her gruba bir başlık vereceğim ve bir sayfa yazacaksınız. Sonra üçer dakika
sunacaksınız.

**Birinci grup: model yönlendirme tablosu.** Hangi iş sınıfı hangi model
sınıfına, ve kim aşabilir.

**İkinci grup: MCP onay süreci.** Sunucuyu kim onaylıyor, hangi ölçütlere göre, ve
onaylı liste nerede duruyor.

**Üçüncü grup: talimat dosyası sahipliği.** Kim değiştirebilir, hangi incelemeden
geçiyor, token bütçesi ne.

**Dördüncü grup: ölçüm ritmi.** Kim hangi raporu okuyor, hangi sıklıkla, ve havuz
aşıma girdiğinde ne oluyor.

Şunu söyleyeyim: burada üreteceğiniz metin günün kalıcı değeri. Öncesindeki her
şey bunu yazabilmek için hazırlıktı.

Ve o dört sayfayı kimse odadan çıkmadan toplayacağım.

[20 dakika grup çalışması, sonra sunumlar.]

---

## Slayt 57 — Tek sayfalık özet

Bunu basılı olarak dağıtıyorum. Masanıza koyacağınız kart bu.

Üç sütun. Her sütunun son satırı bir kural.

**Dosyalar:** her soruda gerekli değilse always-on dosyaya girmez.

**MCP:** yerel içeride demek değil. Kullanmadığınızı kapatın.

**Maliyet:** Settings, Billing, Usage'dan ölçün. Asla tahmin etmeyin.

Başka bir şey eklemeyeceğim. Gün buydu.

---

## Slayt 58 — Bundan sonra ne oluyor

Bir atölye bir etkinliktir. Onu programa çeviren şey ölçülen bir takip.

**Bu hafta:** kapanışta yazdığınız dört sayfayı yayımlayın. Always-on dosya için
ve onaylı MCP sunucu listesi için birer sahip atayın.

**Bu ay:** ölçüm ritmini kurun. Ekip bazlı tüketim, havuza karşı, isimli bir kişi
tarafından, sabit bir tarihte okunuyor.

**Dört-altı hafta sonra:** yarım günlük takip. Bugün öngörülen tasarrufla gerçekte
olanı karşılaştırın. Tutmadığı yerde politikayı düzeltin.

Ve son kez: fiyatlar, model isimleri ve plan detayları değişiyor. Bu rakamları
yeniden kullanmadan önce GitHub Docs'tan doğrulayın.

---

## Slayt 59 — Neyi götürüyorsunuz

Repo elinizde. Çevrimdışı çalışıyor — anahtar yok, ağ erişimi yok, yirmi sekiz
test geçiyor.

Üç komut yeter: bağımlılıkları kurun, testleri çalıştırın, senaryo scriptini
çalıştırın.

Ve şu son satır: fiyat tablosunu güncellemeden bu rakamları hiçbir yerde
sunmayın.

---

## Slayt 60 — Kapanış

Başladığımız yere dönelim.

**Bağlam bir bütçedir.**

Sabah bunu bir slogan olarak duydunuz. Şimdi ne gönderdiğinizi, neyi açtığınızı ve
ne ödediğinizi biliyorsunuz. Ve üçünü de kendi makinenizde ölçtünüz.

Üç şey bırakıyorum.

**Yarın:** tamamlamanın halledebileceği işi sohbete taşımayı bırakın. Bunun için
kimseden izin almanız gerekmiyor.

**Bu çeyrek:** always-on dosyanın ve onaylı sunucu listesinin sahibi olun.

**Sürekli:** kullanım raporunu her ay, sabit bir tarihte okuyun.

Teşekkür ederim. Sorularınızı alayım, sonra dört sayfayı toplayacağım.

[Soruları al. Dört sayfayı topla. Kimse çıkmadan.]

---

# Kullanım notu

Bu metni bir kez baştan sona oku, sonra kapat.

Anlatırken açık tutacağın belge `SUNUM-KILAVUZU.md` olmalı — o özet ve tempo
tutucu. Bu dosya hazırlık içindir.

Odaya okunan metin, odanın anında fark ettiği tek şeydir.
