# Lab 2 — MCP server

**Duration:** 60 minutes (11:45–12:45)
**Who:** everyone connects the server; the second half splits into two tracks
**Goal:** expose an internal resource to Copilot as a tool, and find where its limits are

---

## Step 1 — Set up the environment and find your paths (15 min)

This is the most common point of failure. Go through it carefully.

### 1a. Virtual environment

Do not install into the system Python. On macOS, Homebrew's Python refuses
(`externally-managed-environment`); with Anaconda, packages land in the wrong
environment.

```bash
cd <repo-folder>
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt
python -m pytest tests -q          # expect: 28 passed
```

If `pip install mcp` fails on a PyJWT conflict:

```bash
python -m pip install mcp --ignore-installed PyJWT
```

Check that your prompt now starts with `(.venv)`. It disappears in a new
terminal; re-run the activate line.

### 1b. Get the interpreter's full path

```bash
which python                       # Windows: where python
pwd
```

You should see something like `<repo>/.venv/bin/python`. Note both values.

### 1c. Put the full path in mcp.json

`.vscode/mcp.json` ships with `"command": "python"`, and that is **wrong**.
Rather than editing it by hand, run this — it finds the correct paths and writes
the file for you:

```bash
python - <<'EOF'
import json, sys, pathlib
root = pathlib.Path.cwd()
cfg = root / ".vscode" / "mcp.json"
cfg.parent.mkdir(exist_ok=True)
cfg.write_text(json.dumps({
    "servers": {
        "corp-internal": {
            "type": "stdio",
            "command": sys.executable,
            "args": [str(root / "mcp_server" / "corp_server.py")],
        }
    }
}, indent=2))
print(cfg.read_text())
EOF
```

`sys.executable` is the active environment's interpreter, so the path is correct
by construction. Check that both paths in the output contain `.venv`.

> **Why this matters so much:** plain `python` resolves to whatever comes first
> on PATH — usually the system Python or an Anaconda base environment. The `mcp`
> package is not there, so the process dies instantly. VS Code shows an error
> but the **output channel stays empty**, because the process never got as far
> as writing anything. It is a failure with no visible cause, and it can eat
> hours.

### 1d. Run the server by hand once

Before touching VS Code. Don't retype the path — paste this as-is:

```bash
"$(pwd)/.venv/bin/python" "$(pwd)/mcp_server/corp_server.py"
```

If the terminal hangs and waits, that is **correct** — the server is listening
on stdin. `Ctrl+C` to exit. If it prints a traceback, the fault is here, and you
have just seen what VS Code would have hidden from you.

> `no such file or directory` means either you are not in the repo root (`pwd`)
> or `.venv` was never created (`ls -d .venv`).

### 1e. Start it in VS Code

1. Quit VS Code completely (`Cmd+Q` / `Alt+F4`), reopen it
2. `File → Open Folder` → select the **repo root** (the folder containing `.vscode`)
3. Answer **Yes, I trust the authors** — in an untrusted folder MCP servers are
   never listed and no error is shown
4. Command palette (`Ctrl/Cmd + Shift + P`) → **MCP: List Servers**
5. `corp-internal` → **Start Server**
6. Confirm the chat is in the **Agent** role

### 1f. Verify

Type `#` in the chat. Five tools should be listed. If not, ask directly:

```
Run the standards_list tool.
```

An **"Allow tool from corp-internal"** prompt means everything is working. That
prompt is not incidental — it is exactly what Step 2 is about.

---

## Troubleshooting

| Symptom | Cause |
|---|---|
| List is completely empty | VS Code opened the wrong folder. Run `pwd` in the integrated terminal. |
| Error shown, output channel empty | `command` points at the wrong interpreter. Back to 1b. |
| `corp-internal` defined twice | A user-level `mcp.json` is conflicting with the workspace file. Rename the user one temporarily. |
| Server runs but no tools appear | The role selector is not on Agent. |
| `command not found: pip` | The virtual environment is not active. `source .venv/bin/activate`. |

---

## Step 2 — Use the tools (10 min)

Ask these three, one at a time, each in its own chat:

```
Which internal APIs hold no personal data?
```
```
Can we deploy to production today?
```
```
Can we deploy on 14 August 2026?
```

Copilot will ask permission before each tool call. Click **Allow** and read the
prompt before you do — that prompt is the audit trail.

The third question must come back as **no**, **with a reason**. Note that the
tool returns the reason rather than just `false`. That is the mark of a
well-designed tool: the model cannot invent a justification, it has to quote one.

---

## Step 3A — Engineers: write a tool (25 min)

Add this to `mcp_server/corp_server.py`:

```python
@mcp.tool()
def find_service_owner(service_name: str) -> str:
    """Return the team accountable for a service.

    Use when the user needs to know who to contact about a service — before
    filing a ticket or escalating an incident. Call api_search first if you
    only have a partial name.

    Args:
        service_name: a key or name from the API catalogue.
    """
    ...
```

Three rules while you write it:

1. **The docstring is the interface.** The model chooses tools by reading it.
   Write *when to call this*, not *what it does*.
2. **Fail helpfully.** On a miss, return the available options so the model can
   correct itself instead of guessing.
3. **Return no personal data.**

Then add a test to `tests/test_mcp_tools.py`, following the existing pattern:

```python
def test_find_service_owner_returns_the_team():
    result = call(find_service_owner, service_name="limit-engine")
    assert result["owner_team"] == "Credit Technology"


def test_unknown_service_lists_alternatives():
    result = call(find_service_owner, service_name="nope")
    assert "error" in result
    assert "limit-engine" in result["available"]
```

Run it, then reload the server and try it live:

```bash
python -m pytest tests -q
```

Command palette → **MCP: Restart Server** → ask Copilot: `Who owns the limit engine?`

---

## Step 3B — Analysts: review the tools (25 min)

You are not writing a tool. You are answering the harder question: which tool
should not exist.

Open `mcp_server/corp_server.py` and read the five docstrings. Write short
answers to these:

1. Which description could lead the model to pick the **wrong** tool? Rewrite it.
2. What would break if `api_search` did not have the `pii_free_only` parameter?
3. Name a tool that should **not** be added to this server, and argue why.
   Be specific: name the data it would return and name what goes wrong.
4. `can_deploy` returns a reason as well as a verdict. What would be lost if it
   returned only `true`/`false`?

You present first in the debrief. Two minutes.

> This is not the easy track. In a bank the critical question is *which tool
> must not be written*, and that question belongs to the person who understands
> the business consequence, not the person who understands Python.

---

## Step 4 — The cost of the server (10 min)

Everyone, in the chat:

```
Run the tool_cost tool.
```

Read the output. Those schemas are sent on **every request made while this
server is connected** — including requests that have nothing to do with it.

Now do the arithmetic out loud: ten connected servers with eight tools each is
eighty tool schemas prepended to every question anyone asks. Copilot's ceiling
is 128 tools per request, but the quality degradation starts far earlier,
because the model has to choose between them.

**Rule to take away:** disconnect servers you are not using today. Connecting a
server is not free.

---

## Deliverables

- [ ] Server connected, five tools visible, all three questions answered
- [ ] Engineers: `find_service_owner` written, tests passing, working live
- [ ] Analysts: written answers to the four review questions
- [ ] `tool_cost()` output read and the arithmetic done

---

## Discussion question

This server deliberately returns no customer data. If a team wanted to write a
customer-lookup tool, which approvals should it pass — and who makes the call:
the developer, architecture, or compliance?
