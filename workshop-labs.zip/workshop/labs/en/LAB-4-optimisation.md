# Lab 4 — Optimisation

**Duration:** 60 minutes (15:30–16:30)
**Who:** everyone
**Goal:** lower the number you measured in Lab 3, then measure it again

---

## Step 1 — Weigh every file (10 min)

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import estimate_tokens
from pathlib import Path
total = 0
for f in sorted(Path('.github').rglob('*.md')):
    t = estimate_tokens(f.read_text()); total += t
    print(f'{t:>6} tokens  {f}')
print(f'{total:>6} tokens  TOTAL')
"
```

Run the same command against **your own repository**. That number is what you
are working with today.

> Estimates are for intuition only. Real tokenisation is model-specific, and
> Turkish text produces noticeably more tokens than English for the same
> content. For anything you will report against, use the GitHub usage report.

---

## Step 2 — Cut the always-on file (20 min)

Take your own `copilot-instructions.md`. For each line, apply the Lab 1 test:

| Share of questions that need it | Action |
|---|---|
| 80%+ | keep |
| 20–80% | move to `instructions/` with an `applyTo` glob |
| under 20% | move to a `.prompt.md`, called on demand |

**Target: under 500 tokens.** The example in this repo is about 290.

If you cannot get there, you are using the file as a wiki. That content is not
worthless — it is in the wrong place.

Re-measure after cutting, and compute what you saved:

```
tokens_removed x requests_per_person_per_day x people x workdays = tokens/month
```

Multiply by your model's input price per million. That is a real annual number
you can quote to a manager.

---

## Step 3 — Write the model routing table (10 min)

One page for your team. Start from this skeleton and make it yours:

| Task type | Model class | Why |
|---|---|---|
| Inline completion | default | not metered at all |
| Simple questions, reading code | light | no real reasoning required |
| Debugging, refactoring | balanced | the honest middle for daily work |
| Architecture, complex agent runs | frontier | genuinely earns the price |
| Code review | selective | expensive per run — use where it pays |

**Do not put this table in `copilot-instructions.md`.** It would then be
re-sent on every request forever, to tell the model something the model does not
decide. Put it on the team wiki, where humans read it once.

Decide two more things while you are here:
- Who may override the routing, and does anyone need to know when they do?
- What is the default model for a brand new chat in your organisation?

---

## Step 4 — Before and after, on a real task (15 min)

Pick one task you actually did this week. Do it twice.

**Before:** whole folder in context, frontier model, asked in the middle of a
long-running thread.

**After:** fresh chat, only the relevant file, light model, one precisely
stated request.

Check GitHub → Settings → Billing → Usage between the two runs.

| | Before | After |
|---|---|---|
| Model used | | |
| Files in context | | |
| Credits consumed | | |
| Was the answer acceptable? | | |

**The critical question:** did you make it cheaper by making it worse? An
optimisation that produces a setup which cannot do the work is not an
optimisation. Report savings and quality together, or someone else will
discover the second number at a worse moment.

---

## Step 5 — Your action plan (5 min)

Write exactly three lines:

1. **Tomorrow:** one rule you can apply without asking anyone's permission.
2. **This quarter:** one change that needs a decision or an owner.
3. **Still missing:** one piece of data you need before you can decide.

Keep this. It is what you will be measured against at the follow-up session.

---

## The seven levers, for reference

Largest impact first:

1. **Right surface** — completion is not metered; do not move that work to chat
2. **Model routing** — up to 25x on the same request
3. **Context discipline** — every attached file is re-sent every turn
4. **Cache-friendly ordering** — keep the stable part stable
5. **Tool budget** — disconnect MCP servers you are not using
6. **New chat reflex** — topic changed, start again
7. **Retry cost** — one good prompt beats three poor ones

---

## Deliverables

- [ ] Always-on file under 500 tokens, saving computed in money
- [ ] Model routing table drafted, on the wiki not in the repo
- [ ] Before/after measurement, all four rows including quality
- [ ] Three-line action plan written down

---

## Discussion question

Which of the seven levers can be imposed as a rule, and which only settle in as
habits? For the ones you can impose — is the mechanism a policy, a default
setting, or training? Using the wrong mechanism wastes both.
