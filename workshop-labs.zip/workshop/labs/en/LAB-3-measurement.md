# Lab 3 — Measurement

**Duration:** 45 minutes (14:15–15:00)
**Who:** everyone
**Goal:** replace your estimate with a measurement, and verify all three thresholds yourself

---

## Step 1 — Find your real number (10 min)

Go to **GitHub → Settings → Billing → Usage**.

Write down three things:

| | Your figure |
|---|---|
| AI Credits consumed this month | |
| Which models appear in the mix | |
| Percentage of the included allowance used | |

If you do not have access, the instructor will show their own screen — but note
who in your organisation *does* have access, because you will need them next month.

> **Do not skip this step.** Everything after it anchors on this number.
> Budgeting from an estimate is the polite form of not measuring at all.

---

## Step 2 — Run the scenario script (10 min)

```bash
python cost/scenarios.py
```

Read the summary table at the bottom. Three scenarios, same work, three prices.

Now make it yours. Open `cost/scenarios.py` and change the three constants at
the top:

```python
SEATS = 120           # your team size
WORKDAYS = 21
ALLOWANCE = 19.0      # Business 19, Enterprise 39
```

Then rewrite the `interactions_per_dev_per_day` list in the `baseline` profile
to match how your team actually works — how many chats a day, roughly how much
context each one carries, which model. Run it again.

**Compare the result against the figure you wrote down in Step 1.** If they are
far apart, your usage assumptions are wrong, not the calculator. Adjust them
until the model roughly matches reality — that calibration *is* the exercise.

---

## Step 3 — Verify the three thresholds (15 min)

Run each of these and read the output. Do not take the slides on trust.

### a) Model choice — 25x

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import Interaction
for m in ('gpt-5.6-luna','gpt-5.6-terra','gpt-5.6-sol'):
    i = Interaction(m, input_tokens=100_000, output_tokens=3_000)
    print(f'{m:>16}  \${i.cost_usd():.4f}  {i.credits():.1f} credits')
"
```

### b) Cache — 10x

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import Interaction
full = Interaction('gpt-5.6-terra', input_tokens=100_000)
cached = Interaction('gpt-5.6-terra', cached_input_tokens=100_000)
print(f'full   \${full.cost_usd():.4f}')
print(f'cached \${cached.cost_usd():.4f}')
print(f'ratio  {full.cost_usd()/cached.cost_usd():.1f}x')
"
```

Then check the honest version — on Anthropic models the cache has a *write*
cost that is higher than plain input:

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import RATES
r = RATES['claude-sonnet-5']
print(f'input {r.input_}  cached {r.cached_input}  cache write {r.cache_write}')
"
```

The cache is an investment that pays back on reuse. On a short-lived context it
can lose money.

### c) Long context — 2x

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import Interaction
for n in (270_000, 280_000):
    i = Interaction('gpt-5.6-terra', input_tokens=n, output_tokens=3_000)
    print(f'{n:>9,} tokens -> \${i.cost_usd():.4f}  long_context={i.breakdown()[\"long_context\"]}')
"
```

3.7% more tokens, 104% more money. There is no gradient — it is a cliff at 272K.

---

## Step 4 — Measure yourself (10 min)

Pick one real task, for example "add a timeout to this service call". Do it
twice, checking the GitHub usage report before and after each run.

**Run A:** add five files to context, use a frontier model, ask inside a long
existing thread.

**Run B:** new chat, only the relevant file, light model, one precisely stated
request.

| | Run A | Run B |
|---|---|---|
| Model used | | |
| Files in context | | |
| Credits consumed | | |
| Was the answer acceptable? | | |

**The fourth row is the one that matters.** If quality dropped, you did not
optimise anything — you just made a cheaper setup that cannot do the work.

---

## Deliverables

- [ ] Your real usage figure, written down
- [ ] `scenarios.py` calibrated against that figure
- [ ] 25x, 10x and 2x each verified from your own terminal
- [ ] One before/after comparison, all four rows filled in

---

## Discussion question

In a pooled allowance, one team's overage is everyone's problem. Who should own
the budget — the team lead or the platform team? And when the pool goes into
overage, which data should be requested first?
