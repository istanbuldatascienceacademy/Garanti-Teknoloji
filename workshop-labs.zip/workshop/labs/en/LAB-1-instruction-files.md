# Lab 1 — Instruction files

**Duration:** 45 minutes (10:15–11:00)
**Who:** everyone — engineers and analysts do the same exercise
**Goal:** steer Copilot's behaviour with files, and see the cost effect of each one

---

## Before you begin

```bash
git clone <workshop-repo>
cd workshop
code .
```

Open Copilot Chat and switch the mode selector at the bottom of the chat box to
**Agent**. Every step below assumes Agent mode.

---

## Step 1 — Measure first (5 min)

Before reading any file, ask Copilot:

```
Which type should I use for monetary amounts in this project?
```

Write the answer down verbatim. You will get something general — "BigDecimal is
usually a good choice, but it depends" — because it does not know your rule.

> **Why this step exists:** if you add the instruction file first, you never see
> the difference. Measure before you change anything, every time.

---

## Step 2 — Add the corporate instruction (10 min)

Open `.github/copilot-instructions.md` and read it. Then ask the **same question
again**, in a **new chat**.

You should now get a definite answer: `BigDecimal`, never `double`.

### Now the real exercise

Go through the file line by line and answer this for each line:

> What percentage of the questions my team asks actually needs this line?

Sort every line into one of three buckets:

| Share of questions | Where it belongs |
|---|---|
| 80%+ | stays in `copilot-instructions.md` |
| 20–80% | move to `instructions/` with an `applyTo` glob |
| under 20% | move to a `.prompt.md`, called on demand |

Measure the file:

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import estimate_tokens
from pathlib import Path
for f in sorted(Path('.github').rglob('*.md')):
    print(f'{estimate_tokens(f.read_text()):>6} tokens  {f}')
"
```

**Expected:** `copilot-instructions.md` is around 290 tokens. Your own
organisation's file is very likely three to ten times that.

> **Discussion:** a 40-line file is harmless. A 400-line file is a fixed tax on
> every question every person on the team asks. That is a budget decision, not
> a formatting opinion.

---

## Step 3 — See what applyTo does (10 min)

Open `.github/instructions/java-service.instructions.md` and look at the
frontmatter:

```yaml
applyTo: "**/*.java"
```

Now run the comparison:

1. Open any `.py` file. In a **new chat**, ask: `What are the layering rules here?`
2. Open any `.java` file. In another **new chat**, ask exactly the same question.

The difference between those two answers is what `applyTo` buys you.

> **New chat each time.** If you ask both questions in one thread, the first
> answer is still in context and the second one is contaminated. This matters
> for every measurement you make today.

**Decision rule to take away:** a rule that holds for every file type goes in
`copilot-instructions.md`. A rule specific to one technology goes under
`instructions/` with `applyTo`.

---

## Step 4 — Prompt files (10 min)

Type in the chat:

```
/service-review
```

with a Java file open. One command replaces a paragraph of instructions you
would otherwise re-type every time.

### Write your own

Pick a task you repeat at least weekly. Create
`.github/prompts/<your-task>.prompt.md`. It must have all three of:

1. **More than one step** — if it is one sentence, you did not need a file.
2. **An explicit output shape** — name the table columns or headings you want back.
3. **A stop at the end** — "report first, wait for approval". Reviewing before
   editing is cheaper than undoing.

Test it by typing `/<your-task>` in the chat.

---

## Step 5 — Chat modes (10 min)

Open `.github/chatmodes/analyst.chatmode.md`. Select **analyst** from the mode
menu under the chat box, then ask:

```
Where are the release calendar rules defined and what do they say?
```

Then try:

```
Write me a service class.
```

It should refuse and tell you to switch to Agent mode.

> **For analysts:** this mode gives you a reader rather than a writer. The
> `tools` field also restricts tool access — fewer tools means fewer schemas in
> context, so the answer is both cheaper and more focused.

---

## Deliverables

- [ ] The before/after answer from Steps 1 and 2, written down
- [ ] At least one line of `copilot-instructions.md` argued about out loud
- [ ] The `applyTo` difference observed live
- [ ] Your own `.prompt.md`, tested with `/command`
- [ ] Analyst mode tried, including the refusal

---

## Discussion question

Who writes these files in your organisation, and who approves them? When one
developer adds a line to `copilot-instructions.md`, the cost lands on everyone.

Is that file code, or is it policy?
