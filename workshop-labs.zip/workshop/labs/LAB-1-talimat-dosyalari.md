# Lab 1 — Talimat dosyaları

**Süre:** 45 dakika (10:15–11:00)
**Kimler:** herkes — geliştirici ve analist aynı uygulamayı yapar
**Hedef:** Copilot'un davranışını dosyayla yönetmek ve her dosyanın maliyet etkisini görmek

---

## Başlamadan önce

```bash
git clone <atolye-repo>
cd workshop
code .
```

Copilot Chat'i aç ve sohbet kutusunun altındaki mod seçicisini **Agent** yap.
Aşağıdaki bütün adımlar Agent modunu varsayıyor.

---

## Adım 1 — Önce ölç (5 dk)

Hiçbir dosyaya bakmadan Copilot'a sor:

```
Bu projede para tutarları için hangi tipi kullanmalıyım?
```

Cevabı olduğu gibi not et. Genel bir şey alacaksın — "BigDecimal genelde iyi bir
seçim ama duruma göre değişir" gibi — çünkü senin kuralını bilmiyor.

> **Bu adım neden var:** talimat dosyasını önce eklersen farkı hiç göremezsin.
> Bugün yapacağın her ölçümde önce ölç, sonra değiştir.

---

## Adım 2 — Kurum talimatını ekle (10 dk)

`.github/copilot-instructions.md` dosyasını aç ve oku. Sonra **aynı soruyu**,
**yeni bir sohbette** tekrar sor.

Artık kesin cevap gelmeli: `BigDecimal`, asla `double`.

### Asıl uygulama

Dosyayı satır satır gez ve her satır için şunu yanıtla:

> Ekibimin sorduğu soruların yüzde kaçında bu satır gerçekten gerekli?

Her satırı üç kutudan birine at:

| Soruların ne kadarında gerekli | Nereye ait |
|---|---|
| %80+ | `copilot-instructions.md`'de kalsın |
| %20–80 | `instructions/` altına, `applyTo` ile |
| %20'nin altı | `.prompt.md` dosyasına, istendiğinde çağrılsın |

Dosyayı tart:

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import estimate_tokens
from pathlib import Path
for f in sorted(Path('.github').rglob('*.md')):
    print(f'{estimate_tokens(f.read_text()):>6} token  {f}')
"
```

**Beklenen:** `copilot-instructions.md` yaklaşık 290 token. Kendi kurumundaki
dosya büyük ihtimalle bunun üç ila on katı.

> **Tartışma:** 40 satırlık bir dosya zararsız. 400 satırlık bir dosya, ekipteki
> herkesin her sorusuna eklenen sabit bir vergidir. Bu bir biçim tercihi değil,
> bütçe kararıdır.

---

## Adım 3 — applyTo'nun ne yaptığını gör (10 dk)

`.github/instructions/java-service.instructions.md` dosyasını aç ve
frontmatter'a bak:

```yaml
applyTo: "**/*.java"
```

Şimdi karşılaştırmayı yap:

1. Herhangi bir `.py` dosyası aç. **Yeni sohbette** sor: `Buradaki katman kuralları neler?`
2. Herhangi bir `.java` dosyası aç. **Başka bir yeni sohbette** aynı soruyu sor.

İki cevap arasındaki fark, `applyTo`'nun sana kazandırdığı şeydir.

> **Her seferinde yeni sohbet.** İkisini tek sohbette sorarsan ilk cevap hâlâ
> bağlamda durur ve ikincisi kirlenir. Bu, bugün yapacağın her ölçüm için
> geçerli — özellikle Lab 3'te.

**Alınacak karar kuralı:** her dosya türünde geçerli bir kural
`copilot-instructions.md`'ye; belirli bir teknolojiye özgü kural `instructions/`
altına, `applyTo` ile.

---

## Adım 4 — Prompt dosyaları (10 dk)

Bir Java dosyası açıkken sohbete yaz:

```
/service-review
```

Tek komut, her seferinde yeniden yazacağın bir paragraf talimatın yerine geçiyor.

### Kendi promptunu yaz

Haftada en az bir kez tekrarladığın bir işi seç.
`.github/prompts/<isin>.prompt.md` dosyasını oluştur. Şu üçü mutlaka olsun:

1. **Birden fazla adım** — tek cümleyse zaten dosyaya ihtiyacın yoktu.
2. **Açık çıktı biçimi** — hangi tablo kolonlarını veya başlıkları istiyorsan yaz.
3. **Sonunda bir duruş** — "önce raporu ver, onay bekle". Düzeltmeden önce
   incelemek, geri almaktan ucuzdur.

Sohbete `/<isin>` yazarak test et.

---

## Adım 5 — Sohbet modları (10 dk)

`.github/chatmodes/analyst.chatmode.md` dosyasını aç. Sohbet kutusunun
altındaki mod menüsünden **analyst** modunu seç ve sor:

```
Sürüm takvimi kuralları nerede tanımlı ve ne diyor?
```

Sonra dene:

```
Bana bir servis sınıfı yaz.
```

Reddetmeli ve Agent moduna geçmen gerektiğini söylemeli.

> **Analistler için:** bu mod sana kod yazan değil, kod okuyan bir asistan
> veriyor. `tools` alanı araç erişimini de kısıtlıyor — daha az araç, bağlamda
> daha az şema, yani hem daha ucuz hem daha odaklı bir cevap.

---

## Çıktılar

- [ ] Adım 1 ve 2'deki önce/sonra cevabı yazılı
- [ ] `copilot-instructions.md`'den en az bir satır sesli tartışıldı
- [ ] `applyTo` farkı canlı gözlendi
- [ ] Kendi `.prompt.md` dosyan, `/komut` ile test edildi
- [ ] Analist modu denendi, reddedişi dahil

---

## Tartışma sorusu

Kurumunda bu dosyaları kim yazar ve kim onaylar? Bir geliştirici
`copilot-instructions.md`'ye satır eklediğinde maliyet herkese yayılıyor.

Bu dosya kod mudur, politika mıdır?
