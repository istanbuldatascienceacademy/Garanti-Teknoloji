# Eğitmen cevap anahtarı

Bu sorular tek doğrusu olan sorular değil. Aşağıdakiler "sağlam cevap"lar —
odayı yönlendirmek, tıkandığında açmak ve gelen cevabın kalitesini ölçmek için.

**Kullanım kuralı:** önce onlar konuşsun. Bu metni açıklama olarak değil,
tartışma tıkandığında atacağın çengel olarak kullan. Katılımcının kendi
kurumundan verdiği örnek, buradaki her cevaptan iyidir.

---

## Lab 1 — "Bu dosya kod mudur, politika mıdır?"

**Kısa cevap:** ikisi de, ve sorun tam olarak bu.

Kod gibi davranıyor — repoda duruyor, PR'la değişiyor, git geçmişi var. Ama
politika gibi sonuç doğuruyor: bir kişinin eklediği satır, ekipteki herkesin her
sorusunun maliyetine giriyor ve kimse fark etmiyor.

Odaya sorulacak asıl üç soru:

| Soru | Çoğu kurumdaki gerçek cevap |
|---|---|
| Kim değiştirebilir? | Commit yetkisi olan herkes — yani karar verilmemiş |
| Hangi incelemeden geçiyor? | Normal PR incelemesi, ki uzunluğa bakmaz |
| Ne zaman yeniden okunuyor? | Hiç. Dosyalar sadece büyür |

**İşleyen model:** paylaşılan yapılandırma dosyası gibi davran — isimli bir
sahip, dosyanın kendi başlığında yazılı bir token bütçesi, çeyreklik gözden
geçirme. Kapsamlı dosyalar (`instructions/`) herkese açık kalabilir; sadece
her-istekte-yüklenen dosya sahiplik ister.

**Odanın kaçtığı yer:** "bunu mimari ekibi yapsın" deyip geçmek. Sor: mimari
ekibi hangi sıklıkla bakacak ve ekip bir kural eklemek istediğinde ne kadar
bekleyecek? Çok yavaş bir süreç, insanları dosyayı hiç kullanmamaya iter.

---

## Lab 2, Adım 3B — Analist kolu değerlendirme soruları

### 1. Hangi açıklama yanlış araç seçtirebilir?

En güçlü aday **`api_search`**. Docstring'i "bir servisin sahibinin kim olduğunu
sorduğunda kullan" diyor. Adım 3A'da `find_service_owner` eklenince ikisi
çakışıyor; model sahiplik sorusunda hangisini çağıracağını bilemiyor.

Düzeltme: `api_search`'ten sahiplik ifadesini çıkar ve yönlendirme ekle —
"servis aramak için; belirli bir servisin sahibi gerekiyorsa `find_service_owner`
kullan."

İkinci aday **`tool_cost`**. Adı ve açıklaması, kullanıcı genel olarak maliyet
sorduğunda modeli çağırmaya davet ediyor; oysa yalnızca *bu sunucunun şema
yükünü* ölçüyor. `server_schema_footprint` adı daha az yanıltırdı.

> Ders: araç isimleri ve açıklamaları bir arayüz sözleşmesidir. Yeni araç
> eklemek, mevcut açıklamaları da gözden geçirmeyi gerektirir.

### 2. `pii_free_only` olmasaydı ne bozulurdu?

Filtreleme sunucunun garantisi olmaktan çıkıp modelin takdirine kalırdı.
Kişisel veri içeren servisler yine bağlama girer, model sonradan "bunları
eleyeyim" derdi.

Fark kritik: eleme **sunucuda** yapılırsa veri hiç dışarı çıkmaz; **modelde**
yapılırsa çıkar, sonra görmezden gelinir. Bir de parametre, ayrımın kodda
açıkça yazılı olmasını sağlıyor — denetlenebilir bir sınır, sözlü bir kural değil.

### 3. Eklenmemesi gereken araç

Bariz cevap `get_customer_transactions` ve odadan genelde o gelir. Kabul et,
sonra daha öğretici olanı ortaya at: **`run_sql(query)`**.

Masum görünür, "esneklik" diye savunulur, ama döndüreceği veri önceden belli
değildir. Onaylanacak bir şema yoktur, denetlenecek bir sınır yoktur, ve tek bir
araçla bankadaki her tabloyu modele açar.

> Ders: sınırı tanımlanamayan araç, tanımlanamaz bir risktir. Bir aracın ne
> döndüreceğini önceden yazamıyorsan, onaylayamazsın da.

### 4. `can_deploy` sadece `true`/`false` dönseydi?

Üç şey kaybolurdu:

- **Model gerekçeyi uydurmak zorunda kalırdı.** "Hayır" der, sebebini kendi
  üretir, kullanıcı ona inanır.
- **Kullanıcı itiraz edemezdi.** "Ay sonu mutabakatı" duyan biri istisna
  sürecini işletebilir; çıplak "hayır" yolu kapatır.
- **Cevap alıntılanabilir olmaktan çıkardı.** Modelin cümlesi kanıt değildir;
  aracın döndürdüğü gerekçe kanıttır.

> Genel ders: iyi bir araç modele karar verdirmez, karar için gereken malzemeyi
> verir.

---

## Lab 2 — "Müşteri sorgulama aracı hangi onaylardan geçmeli?"

Kararı **geliştirici veremez.** Bu, teknik zorluğu düşük, kurumsal sonucu ağır
bir karardır ve ikisi karıştırıldığı için tehlikelidir.

Onay sürecinin yanıtlaması gereken üç soru:

1. **Ne döndürüyor?** Hangi alanlar, hangi sistemden, ve bunların herhangi biri
   kişisel veri mi? "Müşteri bilgisi" yeterli değil — alan listesi lazım.
2. **Kim sahibi?** Sunucuyu bakan ve araç yanlış şey döndürmeye başladığında
   cevap veren isimli bir ekip.
3. **Kim bağlayabilir?** Tüm mühendisler mi, tek ekip mi, tek proje mi — başka
   her erişim yetkisi gibi kapsamlandırılmış.

Odaya sorulacak asıl soru: **denetçi geçen ay bir araç çağrısı üzerinden hangi
verinin sınır dışına çıktığını sorsa, kim cevap verebilir?** Cevap yoksa MCP
politikanızın başlangıç noktası burasıdır.

**Odanın kaçtığı yer:** "zaten yerelde çalışıyor" savunması. Hatırlat: aracın
döndürdüğü her şey bağlama giriyor, bağlam da model sağlayıcısına gidiyor.
Yerel çalışmak, verinin içeride kaldığı anlamına gelmiyor.

---

## Lab 3, Adım 4 — Kendini ölç (A/B koşusu)

Bu bir tartışma değil, ölçüm. "Cevap" tek bir rakam değil, **iyi bir sonucun
neye benzediği**.

### Beklenen büyüklük

Örnek bir görev — "şu servis çağrısına zaman aşımı ekle" — iki kurulumda:

| | Model | Girdi | Çıktı | Maliyet |
|---|---|---|---|---|
| **A** 5 dosya, güçlü model, uzun sohbet | Sol | 95.000 | 1.200 | $0,5110 (51 kredi) |
| **B** yeni sohbet, 1 dosya, hafif model | Luna | 6.000 | 900 | $0,0023 (0,2 kredi) |

**Oran: 224x.** Oda buna inanmayabilir; o yüzden değişkenleri ayır.

### Asıl öğretici kısım: çarpım etkisi

Tek tek değiştirirsen:

| Değişen | Maliyet | Kazanç |
|---|---|---|
| Sadece model (bağlam aynı) | $0,0204 | 25x |
| Sadece bağlam (model aynı) | $0,0570 | 9x |
| İkisi birden | $0,0023 | **224x** |

25 × 9 = 225. Kaldıraçlar toplanmıyor, **çarpılıyor**. Odaya bunu hesaplat:
"model yönlendirme %60 tasarruf, bağlam disiplini %50 tasarruf, toplam %110 mu?"
Hayır — ikisi de oranı böler, yüzdeleri toplanmaz.

> Bu, Lab 4'ün yedi kaldıraç sıralamasının gerekçesi. İlk üçünü birden
> uygularsan, tek tek uygulamanın toplamından fazlasını alırsın.

### Odanın yaptığı üç hata

1. **İki koşuyu aynı sohbette yapmak.** A'nın bağlamı hâlâ durur, B kirlenir.
   Lab 1 Adım 3'te aynı uyarıyı verdik; burada da tekrarla.
2. **Aynı anda üç şeyi birden değiştirip hangisinin işe yaradığını bilememek.**
   Yukarıdaki ayrıştırmayı yaptır.
3. **Dördüncü satırı boş bırakmak.** En sık ve en tehlikeli olanı — aşağıda.

### Dördüncü satır: "Cevap kabul edilebilir mi?"

Bu satır boşsa ölçüm geçersizdir. Sor:

- B koşusunun cevabını gerçekten kullanır mıydın, yoksa A'yı görmüş olduğun için
  mi kabul edilebilir göründü?
- B yanlış cevap verdiyse ve tekrar sorman gerekseydi, maliyet hâlâ düşük müydü?

**Beklenen sonuç dürüstse:** rutin işlerde B kabul edilebilir çıkar. Bazı
görevlerde çıkmaz — ve o görevleri bulmak, yönlendirmenin kendisidir, ona
istisna değil.

Bir katılımcı "hafif model işe yaramadı" derse bu bir **başarısızlık değil,
bulgu**. Hangi görevdi, neyi kaçırdı? Cevap, yönlendirme tablosunun "güçlü
model" satırına gider.

---

**Kısa cevap:** ikisinin de, ama farklı şeylerden sorumlu olarak.

| | Elinde olan | Eksik olan |
|---|---|---|
| Ekip lideri | Davranışa yakınlık, değiştirme gücü | Havuzu görememe, diğer ekiplere kaldıraç yok |
| Platform ekibi | Havuzun tamamını görme, merkezî varsayılan | Harcamayı üreten işe uzaklık |

**İşleyen model:** platform ekip bazlı tüketimi aylık yayımlar, ekip liderleri
kendi satırlarından sorumlu olur. İkisi birbirinin yerine geçmez.

### "Havuz aşıma girdiğinde ilk hangi veri istenmeli?"

Sıralama önemli, çünkü yanlış sırayla sorarsan insanları savunmaya geçirirsin:

1. **Model karışımı.** Güçlü model baskınsa tek başına yönlendirme faturayı
   ciddi biçimde hareket ettirir. Kimseyi suçlamayan, en hızlı kazanç.
2. **Yüzey dağılımı.** Tamamlamayla halledilebilecek iş ne kadar sohbete
   taşınmış? Ölçülmeyen bir şey ücretliye dönüştürülmüş olabilir.
3. **İstek başına ortalama bağlam.** Uzun sohbetler ve klasör ekleme alışkanlığı
   burada görünür.
4. **En son: kişi bazlı tüketim.** Buradan başlarsan konu bütçe olmaktan çıkar,
   performans değerlendirmesine döner ve kimse dürüst veri vermez.

> Odaya sor: bu dört veriden hangisini bugün çekebilirsiniz? Çoğu kurumda cevap
> "ilk ikisi" — bu da ölçüm ritmi maddesinin gerekçesi olur.

---

## Lab 4, Adım 2 — Always-on dosyayı kesme

### Repodaki örnek dosya neden 290 token?

Katılımcı "benimki 1.800 token, sizinki hile" diyebilir. Dosyayı birlikte aç ve
her satırın neden hayatta kaldığını göster:

| Satır | Kalma gerekçesi |
|---|---|
| `BigDecimal`, asla `double` | Java'da da Python'da da geçerli, para her yerde var |
| Loglarda müşteri kimliği yok | Dil bağımsız, ihlali pahalı |
| SQL parametreli | Her dilde geçerli |
| Dış çağrılarda zaman aşımı | Her serviste geçerli |
| Sırlar kodda değil | Her dosyada geçerli |
| "Bilmiyorsan sor" | Modelin uydurmasını engelleyen tek satır |

Altı satır. Hepsi **soruların %80'inden fazlasında** geçerli ve hepsinin ihlali
pahalı. Ölçüt bu.

### Tipik kurumsal dosyada ne kesilir

| Kesilen içerik | Nereye |
|---|---|
| Spring Boot katman kuralları | `instructions/` + `applyTo: "**/*.java"` |
| pandas/numpy kuralları | `instructions/` + `applyTo: "**/*.py"` |
| Kod inceleme kontrol listesi | `.prompt.md` — sadece inceleme yaparken |
| Onboarding metni, takım tanıtımı | Wiki. Model bunu okumuyor bile |
| Model yönlendirme tablosu | Wiki (Adım 3'te ayrıca konuşulacak) |
| Commit mesajı formatı | `.prompt.md` veya git hook |

### Tasarrufu paraya çevirme

120 kişi × 4 istek × 21 gün varsayımıyla:

| Kesilen | Aylık token | Dengeli model | Yıllık |
|---|---|---|---|
| 500 token | 5,04M | $10,08 | $121 |
| 1.000 token | 10,08M | $20,16 | $242 |
| 2.000 token | 20,16M | $40,32 | $484 |

Güçlü modelde bu rakamlar **2,5 katına** çıkar — 1.000 token için ayda ~$50.

> **Odanın tepkisi:** "yıllık 242 dolar mı? Bu kadar uğraşa değmez."
> Cevabın hazır olsun: tek başına değmez. Ama bu **tek bir dosya**. Yedi
> kaldıracın hepsi aynı büyüklükte ve çarpılıyorlar — Lab 3 Adım 4'teki 224x
> tam da bu yüzden çıktı. Ayrıca bu rakam, hiç kimsenin okumadığı satırlar için.

### Sahte sonucun işareti

Biri dosyayı 1.800'den 400'e indirdiyse ve **hiçbir satırı taşımadıysa**,
muhtemelen gerçekten gerekli kuralları silmiştir. Sor: kestiğin satırlar nereye
gitti? Cevap "sildim" ise dosyayı geri al ve yeniden yap. Amaç küçültmek değil,
**doğru yere koymak**.

---

## Lab 4, Adım 3 — Model yönlendirme tablosu

### İyi bir tablonun üç özelliği

**1. Model adı değil, model sınıfı yazar.** "GPT-5.6 Terra" yazan tablo altı ay
sonra ölür. "Dengeli" yazan tablo yaşar; hangi modelin dengeli olduğu ayrı bir
satırda tutulur ve tek yerden güncellenir.

**2. İş türüne göre yazılır, kişiye göre değil.** "Kıdemli geliştiriciler güçlü
model kullanır" kötü bir kuraldır — kıdemli bir geliştiricinin PR açıklaması da
hafif modelle yazılır.

**3. Aşma yolunu tanımlar.** "Cevap yeterli değilse güçlü modele geç" cümlesi
tabloda yazılı olmalı. Yoksa insanlar ya kuralı çiğner ya da kötü cevapla
yetinir; ikisi de kötü.

### İki karar

**Yeni sohbetin varsayılan modeli ne olmalı?** Doğru cevap hemen hemen her zaman
"hafif". Gerekçe: yükseltmek bir tıklama, ama güçlü modelde başlayıp fark
etmemek bütün gün sürebilir. Varsayılan, unutulduğunda geçerli olan şeydir —
o yüzden ucuz tarafta dursun.

**Yönlendirmeyi kim aşabilir?** Herkes. Ama Lab 3'teki ölçüm ritmi varsa, ay
sonunda karışım raporunda görünür. Denetim, izin isteme zorunluluğundan daha iyi
çalışır ve kimseyi yavaşlatmaz.

### En sık hata

Tabloyu `copilot-instructions.md`'ye koymak. Bu, günün en ironik hatası:
maliyeti düşürmek için yazılan tablo, her isteğe eklenerek maliyeti artırır.
Üstelik modelin karar vermediği bir şeyi modele anlatır — model kendi modelini
seçmiyor, sen seçiyorsun.

Odada biri bunu yaparsa **düzeltme, göster.** Adım 1'deki token ölçüm komutunu
tekrar çalıştırt; tablonun kaç token ettiğini ve bunun aylık faturaya
çevrilmesini birlikte hesaplayın.

---

## Lab 4, Adım 4 — Gerçek işte önce/sonra

Lab 3 Adım 4 ile aynı iskelet, ama iki fark var: **kendi işi**, ve **kalite
satırı artık zorunlu**.

### İyi sonuç neye benzer

| | Beklenen |
|---|---|
| Kredi düşüşü | 10x–100x arası, işe göre |
| Kalite | Aynı, veya "kabul edilebilir" |
| Süre | Genelde **kısalır** — az bağlam, hızlı cevap |

Süre satırını lab'da istemedik ama odada birileri fark eder. Fark ederlerse
öne çıkar: az bağlam sadece ucuz değil, hızlı.

### Sahte sonucun üç işareti

1. **Kalite satırı boş ya da "iyi" yazıyor, gerekçe yok.** Sor: cevabı
   kullandın mı, yoksa sadece makul mü göründü?
2. **"Sonra" koşusu farklı bir iş.** Kolay görevi hafif modelle yapıp zoru güçlü
   modelde bırakmak ölçüm değil, seçim. İki koşu **aynı işi** yapmalı.
3. **Kredi düşüşü çok büyük ama iş yarım.** Model dosyayı görmediği için kısa
   cevap vermiştir. Çıktının gerçekten görevi tamamlayıp tamamlamadığına bak.

### Kalite düştüyse ne yapılır

Bu bir başarısızlık değil, **yönlendirme tablosunun girdisi**. Sırayla dene:

1. Bağlamı aynı bırak, sadece modeli yükselt — kalite dönüyor mu? Dönüyorsa iş
   gerçekten güçlü model istiyor, tabloya yaz.
2. Model aynı kalsın, bir dosya daha ekle — kalite dönüyor mu? Dönüyorsa sorun
   modelde değil, eksik bağlamdaydı.

Bu iki denemenin ayrı ayrı yapılması önemli. Aynı anda ikisini birden geri
alırsan hangisinin gerektiğini asla öğrenemezsin — ve gereksiz olanı sonsuza
kadar ödersin.

> **Kapanışta söylenecek:** ucuzlatmak hedef değil. Hedef aynı sonucu daha ucuza
> almak. İkisi farklı hedeflerdir ve ikincisini ölçmenin tek yolu kalite
> satırını doldurmaktır.

---

Mekanizma ile hedefi eşleştirmek, günün en pratik çıktısı.

| Kaldıraç | Mekanizma | Neden |
|---|---|---|
| 1. Doğru yüzey | Eğitim + örnek | Karar anında olur, denetlenemez |
| 2. Model yönlendirme | Varsayılan ayar | Yeni sohbetin varsayılan modeli merkezî belirlenebilir |
| 3. Bağlam disiplini | Eğitim + inceleme | Ne kadar bağlamın gerektiği işe göre değişir |
| 4. Önbellek sıralaması | Politika | "Talimat dosyaları toplu güncellenir" yazılı kural olur |
| 5. Araç bütçesi | Politika + onaylı liste | Bağlanabilecek sunucular merkezî kısıtlanabilir |
| 6. Yeni sohbet refleksi | Alışkanlık | Dayatılamaz; sadece örnekle yerleşir |
| 7. Yeniden deneme maliyeti | Eğitim | Prompt kalitesi beceridir, kural değil |

**Asıl ders:** 4 ve 5 bir ayar veya politika olabilir — bir kez kurarsın, işler.
6 ve 7 ancak örnek ve geri bildirimle yerleşir; onlara politika yazmak boşa
gider ve kural yazan kişiyi de itibarsızlaştırır.

**Odanın kaçtığı yer:** her şeyi politikaya bağlamak istemek. Bu bankada tanıdık
bir refleks. Sor: "yeni sohbet aç" kuralını nasıl denetleyeceksiniz? Denetlenemez
bir kural, kural değil, temennidir.

---

## Kapanış atölyesi — dört sayfa neye benzemeli

Gruplar iyi bir şey üretmiş mi, buradan anlarsın.

**1. Model yönlendirme tablosu.** İyi olanı iş türüne göre yazılmıştır, model
adına göre değil — çünkü model adları altı ayda değişir, iş türleri değişmez.
Ayrıca "kim aşabilir" sorusunu yanıtlar.

**2. MCP onay süreci.** İyi olanı üç soruyu yanıtlar (ne döndürüyor, kim sahibi,
kim bağlayabilir) ve reddedilen bir örnek içerir. Reddetme örneği olmayan süreç,
onay makinesidir.

**3. Talimat dosyası sahipliği.** İyi olanı isim içerir. "Mimari ekibi" isim
değildir. Ayrıca bir token bütçesi ve gözden geçirme tarihi vardır.

**4. Ölçüm ritmi.** İyi olanı üç şeyi belirler: kim okuyor, hangi tarihte, ve
hangi eşikte kime haber veriliyor. Ay sonunu beklemek ritim değildir.

**Kapanışta söylenecek:** bu dört sayfa günün kalıcı çıktısı. Öncesindeki her
şey bunları yazabilmek için hazırlıktı. Kimse odadan çıkmadan topla.
