# Lab 4 — Optimizasyon

**Süre:** 60 dakika (15:30–16:30)
**Kimler:** herkes
**Hedef:** Lab 3'te ölçtüğün rakamı düşürmek, sonra tekrar ölçmek

---

## Adım 1 — Her dosyayı tart (10 dk)

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import estimate_tokens
from pathlib import Path
toplam = 0
for f in sorted(Path('.github').rglob('*.md')):
    t = estimate_tokens(f.read_text()); toplam += t
    print(f'{t:>6} token  {f}')
print(f'{toplam:>6} token  TOPLAM')
"
```

Aynı komutu **kendi reponda** çalıştır. Bugün üzerinde çalışacağın rakam o.

> Tahminler yalnızca sezgi içindir. Gerçek tokenizasyon modele göre değişir ve
> Türkçe metin aynı içerik için İngilizceden belirgin biçimde fazla token
> üretir. Rapor edeceğin hiçbir şeyde tahmin kullanma; GitHub kullanım raporunu
> kullan.

---

## Adım 2 — Her istekte yüklenen dosyayı kes (20 dk)

Kendi `copilot-instructions.md` dosyanı al. Her satıra Lab 1'deki testi uygula:

| Soruların ne kadarında gerekli | Ne yap |
|---|---|
| %80+ | bırak |
| %20–80 | `instructions/` altına taşı, `applyTo` ile |
| %20'nin altı | `.prompt.md` dosyasına taşı, istendiğinde çağrılsın |

**Hedef: 500 token altı.** Bu repodaki örnek yaklaşık 290.

Oraya inemiyorsan dosyayı wiki gibi kullanıyorsun demektir. O içerik değersiz
değil — sadece yanlış yerde.

Kestikten sonra yeniden ölç ve tasarrufunu hesapla:

```
çıkarılan_token x kişi_başı_günlük_istek x kişi x iş_günü = token/ay
```

Modelinin milyon token başına girdi fiyatıyla çarp. Yöneticine söyleyebileceğin
gerçek bir yıllık rakam elde edersin.

---

## Adım 3 — Model yönlendirme tablosunu yaz (10 dk)

Ekibin için bir sayfa. Bu iskeletten başla ve kendine uyarla:

| İş türü | Model sınıfı | Gerekçe |
|---|---|---|
| Satır içi tamamlama | varsayılan | hiç ölçülmüyor |
| Basit soru, kod okuma | hafif | muhakeme gerekmiyor |
| Hata ayıklama, refactor | dengeli | günlük işin dürüst ortası |
| Mimari, karmaşık agent işi | güçlü | fiyatını gerçekten hak ediyor |
| Kod incelemesi | seçici | koşu başına pahalı — işe yaradığı yerde kullan |

**Bu tabloyu `copilot-instructions.md`'ye koyma.** Konarsa her isteğe sonsuza
kadar eklenir ve modelin zaten karar vermediği bir şeyi ona anlatır. Ekip
wiki'sine koy, insanlar bir kez okusun.

Buradayken iki şeye daha karar ver:
- Yönlendirmeyi kim aşabilir ve aştığında birinin haberi olmalı mı?
- Kurumunda yeni açılan bir sohbetin varsayılan modeli ne?

---

## Adım 4 — Gerçek bir işte önce/sonra (15 dk)

Bu hafta gerçekten yaptığın bir işi seç. İki kez yap.

**Önce:** klasörün tamamı bağlamda, güçlü model, uzun süren bir sohbetin
ortasında sorulmuş.

**Sonra:** yeni sohbet, sadece ilgili dosya, hafif model, net tek istek.

İki koşu arasında GitHub → Settings → Billing → Usage ekranını kontrol et.

| | Önce | Sonra |
|---|---|---|
| Kullanılan model | | |
| Bağlamdaki dosya sayısı | | |
| Harcanan kredi | | |
| Cevap kabul edilebilir mi? | | |

**Kritik soru:** ucuzlatırken kötüleştirdin mi? İşi yapamayan bir kurulum üreten
optimizasyon, optimizasyon değildir. Tasarrufu ve kaliteyi birlikte raporla,
yoksa ikinci rakamı başkası daha kötü bir anda keşfeder.

---

## Adım 5 — Eylem planın (5 dk)

Tam üç satır yaz:

1. **Yarın:** kimseden izin almadan uygulayabileceğin bir kural.
2. **Bu çeyrek:** bir karar veya bir sahip gerektiren bir değişiklik.
3. **Hâlâ eksik:** karar verebilmek için ihtiyacın olan bir veri.

Bunu sakla. Takip oturumunda karşılaştıracağımız şey bu.

---

## Yedi kaldıraç — referans

Etkisi büyükten küçüğe:

1. **Doğru yüzey** — tamamlama ölçülmüyor; o işi sohbete taşıma
2. **Model yönlendirme** — aynı istekte 25 kata kadar fark
3. **Bağlam disiplini** — eklenen her dosya her turda tekrar gönderiliyor
4. **Önbellek dostu sıralama** — sabit kısmı sabit tut
5. **Araç bütçesi** — kullanmadığın MCP sunucusunu kapat
6. **Yeni sohbet refleksi** — konu değişti, baştan başla
7. **Yeniden deneme maliyeti** — iyi yazılmış tek istek, üç kötüden ucuz

---

## Çıktılar

- [ ] Her istekte yüklenen dosya 500 token altında, tasarruf parayla hesaplandı
- [ ] Model yönlendirme tablosu yazıldı, repoya değil wiki'ye
- [ ] Önce/sonra ölçümü, kalite satırı dahil dört satır dolu
- [ ] Üç satırlık eylem planı yazıldı

---

## Tartışma sorusu

Yedi kaldıraçtan hangisi kural olarak dayatılabilir, hangisi ancak alışkanlıkla
yerleşir? Dayatılabilenler için mekanizma ne — politika mı, varsayılan ayar mı,
eğitim mi? Yanlış mekanizmayı seçmek ikisini birden harcar.
