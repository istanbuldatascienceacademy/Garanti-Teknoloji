# Lab 3 — Ölçüm

**Süre:** 45 dakika (14:15–15:00)
**Kimler:** herkes
**Hedef:** tahmini ölçümle değiştirmek ve üç eşiği kendin doğrulamak

---

## Adım 1 — Gerçek rakamını bul (10 dk)

**GitHub → Settings → Billing → Usage** ekranına git.

Üç şeyi yaz:

| | Senin rakamın |
|---|---|
| Bu ay harcanan AI Credits | |
| Karışımda hangi modeller görünüyor | |
| Dahil kredinin yüzde kaçı kullanılmış | |

Erişimin yoksa eğitmen kendi ekranını gösterecek — ama kurumunda **kimin**
erişimi olduğunu öğren, önümüzdeki ay ona ihtiyacın olacak.

> **Bu adımı atlama.** Sonraki her şey bu rakama dayanıyor. Tahminle bütçe
> kurmak, ölçmemenin kibarcasıdır.

---

## Adım 2 — Senaryo scriptini çalıştır (10 dk)

```bash
python cost/scenarios.py
```

En alttaki özet tablosunu oku. Üç senaryo, aynı iş, üç farklı fiyat.

Şimdi kendine uyarla. `cost/scenarios.py` dosyasını aç ve en üstteki üç sabiti
değiştir:

```python
SEATS = 120           # kendi ekip büyüklüğün
WORKDAYS = 21
ALLOWANCE = 19.0      # Business 19, Enterprise 39
```

Sonra `baseline` profilindeki `interactions_per_dev_per_day` listesini ekibinin
gerçekten nasıl çalıştığına göre yeniden yaz — günde kaç sohbet, her biri kabaca
ne kadar bağlam taşıyor, hangi model. Tekrar çalıştır.

**Sonucu Adım 1'de yazdığın rakamla karşılaştır.** Aralarında büyük fark varsa
hatalı olan hesaplayıcı değil, senin kullanım varsayımların. Kabaca tutana kadar
düzelt — asıl uygulama bu kalibrasyonun kendisi.

---

## Adım 3 — Üç eşiği doğrula (15 dk)

Her birini çalıştır ve çıktıyı oku. Slaytlara güvenme, kendin gör.

### a) Model seçimi — 25x

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import Interaction
for m in ('gpt-5.6-luna','gpt-5.6-terra','gpt-5.6-sol'):
    i = Interaction(m, input_tokens=100_000, output_tokens=3_000)
    print(f'{m:>16}  \${i.cost_usd():.4f}  {i.credits():.1f} kredi')
"
```

### b) Önbellek — 10x

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import Interaction
tam = Interaction('gpt-5.6-terra', input_tokens=100_000)
onbellekli = Interaction('gpt-5.6-terra', cached_input_tokens=100_000)
print(f'tam        \${tam.cost_usd():.4f}')
print(f'önbellekli \${onbellekli.cost_usd():.4f}')
print(f'oran       {tam.cost_usd()/onbellekli.cost_usd():.1f}x')
"
```

Sonra dürüst sürümünü gör — Anthropic modellerinde önbelleğin bir *yazma*
maliyeti var ve düz girdiden pahalı:

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import RATES
r = RATES['claude-sonnet-5']
print(f'girdi {r.input_}  önbellekli {r.cached_input}  önbellek yazma {r.cache_write}')
"
```

Önbellek, tekrar kullanımda geri dönen bir yatırım. Kısa ömürlü bağlamda zarar
bile edebilir.

### c) Uzun bağlam — 2x

```bash
python -c "
import sys; sys.path.insert(0,'.')
from cost.calculator import Interaction
for n in (270_000, 280_000):
    i = Interaction('gpt-5.6-terra', input_tokens=n, output_tokens=3_000)
    print(f'{n:>9,} token -> \${i.cost_usd():.4f}  uzun_baglam={i.breakdown()[\"long_context\"]}')
"
```

%3,7 daha çok token, %104 daha çok para. Kademe yok — 272K'da bir uçurum var.

---

## Adım 4 — Kendini ölç (10 dk)

Gerçek bir iş seç, örneğin "şu servis çağrısına zaman aşımı ekle". İki kez yap,
her koşudan önce ve sonra GitHub kullanım raporunu kontrol et.

**A koşusu:** bağlama beş dosya ekle, güçlü model, uzun süren bir sohbetin
ortasında sor.

**B koşusu:** yeni sohbet, sadece ilgili dosya, hafif model, net tek istek.

| | A koşusu | B koşusu |
|---|---|---|
| Kullanılan model | | |
| Bağlamdaki dosya sayısı | | |
| Harcanan kredi | | |
| Cevap kabul edilebilir mi? | | |

**Asıl önemli satır dördüncüsü.** Kalite düştüyse optimizasyon yapmadın —
işi yapamayan, sadece daha ucuz bir kurulum ürettin.

---

## Çıktılar

- [ ] Gerçek kullanım rakamın yazılı
- [ ] `scenarios.py` o rakama göre kalibre edildi
- [ ] 25x, 10x ve 2x kendi terminalinde doğrulandı
- [ ] Bir önce/sonra karşılaştırması, dört satırı da dolu

---

## Tartışma sorusu

Havuzlanmış kredide bir ekibin aşımı herkesin sorunu. Bütçe kimin olmalı —
ekip lideri mi, platform ekibi mi? Ve havuz aşıma girdiğinde ilk hangi veri
istenmeli?
