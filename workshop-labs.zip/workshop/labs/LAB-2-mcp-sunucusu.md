# Lab 2 — MCP sunucusu

**Süre:** 60 dakika (11:45–12:45)
**Kimler:** sunucuyu herkes bağlar; ikinci yarıda iki kola ayrılıyoruz
**Hedef:** kurum içi bir kaynağı Copilot'a araç olarak açmak ve sınırlarını görmek

---

## Adım 1 — Ortamı kur ve yolları öğren (15 dk)

Bu adım bugünkü en sık arıza noktası. Sonuna kadar dikkatli git.

### 1a. Sanal ortam

Sistem Python'ına kurmaya çalışma. macOS'ta Homebrew Python'ı buna zaten izin
vermiyor (`externally-managed-environment` hatası), Anaconda'da ise paketler
yanlış ortama gidiyor.

```bash
cd <repo-klasoru>
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt
python -m pytest tests -q          # beklenen: 28 passed
```

`pip install mcp` PyJWT çakışmasıyla patlarsa:

```bash
python -m pip install mcp --ignore-installed PyJWT
```

Komut isteminin başında `(.venv)` yazdığını gör. Yeni terminal açtığında
kaybolur; `source .venv/bin/activate` ile geri gelir.

### 1b. Yorumlayıcının tam yolunu al

```bash
which python                       # Windows: where python
pwd
```

Çıktı `<repo>/.venv/bin/python` gibi bir şey olmalı. Bu iki değeri not et.

### 1c. mcp.json'a tam yolu yaz

Repodaki `.vscode/mcp.json` içinde `"command": "python"` yazıyor ve bu **yanlış**.
Elle düzeltmek yerine şu komutu çalıştır — doğru yolları kendisi bulup dosyayı
yazar:

```bash
python - <<'EOF'
import json, sys, pathlib
kok = pathlib.Path.cwd()
cfg = kok / ".vscode" / "mcp.json"
cfg.parent.mkdir(exist_ok=True)
cfg.write_text(json.dumps({
    "servers": {
        "corp-internal": {
            "type": "stdio",
            "command": sys.executable,
            "args": [str(kok / "mcp_server" / "corp_server.py")],
        }
    }
}, indent=2))
print(cfg.read_text())
EOF
```

`sys.executable` aktif ortamın yorumlayıcısı olduğu için doğru yol garanti.
Çıktıdaki iki yolun da `.venv` içerdiğini gör.

> **Neden bu kadar önemli:** düz `python`, PATH'te ilk gelen yorumlayıcıyı
> çalıştırır — genelde sistem Python'ı veya Anaconda base ortamı. Orada `mcp`
> paketi olmadığı için süreç anında ölür. VS Code hata gösterir ama **output
> kanalı boş kalır**, çünkü süreç yazacak vakit bulamaz. Sebebi görünmeyen bir
> hatadır ve saatler yiyebilir.

### 1d. Sunucuyu elle bir kez çalıştır

VS Code'a geçmeden önce. Yolu elle yazma, şunu olduğu gibi yapıştır:

```bash
"$(pwd)/.venv/bin/python" "$(pwd)/mcp_server/corp_server.py"
```

Ekran donup beklerse **doğru** — sunucu stdin dinliyor demektir, `Ctrl+C` ile
çık. Traceback dökerse hata buradadır ve VS Code'da göremeyeceğin şeyi burada
görürsün.

> `no such file or directory` alıyorsan ya repo kökünde değilsin (`pwd` ile
> bak) ya da `.venv` henüz kurulmamış (`ls -d .venv`).

### 1e. VS Code'da başlat

1. VS Code'u tamamen kapat (`Cmd+Q` / `Alt+F4`), yeniden aç
2. `File → Open Folder` → **repo kökünü** seç (`.vscode` klasörünü içeren dizin)
3. Güven sorusuna **Yes, I trust the authors** — güvenilmeyen klasörde MCP hiç
   listelenmez, hata da vermez
4. Komut paleti (`Ctrl/Cmd + Shift + P`) → **MCP: List Servers**
5. `corp-internal` → **Start Server**
6. Sohbetin **Agent** rolünde olduğunu doğrula

### 1f. Doğrula

Sohbete `#` yaz. Beş araç listelenmeli. Görünmezse doğrudan sor:

```
standards_list aracını çalıştır
```

**"Allow tool from corp-internal"** istemi geldiyse her şey çalışıyor demektir.
Bu istem tesadüf değil — Adım 2'nin konusu tam olarak o.

---

## Sorun giderme

| Belirti | Sebep |
|---|---|
| Liste tamamen boş | VS Code yanlış klasörü açmış. Entegre terminalde `pwd` çalıştır. |
| Hata var, output boş | `command` yanlış yorumlayıcıyı gösteriyor. 1b'ye dön. |
| `corp-internal` iki kez tanımlı | Kullanıcı düzeyindeki `mcp.json` ile workspace dosyası çakışıyor. Kullanıcı dosyasını geçici olarak yeniden adlandır. |
| Araçlar görünmüyor ama sunucu çalışıyor | Rol seçici Agent'ta değil. |
| `command not found: pip` | Sanal ortam aktif değil. `source .venv/bin/activate`. |

---

## Adım 2 — Araçları kullan (10 dk)

Şu üçünü, her birini ayrı sohbette sor:

```
Hangi dahili API'ler kişisel veri içermiyor?
```
```
Bugün üretime çıkabilir miyiz?
```
```
14 Ağustos 2026'da deploy edebilir miyiz?
```

Copilot her araç çağrısından önce izin isteyecek. **Allow**'a basmadan önce
istemi oku — o istem denetim izinin ta kendisi.

Üçüncü soru **hayır** dönmeli ve **gerekçesini de vermeli**. Aracın sadece
`false` değil, nedeni de döndürdüğüne dikkat et. İyi araç tasarımının işareti
budur: model gerekçeyi uyduramaz, alıntılamak zorundadır.

---

## Adım 3A — Geliştiriciler: araç yaz (25 dk)

`mcp_server/corp_server.py` dosyasına ekle:

```python
@mcp.tool()
def find_service_owner(service_name: str) -> str:
    """Bir servisten sorumlu ekibi döndürür.

    Kullanıcının bir servis hakkında kime başvuracağını bilmesi gerektiğinde
    kullan — kayıt açmadan veya olayı yükseltmeden önce. Elinde yalnızca
    kısmi bir isim varsa önce api_search çağır.

    Args:
        service_name: API kataloğundaki anahtar veya ad.
    """
    ...
```

Yazarken üç kural:

1. **Docstring aracın arayüzüdür.** Model araç seçimini bunu okuyarak yapıyor.
   *Ne yaptığını* değil, **ne zaman çağrılacağını** yaz.
2. **Faydalı biçimde başarısız ol.** Bulunamayınca mevcut seçenekleri döndür ki
   model tahmin etmek yerine kendini düzeltebilsin.
3. **Kişisel veri döndürme.**

Sonra `tests/test_mcp_tools.py` içine mevcut deseni izleyerek test ekle:

```python
def test_find_service_owner_returns_the_team():
    result = call(find_service_owner, service_name="limit-engine")
    assert result["owner_team"] == "Credit Technology"


def test_unknown_service_lists_alternatives():
    result = call(find_service_owner, service_name="nope")
    assert "error" in result
    assert "limit-engine" in result["available"]
```

Çalıştır, sonra sunucuyu yeniden yükleyip canlı dene:

```bash
python -m pytest tests -q
```

Komut paleti → **MCP: Restart Server** → Copilot'a sor: `Limit motorunun sahibi kim?`

---

## Adım 3B — Analistler: araçları değerlendir (25 dk)

Araç yazmıyorsun. Daha zor olan soruyu yanıtlıyorsun: hangi araç olmamalı.

`mcp_server/corp_server.py` dosyasını aç, beş docstring'i oku ve şunlara kısa
yanıtlar yaz:

1. Hangi açıklama modelin **yanlış** aracı seçmesine yol açabilir? Yeniden yaz.
2. `api_search` aracının `pii_free_only` parametresi olmasaydı ne bozulurdu?
3. Bu sunucuya **eklenmemesi** gereken bir araç söyle ve nedenini savun.
   Somut ol: hangi veriyi döndüreceğini ve neyin ters gideceğini adıyla yaz.
4. `can_deploy` verdiktin yanında gerekçe de döndürüyor. Sadece `true`/`false`
   dönseydi ne kaybederdik?

Değerlendirmede ilk siz sunuyorsunuz. İki dakika.

> Bu kolay kol değil. Bankada asıl kritik soru *hangi aracın yazılmaması
> gerektiği* ve bu soru Python bilene değil, iş sonucunu bilene ait.

---

## Adım 4 — Sunucunun maliyeti (10 dk)

Herkes, sohbete:

```
tool_cost aracını çalıştır.
```

Çıktıyı oku. Bu şemalar, **bu sunucu bağlıyken yapılan her isteğe** gidiyor —
sunucuyla hiç ilgisi olmayan istekler dahil.

Şimdi hesabı sesli yap: sekizer araçlı on sunucu, herkesin sorduğu her sorunun
başına seksen araç şeması ekler. Copilot'un tavanı istek başına 128 araç, ama
kalite bozulması çok daha önce başlar — çünkü model bunların arasından seçmek
zorunda.

**Alınacak kural:** bugün kullanmadığın sunucuyu kapat. Sunucu bağlamak bedava
değil.

---

## Çıktılar

- [ ] Sunucu bağlı, beş araç görünüyor, üç soru da yanıtlandı
- [ ] Geliştirici: `find_service_owner` yazıldı, testler geçiyor, canlı çalışıyor
- [ ] Analist: dört değerlendirme sorusuna yazılı yanıt
- [ ] `tool_cost()` çalıştırıldı ve hesap yapıldı

---

## Tartışma sorusu

Bu sunucu bilinçli olarak müşteri verisi döndürmüyor. Bir ekip müşteri sorgulama
aracı yazmak isterse hangi onaylardan geçmeli — ve kararı kim verir:
geliştirici mi, mimari mi, uyum mu?
