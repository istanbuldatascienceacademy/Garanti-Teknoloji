"""GitHub Copilot AI Credits cost calculator.

On 1 June 2026 Copilot moved to usage-based billing. Premium requests are no
longer counted; input, output and cache tokens are priced per model and
converted to AI Credits. 1 AI credit = 0.01 USD.

PRICES were taken from the GitHub Docs page "Models and pricing for GitHub
Copilot". Prices change. Before you present these numbers to anyone, verify
them at:
    docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing
Updating the RATES dictionary below is all that is required.
"""

from __future__ import annotations

from dataclasses import dataclass, field

RATE_SOURCE = "GitHub Docs · Models and pricing · retrieved 2026-07-31"
CREDIT_USD = 0.01  # 1 AI credit = $0.01


@dataclass(frozen=True)
class ModelRate:
    """Price in USD per one million tokens."""

    name: str
    vendor: str
    category: str
    input_: float
    cached_input: float
    output: float
    cache_write: float | None = None          # Anthropic models charge for this
    long_context_threshold: int | None = None
    long_input: float | None = None
    long_cached_input: float | None = None
    long_output: float | None = None

    def rates_for(self, input_tokens: int) -> tuple[float, float, float]:
        """Return (input, cached_input, output) prices for a given input size.

        Models with a long-context tier jump in price once the threshold is
        crossed — usually to double. This is the sharpest lesson in the
        workshop, so the calculator models it explicitly.
        """
        if (
            self.long_context_threshold is not None
            and input_tokens > self.long_context_threshold
            and self.long_input is not None
        ):
            return (
                self.long_input,
                self.long_cached_input if self.long_cached_input is not None else self.cached_input,
                self.long_output if self.long_output is not None else self.output,
            )
        return self.input_, self.cached_input, self.output


# --- Official rate table (see RATE_SOURCE) ---
RATES: dict[str, ModelRate] = {
    # OpenAI
    "gpt-5-mini": ModelRate("GPT-5 mini", "OpenAI", "Light", 0.25, 0.025, 2.00),
    "gpt-5.4": ModelRate("GPT-5.4", "OpenAI", "Balanced", 2.50, 0.25, 15.00,
                         long_context_threshold=272_000, long_input=5.00,
                         long_cached_input=0.50, long_output=22.50),
    "gpt-5.6-luna": ModelRate("GPT-5.6 Luna", "OpenAI", "Light", 0.20, 0.02, 1.20,
                              long_context_threshold=200_000, long_input=0.40,
                              long_cached_input=0.04, long_output=1.80),
    "gpt-5.6-terra": ModelRate("GPT-5.6 Terra", "OpenAI", "Balanced", 2.00, 0.20, 12.00,
                               long_context_threshold=272_000, long_input=4.00,
                               long_cached_input=0.40, long_output=18.00),
    "gpt-5.6-sol": ModelRate("GPT-5.6 Sol", "OpenAI", "Frontier", 5.00, 0.50, 30.00,
                             long_context_threshold=272_000, long_input=10.00,
                             long_cached_input=1.00, long_output=45.00),
    # Anthropic (cache writes are billed separately)
    "claude-haiku-4.5": ModelRate("Claude Haiku 4.5", "Anthropic", "Balanced",
                                  1.00, 0.10, 5.00, cache_write=1.25),
    "claude-sonnet-5": ModelRate("Claude Sonnet 5", "Anthropic", "Balanced",
                                 2.00, 0.20, 10.00, cache_write=2.50),
    "claude-opus-5": ModelRate("Claude Opus 5", "Anthropic", "Frontier",
                               5.00, 0.50, 25.00, cache_write=6.25),
    # Google
    "gemini-2.5-pro": ModelRate("Gemini 2.5 Pro", "Google", "Frontier", 1.25, 0.125, 10.00),
    # Other
    "raptor-mini": ModelRate("Raptor mini", "GitHub", "Light", 0.25, 0.025, 2.00),
}


@dataclass
class Interaction:
    """One Copilot interaction: a chat turn, an agent step, a code review."""

    model: str
    input_tokens: int = 0
    output_tokens: int = 0
    cached_input_tokens: int = 0
    cache_write_tokens: int = 0
    label: str = ""

    def __post_init__(self) -> None:
        if self.model not in RATES:
            raise ValueError(
                f"Unknown model '{self.model}'. Defined: {', '.join(sorted(RATES))}"
            )
        for name, value in (
            ("input_tokens", self.input_tokens),
            ("output_tokens", self.output_tokens),
            ("cached_input_tokens", self.cached_input_tokens),
            ("cache_write_tokens", self.cache_write_tokens),
        ):
            if value < 0:
                raise ValueError(f"{name} cannot be negative.")

    @property
    def total_input(self) -> int:
        return self.input_tokens + self.cached_input_tokens

    def cost_usd(self) -> float:
        rate = RATES[self.model]
        p_in, p_cached, p_out = rate.rates_for(self.total_input)
        cost = (
            self.input_tokens / 1_000_000 * p_in
            + self.cached_input_tokens / 1_000_000 * p_cached
            + self.output_tokens / 1_000_000 * p_out
        )
        if self.cache_write_tokens and rate.cache_write is not None:
            cost += self.cache_write_tokens / 1_000_000 * rate.cache_write
        return cost

    def credits(self) -> float:
        return self.cost_usd() / CREDIT_USD

    def breakdown(self) -> dict:
        rate = RATES[self.model]
        p_in, p_cached, p_out = rate.rates_for(self.total_input)
        return {
            "label": self.label or rate.name,
            "model": rate.name,
            "long_context": rate.long_context_threshold is not None
            and self.total_input > rate.long_context_threshold,
            "input_usd": round(self.input_tokens / 1_000_000 * p_in, 6),
            "cached_input_usd": round(self.cached_input_tokens / 1_000_000 * p_cached, 6),
            "cache_write_usd": round(
                self.cache_write_tokens / 1_000_000 * (rate.cache_write or 0.0), 6
            ),
            "output_usd": round(self.output_tokens / 1_000_000 * p_out, 6),
            "total_usd": round(self.cost_usd(), 6),
            "credits": round(self.credits(), 4),
        }


@dataclass
class TeamProfile:
    """A team's monthly usage profile.

    plan_allowance_usd: included AI Credits per seat per month, in USD.
    Copilot Business includes 19 USD and Enterprise 39 USD per seat, and those
    allowances are POOLED at the billing-entity level.
    """

    name: str
    seats: int
    workdays_per_month: int = 21
    plan_allowance_usd: float = 19.0
    interactions_per_dev_per_day: list[Interaction] = field(default_factory=list)

    def daily_cost_per_dev(self) -> float:
        return sum(i.cost_usd() for i in self.interactions_per_dev_per_day)

    def monthly_cost(self) -> float:
        return self.daily_cost_per_dev() * self.workdays_per_month * self.seats

    def monthly_allowance(self) -> float:
        return self.plan_allowance_usd * self.seats

    def overage(self) -> float:
        return max(0.0, self.monthly_cost() - self.monthly_allowance())

    def summary(self) -> dict:
        monthly = self.monthly_cost()
        allowance = self.monthly_allowance()
        return {
            "profile": self.name,
            "seats": self.seats,
            "daily_per_dev_usd": round(self.daily_cost_per_dev(), 4),
            "monthly_total_usd": round(monthly, 2),
            "monthly_allowance_usd": round(allowance, 2),
            "overage_usd": round(self.overage(), 2),
            "allowance_used_pct": round(monthly / allowance * 100, 1) if allowance else 0.0,
            "monthly_per_seat_usd": round(monthly / self.seats, 2) if self.seats else 0.0,
        }


def compare(before: TeamProfile, after: TeamProfile) -> dict:
    """Compare two profiles — what the optimisation is worth in money."""
    old, new = before.monthly_cost(), after.monthly_cost()
    diff = old - new
    return {
        "before_monthly_usd": round(old, 2),
        "after_monthly_usd": round(new, 2),
        "saving_usd": round(diff, 2),
        "saving_pct": round(diff / old * 100, 1) if old else 0.0,
        "annual_saving_usd": round(diff * 12, 2),
    }


def model_table() -> list[dict]:
    """Return the rate table in a readable form — usable in slides."""
    rows = []
    for key, r in sorted(RATES.items(), key=lambda kv: kv[1].input_):
        rows.append({
            "key": key,
            "model": r.name,
            "vendor": r.vendor,
            "category": r.category,
            "input": r.input_,
            "cached_input": r.cached_input,
            "output": r.output,
            "cache_write": r.cache_write,
            "cache_discount_x": round(r.input_ / r.cached_input, 1) if r.cached_input else None,
        })
    return rows


def estimate_tokens(text: str) -> int:
    """A very rough token estimate — intuition, not measurement.

    Real tokenisation is model-specific. This is good enough to answer "roughly
    how big is this instruction file", and must NEVER be used for billing —
    the real figure lives in the GitHub usage report.

    Turkish text produces noticeably more tokens than English for the same
    content; 3 characters per token is the assumption here.
    """
    return max(1, len(text) // 3)
