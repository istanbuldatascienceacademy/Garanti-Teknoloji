"""Scenario comparison — what each optimisation is worth in money.

Run it:  python cost/scenarios.py

This script is the backbone of Labs 3 and 4. Participants change the constants
below to their own team size and usage pattern, then run it again.

WARNING: the usage assumptions here (requests per day, tokens per request) are
EXAMPLES. Real figures come from the GitHub usage report:
Settings -> Billing -> Usage. Stress this distinction in the room — budgeting
from an estimate is the polite form of not measuring at all.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from cost.calculator import (  # noqa: E402
    RATE_SOURCE,
    Interaction,
    TeamProfile,
    compare,
    model_table,
)

# ─── CHANGE THESE THREE LINES TO MATCH YOUR OWN TEAM ────────────────
SEATS = 120           # your team size
WORKDAYS = 21         # working days per month
ALLOWANCE = 19.0      # Copilot Business 19, Enterprise 39
# ───────────────────────────────────────────────────────────────────


def banner(text: str) -> None:
    print(f"\n{'=' * 78}\n{text}\n{'=' * 78}")


def show(profile: TeamProfile) -> None:
    s = profile.summary()
    print(f"  {s['profile']}")
    print(f"    Per person, per day   : ${s['daily_per_dev_usd']:>10,.4f}")
    print(f"    Per person, per month : ${s['monthly_per_seat_usd']:>10,.2f}")
    print(f"    Team monthly total    : ${s['monthly_total_usd']:>10,.2f}")
    print(f"    Included (pooled)     : ${s['monthly_allowance_usd']:>10,.2f}")
    print(f"    Allowance used        : {s['allowance_used_pct']:>10,.1f}%")
    if s["overage_usd"] > 0:
        print(f"    ! OVERAGE (billed)    : ${s['overage_usd']:>10,.2f}/month")
    else:
        print("    + No overage")


# ────────────────────────────────────────────────────────────────
banner("0. RATE TABLE — how much does model choice alone matter?")
print(f"  Source: {RATE_SOURCE}\n")
print(f"  {'Model':<22}{'Input':>9}{'Cached':>10}{'Output':>10}   Cache discount")
print("  " + "-" * 70)
for r in model_table():
    if r["key"] in ("gpt-5.6-luna", "raptor-mini", "gemini-2.5-pro",
                    "gpt-5.6-terra", "claude-sonnet-5", "claude-opus-5", "gpt-5.6-sol"):
        disc = f"{r['cache_discount_x']}x" if r["cache_discount_x"] else "-"
        print(f"  {r['model']:<22}${r['input']:>8.2f}${r['cached_input']:>9.3f}"
              f"${r['output']:>9.2f}{disc:>15}")
print("\n  -> 25x between the cheapest and most expensive input price.")
print("  -> Cached input is ~10x cheaper on every model. Largest single lever.")

# ────────────────────────────────────────────────────────────────
banner("1. BASELINE — no optimisation at all")

baseline = TeamProfile(
    name="Before optimisation", seats=SEATS, workdays_per_month=WORKDAYS,
    plan_allowance_usd=ALLOWANCE,
    interactions_per_dev_per_day=[
        # Frontier model for everything, no cache, bloated context
        Interaction("gpt-5.6-sol", input_tokens=45_000, output_tokens=1_500,
                    label="Morning: understanding code"),
        Interaction("gpt-5.6-sol", input_tokens=60_000, output_tokens=2_500,
                    label="Midday: feature work (agent)"),
        Interaction("gpt-5.6-sol", input_tokens=55_000, output_tokens=2_000,
                    label="Afternoon: debugging"),
        Interaction("gpt-5.6-sol", input_tokens=40_000, output_tokens=1_200,
                    label="Evening: PR description"),
    ],
)
show(baseline)

# ────────────────────────────────────────────────────────────────
banner("2. OPTIMISATION 1 — model routing")
print("  Not every task deserves the frontier model. Routine work goes light,")
print("  genuinely hard work stays strong.\n")

opt1 = TeamProfile(
    name="After model routing", seats=SEATS, workdays_per_month=WORKDAYS,
    plan_allowance_usd=ALLOWANCE,
    interactions_per_dev_per_day=[
        Interaction("gpt-5.6-luna", input_tokens=45_000, output_tokens=1_500,
                    label="Understanding code -> light"),
        Interaction("gpt-5.6-sol", input_tokens=60_000, output_tokens=2_500,
                    label="Feature work -> frontier (earns it)"),
        Interaction("gpt-5.6-terra", input_tokens=55_000, output_tokens=2_000,
                    label="Debugging -> balanced"),
        Interaction("gpt-5.6-luna", input_tokens=40_000, output_tokens=1_200,
                    label="PR description -> light"),
    ],
)
show(opt1)
c1 = compare(baseline, opt1)
print(f"\n  -> Saving: ${c1['saving_usd']:,.2f}/month "
      f"({c1['saving_pct']}%) · ${c1['annual_saving_usd']:,.2f}/year")

# ────────────────────────────────────────────────────────────────
banner("3. OPTIMISATION 2 — context discipline + cache")
print("  Instruction files trimmed, unused MCP servers disconnected, and the")
print("  fixed part of the context now lands in the cache.\n")

opt2 = TeamProfile(
    name="After context discipline", seats=SEATS, workdays_per_month=WORKDAYS,
    plan_allowance_usd=ALLOWANCE,
    interactions_per_dev_per_day=[
        Interaction("gpt-5.6-luna", input_tokens=6_000, cached_input_tokens=18_000,
                    output_tokens=1_500, label="Understanding code"),
        Interaction("gpt-5.6-sol", input_tokens=9_000, cached_input_tokens=22_000,
                    output_tokens=2_500, label="Feature work"),
        Interaction("gpt-5.6-terra", input_tokens=8_000, cached_input_tokens=20_000,
                    output_tokens=2_000, label="Debugging"),
        Interaction("gpt-5.6-luna", input_tokens=5_000, cached_input_tokens=15_000,
                    output_tokens=1_200, label="PR description"),
    ],
)
show(opt2)
c2 = compare(baseline, opt2)
print(f"\n  -> Saving vs baseline: ${c2['saving_usd']:,.2f}/month "
      f"({c2['saving_pct']}%) · ${c2['annual_saving_usd']:,.2f}/year")

# ────────────────────────────────────────────────────────────────
banner("4. THE LONG-CONTEXT CLIFF — the 272K threshold")
print("  On GPT-5.6 Terra, crossing 272K input tokens doubles the input price.")
print("  Throwing the whole repository into context crosses it easily.\n")

under = Interaction("gpt-5.6-terra", input_tokens=270_000, output_tokens=3_000)
over = Interaction("gpt-5.6-terra", input_tokens=280_000, output_tokens=3_000)
print(f"  270,000 input tokens : ${under.cost_usd():.4f}")
print(f"  280,000 input tokens : ${over.cost_usd():.4f}")
print(f"  -> 3.7% more tokens, {(over.cost_usd()/under.cost_usd()-1)*100:.0f}% more money.")
print("\n  If the team crosses this line twice a day:")
daily_gap = (over.cost_usd() - under.cost_usd()) * 2
print(f"  {SEATS} people x {WORKDAYS} days x 2 = "
      f"${daily_gap * SEATS * WORKDAYS:,.2f}/month from the threshold alone.")

# ────────────────────────────────────────────────────────────────
banner("5. CODE COMPLETION — the part that is not billed")
print("  GitHub Docs: inline completion and next-edit suggestions do not draw")
print("  down AI Credits; they are unlimited on paid plans.\n")
print("  Practical consequence: moving a task that inline completion could have")
print("  handled into chat converts something free into something billed. This is")
print("  the simplest and highest-return rule you can hand a team.")

# ────────────────────────────────────────────────────────────────
banner("SUMMARY")
print(f"  Team: {SEATS} people · {WORKDAYS} working days · "
      f"${ALLOWANCE} included credits per seat\n")
print(f"  {'Scenario':<32}{'Monthly':>14}{'Allowance used':>20}")
print("  " + "-" * 66)
for p in (baseline, opt1, opt2):
    s = p.summary()
    print(f"  {s['profile']:<32}${s['monthly_total_usd']:>13,.2f}"
          f"{s['allowance_used_pct']:>19,.1f}%")
print("  " + "-" * 66)
print(f"\n  Total saving: ${c2['saving_usd']:,.2f}/month · "
      f"${c2['annual_saving_usd']:,.2f}/year ({c2['saving_pct']}%)")
print("\n  Note: these rest on example usage assumptions. For your own team's real")
print("  figure use GitHub -> Settings -> Billing -> Usage.")
