# Instructor runbook

How to run the day. Read this once end to end before you deliver.

---

## Solo rehearsal setup

You do not need the client's organisation to rehearse this material. A personal
Copilot Pro seat is enough for Labs 1, 2 and 4 in full, and for most of Lab 3.

**Why it is simpler on a personal seat:** the "MCP servers in Copilot" policy
gate exists only on Business and Enterprise plans. On an individual plan Agent
mode and MCP are available without an administrator.

### Setup, about 15 minutes

1. Take a Copilot Pro seat on your own GitHub account.
2. Install VS Code (1.99 or later), then the **GitHub Copilot** and
   **GitHub Copilot Chat** extensions. Sign in from the Copilot icon.
3. Settings → search `github.copilot.chat.agent.enabled` → set to `true`.
4. Confirm the mode selector under the chat box shows **Agent**.
5. Clone the workshop repo:
   ```bash
   pip install -r requirements.txt
   python -m pytest tests -q          # 28 passed
   python cost/scenarios.py
   ```
6. Command palette → **MCP: List Servers** → start `corp-internal` → check that
   five tools appear in the chat panel's tool list.

### What you can rehearse fully

| Lab | Works solo? |
|---|---|
| 1 — Instruction files | Yes, completely |
| 2 — MCP server | Yes, completely, including writing the new tool |
| 3 — Measurement | Mostly — see below |
| 4 — Optimisation | Yes, completely |

### The four things you cannot verify alone

These are all **talk content, not lab steps**, so they create no rehearsal gap —
but know that you are presenting them untested against the client's environment:

1. **Credit pooling** — exists only at the billing-entity level. Your Pro
   account shows your own consumption under Settings → Billing → Usage, which is
   enough to rehearse Lab 3 Step 1, but you will not see a pool.
2. **Organisation-level instructions** (slide 17) — central definition applied
   across repositories.
3. **Approved MCP server lists and server access policies** (slides 28–29).
4. **Content exclusion** — which directories are hidden from the assistant.

On the day itself you need one participant with access to
**Settings → Billing → Usage** for Lab 3 Step 1. Arrange this in advance.

### Time the rehearsal

Block three hours and run all four labs end to end, noting how long each step
*actually* takes. The durations printed in the lab guides are estimates. Your
own measured numbers are far more useful when you are pacing the real day.

---

## Three days before

- [ ] Send the prerequisite list to the client and get a written confirmation
      that **Agent mode and MCP are permitted by policy**. Be specific: on
      Copilot Business and Enterprise an administrator must enable the
      **"MCP servers in Copilot"** policy, and it is **off by default**. If it
      stays off, `.vscode/mcp.json` does nothing — the server simply does not
      appear, and no error is shown anywhere. Get a named person to confirm
      they have turned it on, not a general "yes, we allow it".
- [ ] Ask whether any **content exclusion** rules would hide the workshop repo
      from Copilot.
- [ ] Send participants the environment check and ask for the output back:
      `python3 --version` (must be 3.10+) and `which python3`. Anaconda,
      Homebrew Python and system Python all behave differently, and the
      interpreter path is the single thing Lab 2 depends on. Do not accept
      "yes, Python is installed" — ask for the two lines.
- [ ] Warn them: install the **stable** VS Code, not Insiders. The Insiders UI
      changes weekly and will not match what you demonstrate.
- [ ] Confirm network access to `github.com`, `api.githubcopilot.com` and PyPI.
- [ ] Ask for one participant with access to **Settings → Billing → Usage**.
      If nobody has it, plan to show your own screen in Lab 3.
- [ ] Re-verify the rate table. Open
      `docs.github.com/en/copilot/reference/copilot-billing/models-and-pricing`
      and update the `RATES` dictionary in `cost/calculator.py`. Prices change,
      and this room will check.
- [ ] Set `SEATS` in `cost/scenarios.py` to the client's real team size. The
      opening slide's impact depends entirely on that number being theirs.

## The day before

- [ ] Run every lab yourself, start to finish, on a clean clone.
- [ ] `pip install -r requirements.txt && python -m pytest tests -q` → 28 passed
- [ ] `python cost/scenarios.py` → check the summary table matches your slides
- [ ] Connect the MCP server in VS Code and ask all three Lab 2 questions.

---

## Speaker materials

Two documents, two purposes:

- `SUNUM-TAM-METIN.md` — the full verbatim script for all 60 slides. Read it once
  end to end while preparing, then close it. Do not read from it in the room.
- `SUNUM-KILAVUZU.md` — the condensed guide. This is the one to keep open while
  presenting: timing, what is on screen, what to say, what to watch for.

## Speaker guide

`SUNUM-KILAVUZU.md` walks all 60 slides in order: timing, what is on screen,
what to say, and what to watch for. It also flags which slides to compress when
you run late, and which ones never to compress (24, 25, 26 and 54).

## Answer key

Every lab discussion question, plus the four Lab 2 analyst-track review
questions, has a worked answer in `labs/EGITMEN-CEVAP-ANAHTARI.md` — including
where each room typically tries to escape the question. Read it before you
deliver; use it only when a discussion stalls.

## Running each block

### Opening (09:00–09:30)

Project the output of `python cost/scenarios.py`. Show the three-row summary.
Then ask: *"Same work, same people. Which one are you in?"* and stop talking.

Most rooms cannot answer. That silence is the reason for the day.

**Say out loud that the figures rest on modelled assumptions** and that they
will find their own real numbers in Lab 3. If you oversell here, you lose the
senior engineers for the rest of the day.

### Lab 1 (10:15–11:00)

Circulate during Step 2. The argument about which lines are necessary *is* the
lab — do not let people rush past it to the tooling.

Common stumble: people ask the second question in the same chat as the first,
so the old answer is still in context. Watch for it and correct it early,
because the same mistake ruins every measurement in Lab 3.

### Lab 2 (11:45–12:45)

**Step 1 is where the whole lab is won or lost.** Budget the full 15 minutes and
do not let anyone skip ahead to Step 2.

The failure you will see most is this: `mcp.json` says `"command": "python"`,
PATH resolves that to a system or Anaconda interpreter without the `mcp`
package, and the process dies before it can write anything. VS Code shows an
error and an **empty output channel**. There is no visible cause, and people
will burn twenty minutes on it. The fix is always the same — put the full
interpreter path from `which python` into `command`.

Teach Step 1d as a habit, not a workaround: run the server by hand before
trusting the IDE. A process that starts from your terminal and dies inside VS
Code narrows the problem to configuration in one move.

Other things to watch:

- Someone will be in the wrong role and wonder why no tools appear.
- Someone will have VS Code open on the parent folder, so `.vscode/mcp.json` is
  never found. `pwd` in the integrated terminal settles it immediately.
- Someone who experimented with **MCP: Add Server** earlier will have a stale
  user-level definition shadowing the workspace one. Rename it and reload.

**Do not let the analyst track look like the easy option.** Have the analyst
group present first in the debrief. "Which tool should not exist" is the harder
question and in a bank it is the one that matters.

### Lab 3 (14:15–15:00)

Step 1 is non-negotiable. If nobody has billing access, show yours — but make
them write down who in their organisation does.

When someone's calibrated model does not match their real usage figure, that is
a finding, not a failure. Work through it with them in front of the room.

### Lab 4 (15:30–16:30)

Step 2 generates the best arguments of the day. Give it real time.

Watch for the failure mode in Step 4: someone reports a large saving and quietly
skips the quality row. Ask about it directly.

### Closing (16:30–17:00)

Groups of three, one page each, three-minute presentations:

1. Model routing table — which work to which model class
2. MCP approval process — who approves what, against which criteria
3. Instruction file ownership — who may change it, what review, what token budget
4. Measurement rhythm — who reads which report, how often, what happens on overage

**Collect the four pages before anyone leaves.** That document is the durable
value of the day; everything before it was preparation for writing it.

---

## Handling the hard questions

**"Are these prices real?"**
They came from GitHub Docs on the date in `RATE_SOURCE`. Show the URL, say
prices change, and point at the one dictionary that has to be updated.

**"Does the cache not have a write cost?"**
Yes, on Anthropic models, and it is higher than plain input. Volunteer this
before anyone asks — slide 43 exists for exactly this. Caching is an investment
that pays back on reuse; on a short-lived context it can lose money.

**"Our security team will never allow MCP."**
Good — that is the correct default posture. The answer is an approved server
list, not free installation, and Lab 2's discussion question is designed to
start that conversation rather than end it.

**"Is this not just telling people to use worse models?"**
No. Slide 54 and Lab 4 Step 4 make quality a recorded column. An optimisation
that produces a setup which cannot do the work is not an optimisation.

---

## Four to six weeks later

Half-day follow-up: compare the savings predicted on the day against what
actually happened, and correct the policy where it did not hold.

This is what turns a workshop into a programme — and it sets up the second
engagement without you having to sell it.
